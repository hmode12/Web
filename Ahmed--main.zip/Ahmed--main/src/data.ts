/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { World, Question, ShopItem, Achievement, LeaderboardEntry } from "./types";

export const WORLDS: World[] = [
  {
    id: 1,
    name: "Green Meadows",
    arabicName: "المروج الخضراء",
    description: "Peaceful hand-drawn grasslands with cartoon butterflies and flowers.",
    accent: "#5BB381",
    themeColor: "bg-[#E2F0D9]",
    bgColor: "#E2F0D9",
    textColor: "text-[#3D6E4F]",
    levelsRange: [1, 50],
    starsRequiredToUnlock: 0,
    bgDecorativeElements: ["🦋", "🌸", "🌻", "☁️"],
  },
  {
    id: 2,
    name: "Deep Forest",
    arabicName: "الغابة العميقة",
    description: "Dense trees with cute cartoon woodland animals and heavy ink mist.",
    accent: "#3E5C3B",
    themeColor: "bg-[#D0E1C9]",
    bgColor: "#D0E1C9",
    textColor: "text-[#284025]",
    levelsRange: [51, 100],
    starsRequiredToUnlock: 15,
    bgDecorativeElements: ["🌲", "🦉", "🦌", "🍄"],
  },
  {
    id: 3,
    name: "Golden Desert",
    arabicName: "الصحراء الذهبية",
    description: "Warm sand dunes, ancient ruins, and animated heatwaves.",
    accent: "#D9A241",
    themeColor: "bg-[#F7E7C4]",
    bgColor: "#F7E7C4",
    textColor: "text-[#875F1B]",
    levelsRange: [101, 150],
    starsRequiredToUnlock: 45,
    bgDecorativeElements: ["🌵", "🐪", "🏺", "☀️"],
  },
  {
    id: 4,
    name: "High Mountains",
    arabicName: "الجبال الشاهقة",
    description: "Cliffside bridges, cartoon mountain goats, and cascading waterfalls.",
    accent: "#64858C",
    themeColor: "bg-[#E1ECED]",
    bgColor: "#E1ECED]",
    textColor: "text-[#3C5459]",
    levelsRange: [151, 200],
    starsRequiredToUnlock: 85,
    bgDecorativeElements: ["🏔️", "🐐", "🦅", "🌉"],
  },
  {
    id: 5,
    name: "Snow Mountains",
    arabicName: "قمم الجليد",
    description: "Slippery ice caves, cozy cabins, and sparkling cartoon snowflakes.",
    accent: "#5B96B3",
    themeColor: "bg-[#E6F3F8]",
    bgColor: "#E6F3F8",
    textColor: "text-[#2C5970]",
    levelsRange: [201, 250],
    starsRequiredToUnlock: 135,
    bgDecorativeElements: ["❄️", "☃️", "🐧", "🏠"],
  },
  {
    id: 6,
    name: "Volcano Land",
    arabicName: "أرض البراكين",
    description: "Bouncing bubbles of animated orange lava and cute charcoal clouds.",
    accent: "#D2543A",
    themeColor: "bg-[#FCDFD7]",
    bgColor: "#FCDFD7",
    textColor: "text-[#852C1B]",
    levelsRange: [251, 300],
    starsRequiredToUnlock: 195,
    bgDecorativeElements: ["🌋", "🔥", "☄️", "💀"],
  },
  {
    id: 7,
    name: "Ocean Kingdom",
    arabicName: "مملكة الأعماق",
    description: "Submerged retro kingdom with coral reefs and waving starfishes.",
    accent: "#3A96D2",
    themeColor: "bg-[#D7EFFC]",
    bgColor: "#D7EFFC",
    textColor: "text-[#1C557A]",
    levelsRange: [301, 350],
    starsRequiredToUnlock: 265,
    bgDecorativeElements: ["🐙", "🐠", "🦀", "🫧"],
  },
  {
    id: 8,
    name: "Sky Kingdom",
    arabicName: "مملكة السحاب",
    description: "Floating islands connected by dynamic cartoon rainbow bridges.",
    accent: "#8B5FBF",
    themeColor: "bg-[#F3EBF9]",
    bgColor: "#F3EBF9",
    textColor: "text-[#54317D]",
    levelsRange: [351, 400],
    starsRequiredToUnlock: 345,
    bgDecorativeElements: ["🌈", "🦄", "🏰", "⚡"],
  },
  {
    id: 9,
    name: "Haunted Castle",
    arabicName: "القصر المسكون",
    description: "Family-friendly bouncing ghosts, old portraits, and candle flickers.",
    accent: "#5E4A8C",
    themeColor: "bg-[#E7E2F2]",
    bgColor: "#E7E2F2",
    textColor: "text-[#3B2861]",
    levelsRange: [401, 450],
    starsRequiredToUnlock: 435,
    bgDecorativeElements: ["👻", "🦇", "🕯️", "🕸️"],
  },
  {
    id: 10,
    name: "Space Galaxy",
    arabicName: "فضاء المجرة",
    description: "Twinkling 1930s hand-drawn stars, meteors, and bouncing spaceships.",
    accent: "#1A2536",
    themeColor: "bg-[#CFD8E3]",
    bgColor: "#CFD8E3",
    textColor: "text-[#101F33]",
    levelsRange: [451, 500],
    starsRequiredToUnlock: 535,
    bgDecorativeElements: ["🚀", "🪐", "⭐", "👽"],
  }
];

// الأسئلة المنسقة يدوياً للعوالم الأولى (تم توزيع الإجابة الصحيحة بشكل عشوائي في المصفوفات)
export const CURATED_QUESTIONS: Record<number, Question[]> = {
  1: [
    {
      id: 101,
      question: "Which planet is known as the Red Planet?",
      arabicQuestion: "أي كوكب في مجموعتنا الشمسية يشتهر بالكوكب الأحمر؟",
      answers: ["Earth", "Mars", "Jupiter", "Venus"],
      arabicAnswers: ["الأرض", "المريخ", "المشتري", "الزهرة"],
      correctAnswer: "Mars",
      arabicCorrectAnswer: "المريخ",
      explanation: "Mars is called the Red Planet because of iron oxide (rust) on its surface.",
      arabicExplanation: "يُطلق على المريخ اسم الكوكب الأحمر بسبب انتشار أكسيد الحديد (الصدأ) على سطحه.",
      difficulty: "Easy"
    },
    {
      id: 102,
      question: "How many elements are there in the water chemical formula?",
      arabicQuestion: "كم عدد اللاعبين في فريق كرة القدم داخل الملعب أثناء المباراة؟",
      answers: ["11", "7", "9", "5"],
      arabicAnswers: ["11", "7", "9", "5"],
      correctAnswer: "11",
      arabicCorrectAnswer: "11",
      explanation: "An official soccer match is played with 11 players in each team on the pitch.",
      arabicExplanation: "تُلعب مباراة كرة القدم الرسمية بوجود 11 لاعباً من كل فريق داخل أرضية الملعب.",
      difficulty: "Easy"
    },
    {
      id: 103,
      question: "What is the largest ocean on Earth?",
      arabicQuestion: "ما هو أكبر محيط على وجه الكرة الأرضية؟",
      answers: ["Atlantic Ocean", "Indian Ocean", "Pacific Ocean", "Arctic Ocean"],
      arabicAnswers: ["المحيط الأطلسي", "المحيط الهندي", "المحيط الهادئ", "المحيط المتجمد الشمالي"],
      correctAnswer: "Pacific Ocean",
      arabicCorrectAnswer: "المحيط الهادئ",
      explanation: "The Pacific Ocean is the largest and deepest of Earth's oceanic divisions.",
      arabicExplanation: "المحيط الهادئ هو أكبر وأعمق المسطحات المائية على كوكب الأرض.",
      difficulty: "Easy"
    },
    {
      id: 104,
      question: "Which programming language is mainly used for building web page behavior?",
      arabicQuestion: "ما هي لغة البرمجة الأساسية المستخدمة لإضافة التفاعل وحركات الواجهة في صفحات الويب؟",
      answers: ["Python", "JavaScript", "C++", "HTML"],
      arabicAnswers: ["بايثون (Python)", "جافا سكريبت (JavaScript)", "سي بلس بلس (++C)", "HTML"],
      correctAnswer: "JavaScript",
      arabicCorrectAnswer: "جافا سكريبت (JavaScript)",
      explanation: "JavaScript is the logic language of the web that brings pages to life.",
      arabicExplanation: "جافا سكريبت هي لغة البرمجة الأساسية لتطوير المتصفحات وجعل صفحات الويب تفاعلية وديناميكية.",
      difficulty: "Easy"
    }
  ],
  2: [
    {
      id: 201,
      question: "Who painted the famous Mona Lisa?",
      arabicQuestion: "من هو الرسام والفنان الشهير صاحب لوحة الموناليزا؟",
      answers: ["Pablo Picasso", "Leonardo da Vinci", "Vincent van Gogh", "Michelangelo"],
      arabicAnswers: ["بابلو بيكاسو", "ليوناردو دا فينشي", "فينسنت فان جوخ", "مايكل أنجلو"],
      correctAnswer: "Leonardo da Vinci",
      arabicCorrectAnswer: "ليوناردو دا فينشي",
      explanation: "Leonardo da Vinci painted the Mona Lisa in Florence during the Renaissance.",
      arabicExplanation: "رسم الفنان الإيطالي ليوناردو دا فينشي لوحة الموناليزا في القرن السادس عشر خلال عصر النهضة.",
      difficulty: "Medium"
    },
    {
      id: 202,
      question: "Which organ is responsible for pumping blood throughout the human body?",
      arabicQuestion: "ما هو العضو الأساسي المسئول عن ضخ الدم إلى جميع أجزاء جسم الإنسان؟",
      answers: ["Lungs", "Brain", "Heart", "Liver"],
      arabicAnswers: ["الرئتين", "الدماغ", "القلب", "الكبد"],
      correctAnswer: "Heart",
      arabicCorrectAnswer: "القلب",
      explanation: "The heart functions as a muscular pump that forces blood through the circulatory system.",
      arabicExplanation: "يعمل القلب كمضخة عضلية تقوم بدفع وتوزيع الدم في شبكة الأوعية الدموية للجسم بالكامل.",
      difficulty: "Easy"
    },
    {
      id: 203,
      question: "What is the fast storage used by computers to hold temporary running data?",
      arabicQuestion: "ما هي الذاكرة العشوائية السريعة المستخدمة في الكمبيوتر لتخزين البيانات المؤقتة أثناء التشغيل؟",
      answers: ["SSD", "RAM", "CPU", "Hard Drive"],
      arabicAnswers: ["القرص الصلب SSD", "الذاكرة العشوائية RAM", "المعالج CPU", "القرص الصلب HDD"],
      correctAnswer: "RAM",
      arabicCorrectAnswer: "الذاكرة العشوائية RAM",
      explanation: "RAM (Random Access Memory) allows your computer to read and write temporary data super fast.",
      arabicExplanation: "الذاكرة العشوائية (RAM) تتيح للجهاز قراءة وكتابة البيانات المؤقتة بسرعة فائقة لتشغيل التطبيقات بسلاسة.",
      difficulty: "Medium"
    }
  ]
};

// مولد الأسئلة التلقائي لإنشاء 500 مستوى بتصنيفات منوعة وإجابات مبعثرة عشوائياً وبشكل ثابت (Deterministic)
export function getQuestionForLevel(worldId: number, levelNumber: number): Question {
  const curated = CURATED_QUESTIONS[worldId];
  if (curated && curated[levelNumber - 1]) {
    return curated[levelNumber - 1];
  }

  // استخدام تقنية الهش لضمان عدم تغير السؤال عند إعادة الرندرة وثبات الترتيب
  const hash = (worldId * 73) + levelNumber;
  
  const categories = [
    "ثقافة عامة",
    "رياضة",
    "علوم وطبيعة",
    "تقنية وبرمجة",
    "رياضيات وذكاء"
  ];
  const category = categories[hash % categories.length];
  
  let question = "";
  let arabicQuestion = "";
  let answers: string[] = [];
  let arabicAnswers: string[] = [];
  let correctAnswer = "";
  let arabicCorrectAnswer = "";
  let explanation = "";
  let arabicExplanation = "";
  let difficulty: "Easy" | "Medium" | "Hard" = "Easy";

  if (levelNumber > 150) difficulty = "Medium";
  if (levelNumber > 300) difficulty = "Hard";

  if (category === "رياضيات وذكاء") {
    const baseValue = 10 + (hash % 30);
    const multiplier = 2 + (hash % 4);
    
    question = `Solve the puzzle: What is (${baseValue} * ${multiplier}) - 5?`;
    arabicQuestion = `حل المسألة الرياضية التالية: ما ناتج عملية حسابية بسيطة: (${baseValue} × ${multiplier}) - 5؟`;
    
    const result = (baseValue * multiplier) - 5;
    correctAnswer = String(result);
    arabicCorrectAnswer = String(result);
    
    // وضع الإجابات عشوائياً بناء على الـ Hash
    answers = [String(result + 5), String(result - 2), String(result), String(result + 12)];
    arabicAnswers = [...answers];
    
    explanation = `Multiply first: ${baseValue} * ${multiplier} = ${baseValue * multiplier}. Then subtract 5 to get ${result}.`;
    arabicExplanation = `نقوم بالضرب أولاً: ${baseValue} × ${multiplier} = ${baseValue * multiplier}. ثم نطرح 5 ليكون الناتج النهائي ${result}.`;
  } 
  else if (category === "رياضة") {
    const sportsPuzzles = [
      {
        q: "How many gold rings are displayed on the official Olympic flag?",
        aq: "كم عدد الحلقات الملونة المتداخلة التي تظهر على علم الألعاب الأولمبية؟",
        ans: ["4", "5", "6", "7"],
        sans: ["4", "5", "6", "7"],
        c: "5",
        ac: "5",
        exp: "The 5 rings represent the five inhabited continents of the world coming together.",
        aexp: "تمثل الحلقات الخمس قارات العالم الخمس المأهولة بالسكان والاتحاد بينها في المنافسة الرياضية."
      },
      {
        q: "Which country won the historic FIFA World Cup in 2022?",
        aq: "أي منتخب وطني توج بلقب كأس العالم لكرة القدم للرجال عام 2022؟",
        ans: ["France", "Brazil", "Argentina", "Croatia"],
        sans: ["فرنسا", "البرازيل", "الأرجنتين", "كرواتيا"],
        c: "Argentina",
        ac: "الأرجنتين",
        exp: "Argentina won the 2022 World Cup after an epic final match against France.",
        aexp: "فاز المنتخب الأرجنتيني ببطولة كأس العالم 2022 بعد مباراة تاريخية مثيرة ضد منتخب فرنسا."
      }
    ];
    const item = sportsPuzzles[hash % sportsPuzzles.length];
    question = item.q;
    arabicQuestion = item.aq;
    answers = [...item.ans];
    arabicAnswers = [...item.sans];
    correctAnswer = item.c;
    arabicCorrectAnswer = item.ac;
    explanation = item.exp;
    arabicExplanation = item.aexp;
  }
  else if (category === "تقنية وبرمجة") {
    const techPuzzles = [
      {
        q: "What does the abbreviation 'WWW' stand for in website links?",
        aq: "إلى ماذا يرمز الاختصار العالمي المشهور 'WWW' في بداية روابط المواقع الإلكترونية؟",
        ans: ["World Wide Web", "Web World Wave", "Wild Wide Web", "Web Wireless Way"],
        sans: ["شبكة الويب العالمية (World Wide Web)", "موجة العالم الرقمي", "شبكة الاتصال البري", "منفذ الويب اللاسلكي"],
        c: "World Wide Web",
        ac: "شبكة الويب العالمية (World Wide Web)",
        exp: "WWW stands for World Wide Web, invented by Tim Berners-Lee.",
        aexp: "الاختصار يعني شبكة الويب العالمية، وهو النظام العالمي الذي اخترعه تيم بيرنرز لي لتصفح المواقع."
      },
      {
        q: "Which company created the iOS mobile operating system?",
        aq: "ما هي الشركة التكنولوجية العملاقة المطورة لنظام تشغيل الهواتف الذكية iOS؟",
        ans: ["Google", "Microsoft", "Apple", "Samsung"],
        sans: ["جوجل", "مايكروسوفت", "آبل (Apple)", "سامسونج"],
        c: "Apple",
        ac: "آبل (Apple)",
        exp: "Apple designs iOS specifically for its iPhone devices.",
        aexp: "تقوم شركة آبل بتطوير وتصميم نظام التشغيل iOS حصرياً لهواتفها الذكية من نوع آيفون."
      }
    ];
    const item = techPuzzles[hash % techPuzzles.length];
    question = item.q;
    arabicQuestion = item.aq;
    answers = [...item.ans];
    arabicAnswers = [...item.sans];
    correctAnswer = item.c;
    arabicCorrectAnswer = item.ac;
    explanation = item.exp;
    arabicExplanation = item.aexp;
  }
  else if (category === "علوم وطبيعة") {
    const sciencePuzzles = [
      {
        q: "What is the main gas present in the air that humans need to breathe to live?",
        aq: "ما هو الغاز الأساسي المتواجد في الهواء الجوي والذي يحتاجه الإنسان للتنفس للبقاء على قيد الحياة؟",
        ans: ["Carbon Dioxide", "Hydrogen", "Nitrogen", "Oxygen"],
        sans: ["ثاني أكسيد الكربون", "الهيدروجين", "النيتروجين", "الأكسجين"],
        c: "Oxygen",
        ac: "الأكسجين",
        exp: "Oxygen is critical for cellular respiration in human bodies.",
        aexp: "غاز الأكسجين هو المكون الحيوي الذي تمتصه الرئتان لتغذية خلايا الجسم وإنتاج الطاقة."
      },
      {
        q: "Which metal is the best conductor of electricity among common metals?",
        aq: "أي من المعادن التالية يعتبر من أفضل وأقوى الموصلات الكهربائية والمستخدم بكثرة في الأسلاك؟",
        ans: ["Iron", "Copper", "Aluminum", "Lead"],
        sans: ["الحديد", "النحاس", "الألومنيوم", "الرصاص"],
        c: "Copper",
        ac: "النحاس",
        exp: "Copper is highly conductive and flexible, making it ideal for standard wiring.",
        aexp: "يتميز النحاس بقدرته الفائقة على توصيل التيار الكهربائي ومقاومته المنخفضة، لذا يُصنع منه أغلب التوصيلات."
      }
    ];
    const item = sciencePuzzles[hash % sciencePuzzles.length];
    question = item.q;
    arabicQuestion = item.aq;
    answers = [...item.ans];
    arabicAnswers = [...item.sans];
    correctAnswer = item.c;
    arabicCorrectAnswer = item.ac;
    explanation = item.exp;
    arabicExplanation = item.aexp;
  }
  else {
    // ثقافة عامة وتاريخ
    const generalPuzzles = [
      {
        q: "Which device is used to measure temperature accurately?",
        aq: "ما هو الجهاز الطبي والمنزلي المستخدم لقياس درجات الحرارة بدقة؟",
        ans: ["Barometer", "Thermometer", "Speedometer", "Compass"],
        sans: ["الباروميتر", "الترمومتر (الميزان الحراري)", "مقياس السرعة", "البوصلة"],
        c: "Thermometer",
        ac: "الترمومتر (الميزان الحراري)",
        exp: "A thermometer measures thermal energy or heat levels in bodies or rooms.",
        aexp: "الترمومتر هو الأداة المخصصة لرصد مستويات درجة الحرارة والحرارة الحركية للمواد."
      },
      {
        q: "How many months are there in one single calendar year?",
        aq: "كم عدد الشهور التي تتكون منها السنة الميلادية الكاملة؟",
        ans: ["10", "11", "12", "14"],
        sans: ["10 شهور", "11 شهراً", "12 شهراً", "14 شهراً"],
        c: "12",
        ac: "12 شهراً",
        exp: "One standard calendar year consists of 12 distinct months.",
        aexp: "تتكون السنة الشمسية والميلادية المعتمدة عالمياً من اثني عشر شهراً."
      }
    ];
    const item = generalPuzzles[hash % generalPuzzles.length];
    question = item.q;
    arabicQuestion = item.aq;
    answers = [...item.ans];
    arabicAnswers = [...item.sans];
    correctAnswer = item.c;
    arabicCorrectAnswer = item.ac;
    explanation = item.exp;
    arabicExplanation = item.aexp;
  }

  // خوارزمية بعثرة الخيارات عشوائياً (Fisher-Yates) تعتمد على الـ Hash لضمان ثبات أماكن الإجابات للمستوى الواحد
  const shuffleSeed = hash;
  
  const shuffled = [...answers];
  for (let i = shuffled.length - 1; i > 0; i--) {
    const j = (shuffleSeed + i) % (i + 1);
    const temp = shuffled[i];
    shuffled[i] = shuffled[j];
    shuffled[j] = temp;
  }

  const shuffledArabic = [...arabicAnswers];
  for (let i = shuffledArabic.length - 1; i > 0; i--) {
    const j = (shuffleSeed + i) % (i + 1);
    const temp = shuffledArabic[i];
    shuffledArabic[i] = shuffledArabic[j];
    shuffledArabic[j] = temp;
  }

  return {
    id: 2000 + hash,
    question,
    arabicQuestion,
    answers: shuffled,
    arabicAnswers: shuffledArabic,
    correctAnswer,
    arabicCorrectAnswer,
    explanation,
    arabicExplanation,
    difficulty
  };
}

export const SHOP_ITEMS: ShopItem[] = [
  // Avatars
  {
    id: "av_cuphead",
    name: "Cuphead",
    arabicName: "كوبهيد (Cuphead)",
    category: "avatar",
    price: 0,
    description: "The bold, red-clad, gambling cup himself! Default hero.",
    arabicDescription: "البطل الكرتوني كوبهيد، ذو الروح الحماسية والرداء الأحمر الكلاسيكي بروح الثلاثينيات! الشخصية الافتراضية.",
    image: "🔴🥛"
  },
  {
    id: "av_mugman",
    name: "Mugman",
    arabicName: "مجمان (Mugman)",
    category: "avatar",
    price: 150,
    description: "The careful, blue-clad partner of Cuphead. Very lucky!",
    arabicDescription: "شريك كوبهيد الحذر والذكي ذو الرداء الأزرق برسم كرتوني عتيق.",
    image: "🔵🥛"
  },
  {
    id: "av_chalice",
    name: "Ms. Chalice",
    arabicName: "الآنسة شاليس (Ms. Chalice)",
    category: "avatar",
    price: 400,
    description: "A mysterious golden chalice with incredible jumping skills.",
    arabicDescription: "الآنسة شاليس الأنيقة ذات اللون الذهبي والقفزات والمهارات الاستعراضية الرائعة.",
    image: "🟡🏆"
  },
  {
    id: "av_baroness",
    name: "Baroness Von Bon Bon",
    arabicName: "البارونة بون بون",
    category: "avatar",
    price: 800,
    description: "The sweet but chaotic ruler of Sugarland Shimmy.",
    arabicDescription: "حاكمة أرض السكر اللذيذة والغاضبة دائماً.",
    image: "🍬👑"
  },
  {
    id: "av_kingdice",
    name: "King Dice",
    arabicName: "الملك نرد (King Dice)",
    category: "avatar",
    price: 1500,
    description: "The Devil's right-hand man. A real smooth talker!",
    arabicDescription: "المساعد الأول للشيطان وصاحب الابتسامة الخبيثة.",
    image: "🎲🟣"
  },
  {
    id: "av_devil",
    name: "The Devil",
    arabicName: "الشيطان الأكبر (The Devil)",
    category: "avatar",
    price: 3000,
    description: "The master of the underworld himself. Pure vintage chaos!",
    arabicDescription: "سيد الكازينو وصاحب العقود العتيقة الغامضة.",
    image: "😈🔥"
  },

  // Powerups / Hints
  {
    id: "hint_5050",
    name: "50:50 Hint",
    arabicName: "مساعدة 50:50",
    category: "powerup",
    price: 60,
    description: "Removes two incorrect answers from the active level.",
    arabicDescription: "تحذف خيارين خاطئين من السؤال الحالي.",
    image: "✂️"
  },
  {
    id: "hint_reveal",
    name: "Answer Key",
    arabicName: "مفتاح الحل",
    category: "powerup",
    price: 120,
    description: "Instantly reveals the correct answer for the current level.",
    arabicDescription: "تكشف الإجابة الصحيحة فوراً للسؤال الحالي.",
    image: "🔑"
  },
  {
    id: "item_heart",
    name: "Extra Heart Refill",
    arabicName: "تعبئة قلوب إضافية",
    category: "powerup",
    price: 80,
    description: "Restores your hearts to maximum (3 Hearts) instantly.",
    arabicDescription: "تستعيد طاقة القلوب بالكامل (3 قلوب) فوراً.",
    image: "❤️"
  }
];

export const ACHIEVEMENTS: Achievement[] = [
  {
    id: "ach_first_contract",
    name: "First Soul Contract",
    arabicName: "العقد الأول",
    description: "Win your very first level!",
    arabicDescription: "فز بأول مستوى لك في اللعبة!",
    xpReward: 50,
    coinsReward: 30,
    icon: "📜",
    conditionType: "total_levels",
    conditionValue: 1
  },
  {
    id: "ach_novice_gambler",
    name: "Novice Quizzer",
    arabicName: "مغامر مبتدئ",
    description: "Complete 10 levels across any worlds.",
    arabicDescription: "أكمل 10 مستويات بنجاح في أي عوالم.",
    xpReward: 200,
    coinsReward: 100,
    icon: "🎒",
    conditionType: "total_levels",
    conditionValue: 10
  },
  {
    id: "ach_cup_champion",
    name: "Cup Champion",
    arabicName: "بطل الكأس العظيم",
    description: "Complete 50 levels and dominate early worlds.",
    arabicDescription: "أكمل 50 مستوى واكتسح العوالم الأولى.",
    xpReward: 500,
    coinsReward: 300,
    icon: "🏆",
    conditionType: "total_levels",
    conditionValue: 50
  },
  {
    id: "ach_gold_rush",
    name: "Golden Piggybank",
    arabicName: "خزنة الذهب",
    description: "Amass a total of 500 coins in your pocket.",
    arabicDescription: "اجمع ما مجموعه 500 قطعة ذهبية في رصيدك.",
    xpReward: 150,
    coinsReward: 150,
    icon: "💰",
    conditionType: "total_coins",
    conditionValue: 500
  },
  {
    id: "ach_star_lord",
    name: "Constellation Collector",
    arabicName: "جامع النجوم",
    description: "Earn a grand total of 30 stars from quiz victories.",
    arabicDescription: "احصل على 30 نجمة من الانتصارات المتتالية.",
    xpReward: 300,
    coinsReward: 200,
    icon: "⭐",
    conditionType: "total_stars",
    conditionValue: 30
  }
];

export const LEADERBOARD_DATA: LeaderboardEntry[] = [
  { username: "Sally_Stageplay", displayName: "Sally Stageplay", avatar: "🎭", stars: 125, xp: 12500, coins: 4120 },
  { username: "Beppi_The_Clown", displayName: "Beppi The Clown", avatar: "🤡", stars: 112, xp: 11200, coins: 3450 },
  { username: "Cagney_Carnation", displayName: "Cagney Carnation", avatar: "🌻", stars: 95, xp: 9500, coins: 2100 },
  { username: "Grim_Matchstick", displayName: "Grim Matchstick", avatar: "🐉", stars: 82, xp: 8200, coins: 1840 },
  { username: "Baroness_Bon", displayName: "Baroness Von Bon Bon", avatar: "🍬", stars: 74, xp: 7400, coins: 1220 },
  { username: "Mugman_AI", displayName: "Mugman AI", avatar: "🔵🥛", stars: 40, xp: 4000, coins: 850 },
  { username: "Elder_Kettle", displayName: "Elder Kettle", avatar: "🏺", stars: 18, xp: 1800, coins: 400 }
];