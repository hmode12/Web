/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from "react";
import { motion } from "motion/react";
import { audio } from "../audio";
import { SHOP_ITEMS } from "../data";
import { ShopItem, User, GameSettings } from "../types";
import { ArrowLeft, Coins, Check } from "lucide-react";
import CharacterAvatar from "./CharacterAvatar";

interface ShopProps {
  user: User;
  onNavigate: (screen: string) => void;
  onBuyItem: (item: ShopItem) => void;
  settings: GameSettings;
}

export default function Shop({ user, onNavigate, onBuyItem, settings }: ShopProps) {
  const lang = settings.language || "ar";

  const playClick = () => {
    audio.playClick();
  };

  const handlePurchase = (item: ShopItem) => {
    const isAlreadyOwned = user.inventory.includes(item.id) && item.category === "avatar";
    if (isAlreadyOwned) {
      audio.playWrong();
      return;
    }

    if (user.coins >= item.price) {
      audio.playCoin();
      onBuyItem(item);
    } else {
      audio.playWrong();
      alert(lang === "ar" 
        ? "ليس لديك ما يكفي من المال يا صاحبي! فز بالمزيد من المراحل للحصول على عملات ذهبية!" 
        : "You don't have enough dough for this item, pal! Win more quiz stages!"
      );
    }
  };

  return (
    <div className="relative w-full min-h-screen bg-[#F5E6CA] vignette-overlay py-8 px-4 md:px-8 flex flex-col justify-between select-none">
      
      {/* HEADER HUD */}
      <div className="w-full max-w-5xl mx-auto flex justify-between items-center border-b-4 border-black pb-4 mb-6">
        <button
          onClick={() => { playClick(); onNavigate("menu"); }}
          className="cartoon-button text-xs md:text-sm px-4 py-2 flex items-center gap-1 bg-[#5C3D2E] text-white uppercase"
        >
          <ArrowLeft className="w-4 h-4 stroke-[3]" /> {lang === "ar" ? "القائمة" : "Menu"}
        </button>

        <h1 className="text-2xl md:text-4xl font-display text-[#D23A3A] tracking-wide filter drop-shadow-[2px_2px_0_#1a1a1a]">
          {lang === "ar" ? "المتجر العام" : "GENERAL STORE"}
        </h1>

        {/* Live Wallet Counter */}
        <div className="flex items-center gap-2 bg-[#E6D5B3] border-4 border-black px-4 py-1.5 shadow-[3px_3px_0_#1a1a1a] rounded-xl font-display text-lg animate-pulse">
          <span>🪙</span>
          <span className="font-display tracking-tight text-gray-800">{user.coins}</span>
        </div>
      </div>

      {/* SHOP CARDS */}
      <div className="w-full max-w-5xl mx-auto my-auto py-2">
        <div className="text-center mb-8">
          <p className="font-handwritten text-gray-700 max-w-lg mx-auto text-sm md:text-base leading-relaxed">
            {lang === "ar" 
              ? "\"تفضلوا يا سادة! استبدلوا قطعكم الذهبية بأزياء نادرة مرسومة يدوياً أو مساعدات سحرية لتجاوز العقبات!\"" 
              : "\"Step right up, folks! Trade your golden tokens for rare hand-drawn costumes or magic hints to outsmart the Devil's ledger!\""}
          </p>
        </div>

        {/* Shop Items Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {SHOP_ITEMS.map((item: ShopItem) => {
            const isAvatar = item.category === "avatar";
            const isOwned = user.inventory.includes(item.id) && isAvatar;
            const isMaxHearts = item.id === "item_heart" && user.lives >= 3;

            return (
              <motion.div
                key={item.id}
                whileHover={{ scale: 1.02 }}
                className={`relative vintage-paper-panel p-5 rounded-2xl flex flex-col justify-between gap-4 border-4 h-72`}
                style={{ backgroundColor: isOwned ? "#E2F0D9" : "#F5E6CA" }}
              >
                {/* Showcase Mascot / Icon Box */}
                <div className="flex justify-between items-start">
                  <div className="w-16 h-16 bg-white rounded-full border-4 border-black flex items-center justify-center shadow-[2px_2px_0_#1a1a1a] rubber-hose-idle overflow-hidden">
                    {item.category === "avatar" ? (
                      <CharacterAvatar avatar={item.image} size={48} />
                    ) : (
                      <span className="text-4xl">{item.image}</span>
                    )}
                  </div>
                  
                  <span className="font-mono text-[10px] font-bold bg-[#E6D5B3] border-2 border-black px-2 py-0.5 uppercase">
                    {item.category === "avatar" 
                      ? (lang === "ar" ? "شخصية" : "avatar") 
                      : (lang === "ar" ? "مساعدة" : "powerup")}
                  </span>
                </div>

                {/* Info Text */}
                <div>
                  <h3 className="text-lg font-display leading-tight text-gray-900">
                    {lang === "ar" ? item.arabicName : item.name}
                  </h3>
                  {lang === "ar" && (
                    <h4 className="text-xs font-display text-gray-500 leading-tight">
                      {item.name}
                    </h4>
                  )}
                  
                  <p className="font-sans text-xs text-gray-700 leading-tight line-clamp-2 mt-1">
                    {lang === "ar" ? item.arabicDescription : item.description}
                  </p>
                </div>

                {/* Purchase Button / Price footer */}
                <div className="border-t border-black/15 pt-3 mt-auto flex justify-between items-center">
                  {isOwned ? (
                    <div className="flex items-center gap-1 text-emerald-800 font-mono text-xs font-bold uppercase">
                      <Check className="w-4 h-4 text-emerald-800 stroke-[3]" /> {lang === "ar" ? "تم الشراء" : "Owned"}
                    </div>
                  ) : isMaxHearts ? (
                    <div className="text-gray-500 font-mono text-xs font-bold uppercase">
                      {lang === "ar" ? "القلوب ممتلئة" : "Hearts Full"}
                    </div>
                  ) : (
                    <span className="font-display text-[#D23A3A] text-lg">
                      {item.price} 🪙
                    </span>
                  )}

                  {!isOwned && !isMaxHearts && (
                    <button
                      onClick={() => handlePurchase(item)}
                      className="cartoon-button text-xs px-4 py-2 uppercase bg-[#5C3D2E] hover:bg-[#724c3a]"
                    >
                      {lang === "ar" ? "شراء" : "Buy"}
                    </button>
                  )}
                </div>
              </motion.div>
            );
          })}
        </div>
      </div>

      {/* FOOTER */}
      <div className="w-full max-w-5xl mx-auto flex justify-between items-center border-t-4 border-black pt-4 mt-8 text-xs font-mono font-bold text-gray-700 uppercase">
        <span>STORE REEL NO: 405</span>
        <span>Reel: No. 104 • 1930s Film</span>
      </div>

      {/* Retro film scratches */}
      <div className="film-scratch-1"></div>
      <div className="film-scratch-2"></div>
    </div>
  );
}
