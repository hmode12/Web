/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from "react";
import { motion } from "motion/react";
import { audio } from "../audio";
import { WORLDS } from "../data";
import { World, User, GameSettings } from "../types";
import { ArrowLeft, Lock, Star, Sparkles } from "lucide-react";

interface WorldSelectionProps {
  user: User;
  onSelectWorld: (worldId: number) => void;
  onNavigate: (screen: string) => void;
  settings: GameSettings;
}

export default function WorldSelection({ user, onSelectWorld, onNavigate, settings }: WorldSelectionProps) {
  const lang = settings.language || "ar";

  const playClick = () => {
    audio.playClick();
  };

  const getWorldDescription = (world: World, language: string) => {
    if (language !== "ar") return world.description;
    switch (world.id) {
      case 1: return "مروج خضراء هادئة مرسومة يدوياً مع فراشات وزهور كرتونية لطيفة.";
      case 2: return "غابات كثيفة مأهولة بحيوانات برية كرتونية لطيفة مع ضباب حبر سميك.";
      case 3: return "كثبان رملية دافئة، وأنقاض أثرية قديمة، وموجات حرارة كرتونية متحركة.";
      case 4: return "جسور على حافة الجرف، وماعز جبال كرتوني، وشلالات مياه متدفقة.";
      case 5: return "كهوف جليدية منزلقة، وأكواخ دافئة، وندفات ثلج كرتونية تتألق بجمال.";
      case 6: return "فقاعات لافا برتقالية متحركة وغيوم فحم صغيرة لطيفة تتطاير في الأرجاء.";
      case 7: return "مملكة عتيقة مغمورة بالمياه مع شعاب مرجانية ونجم البحر يلوح بيده.";
      case 8: return "جزر عائمة متصلة بجسور قوس قزح الكرتونية التفاعلية الملونة.";
      case 9: return "أشباح كرتونية لطيفة، ولوحات بورتريه قديمة، وشموع تومض بلطف.";
      case 10: return "نجوم متلألئة مرسومة يدوياً بأسلوب الثلاثينيات، وشهب، ومركبات فضائية تقفز.";
      default: return world.description;
    }
  };

  return (
    <div className="relative w-full min-h-screen bg-[#F5E6CA] vignette-overlay py-8 px-4 md:px-8 flex flex-col justify-between select-none">
      
      {/* HEADER HUD */}
      <div className="w-full max-w-5xl mx-auto flex justify-between items-center border-b-4 border-black pb-4 mb-6">
        <button
          onClick={() => { playClick(); onNavigate("menu"); }}
          className="cartoon-button text-xs md:text-sm px-4 py-2 flex items-center gap-1 bg-[#5C3D2E] text-white uppercase"
        >
          <ArrowLeft className="w-4 h-4 stroke-[3]" /> {lang === "ar" ? "القائمة" : "Menu"}
        </button>

        <h1 className="text-2xl md:text-4xl font-display text-[#D23A3A] tracking-wide filter drop-shadow-[2px_2px_0_#1a1a1a]">
          {lang === "ar" ? "خريطة المغامرة" : "WORLD MAP"}
        </h1>

        {/* Stars Display */}
        <div className="flex items-center gap-2 bg-[#E6D5B3] border-4 border-black px-4 py-1.5 shadow-[3px_3px_0_#1a1a1a] rounded-xl font-display">
          <span>⭐</span>
          <span className="font-display tracking-tight text-gray-800">{user.stars}</span>
        </div>
      </div>

      {/* CORE WORLDS CONTAINER */}
      <div className="w-full max-w-5xl mx-auto my-auto">
        <p className="text-center font-handwritten text-gray-700 max-w-xl mx-auto mb-8 text-sm md:text-base">
          {lang === "ar" 
            ? "توسعت جزيرة الحبر إلى عشرة عوالم مجنونة! اجمع النجوم من المستويات السابقة لفتح البوابات." 
            : "\"The Inkwell Isle has expanded into ten crazy landscapes! Collect stars from previous levels to unlock passage through the gates.\""}
        </p>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {WORLDS.map((world: World) => {
            const isUnlocked = user.stars >= world.starsRequiredToUnlock;
            const isUserCurrent = user.currentWorldId === world.id;

            return (
              <motion.div
                key={world.id}
                whileHover={isUnlocked ? { scale: 1.03, rotate: 1 } : {}}
                transition={{ type: "spring", stiffness: 300, damping: 15 }}
                onClick={() => {
                  if (isUnlocked) {
                    playClick();
                    onSelectWorld(world.id);
                  } else {
                    audio.playWrong();
                  }
                }}
                className={`relative vintage-paper-panel p-5 cursor-pointer flex flex-col justify-between gap-4 h-64 rounded-2xl ${
                  isUnlocked 
                    ? "hover:border-[#D23A3A] hover:shadow-[8px_8px_0px_0px_#1A1A1A] transition-all" 
                    : "opacity-75 bg-[#D5C2A5]"
                }`}
                style={{
                  backgroundColor: isUnlocked ? world.bgColor : "#D5C2A5"
                }}
              >
                {/* Decorative particles */}
                {isUnlocked && (
                  <div className="absolute top-2 right-2 text-xl opacity-30 select-none">
                    {world.bgDecorativeElements[0]}
                  </div>
                )}

                {/* World Title & Index */}
                <div>
                  <div className="flex justify-between items-start">
                    <span className="font-mono text-xs font-bold bg-black text-white px-2 py-0.5 rounded uppercase">
                      {lang === "ar" ? `العالم ${world.id}` : `WORLD ${world.id.toString().padStart(2, "0")}`}
                    </span>
                    {isUserCurrent && (
                      <span className="flex items-center gap-1 font-mono text-[9px] font-bold bg-[#D23A3A] text-white px-2 py-0.5 rounded uppercase animate-bounce shadow-sm">
                        <Sparkles className="w-3 h-3 fill-white" /> {lang === "ar" ? "نشط" : "Active"}
                      </span>
                    )}
                  </div>
                  <h2 className="text-2xl font-display mt-2 leading-none" style={{ color: world.accent }}>
                    {lang === "ar" ? world.arabicName : world.name}
                  </h2>
                  {lang === "ar" && (
                    <h3 className="text-sm font-display text-gray-500 leading-tight">
                      {world.name}
                    </h3>
                  )}
                </div>

                {/* Description */}
                <p className="text-xs font-sans font-medium text-gray-800 line-clamp-3">
                  {getWorldDescription(world, lang)}
                </p>

                {/* Lock / Unlocked Status footer */}
                <div className="border-t border-black/10 pt-3 mt-auto flex justify-between items-center">
                  <div className="flex items-center gap-1.5 text-xs font-bold uppercase text-gray-700">
                    {lang === "ar" ? `المستويات ${world.levelsRange[0]} - ${world.levelsRange[1]}` : `Levels ${world.levelsRange[0]} - ${world.levelsRange[1]}`}
                  </div>

                  {isUnlocked ? (
                    <span className="text-xs font-display text-emerald-700 uppercase flex items-center gap-1">
                      {lang === "ar" ? "🟢 العب الآن" : "🟢 PLAY NOW"}
                    </span>
                  ) : (
                    <div className="flex items-center gap-1 font-mono text-xs font-bold text-red-700 bg-red-100 border-2 border-red-700 px-2.5 py-1 rounded">
                      <Lock className="w-3.5 h-3.5 stroke-[2.5]" />
                      <span>{lang === "ar" ? `${world.starsRequiredToUnlock} نجمة مطلوبة` : `${world.starsRequiredToUnlock} ⭐ REQUIRED`}</span>
                    </div>
                  )}
                </div>

                {/* Dark overlay for locked world */}
                {!isUnlocked && (
                  <div className="absolute inset-0 bg-black/10 rounded-2xl flex items-center justify-center backdrop-blur-[0.5px]">
                    <div className="w-14 h-14 bg-white/95 rounded-full border-4 border-black flex items-center justify-center shadow-[4px_4px_0_rgba(0,0,0,1)]">
                      <Lock className="w-6 h-6 text-black" />
                    </div>
                  </div>
                )}
              </motion.div>
            );
          })}
        </div>
      </div>

      {/* FOOTER */}
      <div className="w-full max-w-5xl mx-auto flex justify-between items-center border-t-4 border-black pt-4 mt-8 text-xs font-mono font-bold text-gray-700 uppercase">
        <span>Map Version 1.0</span>
        <span>Reel: No. 104 • 1930s Film</span>
      </div>

      {/* Retro film scratches */}
      <div className="film-scratch-1"></div>
      <div className="film-scratch-2"></div>
    </div>
  );
}
