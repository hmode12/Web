import React from "react";
import { motion } from "motion/react";
import { audio } from "../audio";
import { Question, GameSettings } from "../types";
import { ArrowLeft, Play, RotateCcw, Star } from "lucide-react";

interface ResultScreenProps {
  correct: boolean;
  speedBonus: boolean;
  usedReveal: boolean;
  question: Question;
  coinsEarned: number;
  xpEarned: number;
  starsEarned: number;
  livesRemaining: number;
  onNextLevel: () => void;
  onRetry: () => void;
  onBackToLevels: () => void;
  settings: GameSettings;
}

export default function ResultScreen({
  correct,
  speedBonus,
  usedReveal,
  question,
  coinsEarned,
  xpEarned,
  starsEarned,
  livesRemaining,
  onNextLevel,
  onRetry,
  onBackToLevels,
  settings
}: ResultScreenProps) {
  const playClick = () => {
    audio.playClick();
  };

  const lang = settings.language || "ar";

  return (
    <div className="relative w-full min-h-screen bg-[#F5E6CA] vignette-overlay py-10 px-4 md:px-8 flex flex-col justify-center items-center select-none">
      
      {/* Dynamic Background clouds / particles */}
      <div className="absolute inset-0 pointer-events-none opacity-10 overflow-hidden">
        <div className="absolute top-12 left-10 text-9xl">🎈</div>
        <div className="absolute bottom-12 right-10 text-9xl">🎺</div>
      </div>

      <motion.div
        initial={{ scale: 0.8, rotate: -2, opacity: 0 }}
        animate={{ scale: 1, rotate: 0, opacity: 1 }}
        transition={{ type: "spring", damping: 12 }}
        className="vintage-paper-panel max-w-xl w-full p-6 md:p-8 flex flex-col items-center gap-6 z-10"
      >
        {correct ? (
          /* ================= VICTORY SCREEN ================= */
          <>
            <div className="text-xs font-mono tracking-widest text-emerald-800 border-b-2 border-emerald-800 pb-2 mb-2 w-full uppercase text-center font-bold">
              {lang === "ar" ? "★ تم اجتياز المرحلة - تقييم ممتاز ★" : "★ STAGE DEFEATED - A PERFECT GRADE ★"}
            </div>

            {/* YOU WON BANNER */}
            <h1 
              className="text-5xl md:text-6xl font-display text-[#5BB381] tracking-wide text-center filter drop-shadow-[3px_3px_0px_#1A1A1A]"
              style={{ WebkitTextStroke: "2px #1A1A1A" }}
            >
              {lang === "ar" ? "لقد فزت!" : "YOU WON!"}
            </h1>

            {/* Stars display with animation */}
            <div className="flex gap-2 my-2">
              {[1, 2, 3].map((starIdx) => {
                const isActive = starIdx <= starsEarned;
                return (
                  <motion.div
                    key={starIdx}
                    initial={{ scale: 0 }}
                    animate={{ scale: 1 }}
                    transition={{ delay: 0.2 * starIdx, type: "spring" }}
                  >
                    <Star
                      className={`w-12 h-12 ${
                        isActive
                          ? "fill-amber-400 text-black stroke-[2] animate-star-pop"
                          : "text-gray-300 fill-gray-200 opacity-20"
                      }`}
                    />
                  </motion.div>
                );
              })}
            </div>

            {/* Rewards Display (Coins, XP) */}
            <div className="grid grid-cols-2 gap-4 w-full p-4 bg-[#E6D5B3] border-4 border-black rounded-xl shadow-[3px_3px_0_#1a1a1a]">
              <div className="flex flex-col items-center justify-center p-2 border-r-2 border-dashed border-black/20">
                <span className="text-3xl">🪙</span>
                <span className="font-display text-xl text-gray-800 mt-1">+{coinsEarned} {lang === "ar" ? "قطع" : "Coins"}</span>
                <span className="text-[10px] font-mono font-bold text-gray-600 uppercase">
                  {lang === "ar" ? "حقيبة الغنائم" : "Loot Bag"}
                </span>
              </div>

              <div className="flex flex-col items-center justify-center p-2">
                <span className="text-3xl">✨</span>
                <span className="font-display text-xl text-gray-800 mt-1">+{xpEarned} {lang === "ar" ? "خبرة" : "XP"}</span>
                <span className="text-[10px] font-mono font-bold text-gray-600 uppercase">
                  {lang === "ar" ? "نقاط الخبرة" : "Wisdom Points"}
                </span>
              </div>
            </div>

            {/* Solution Explanation */}
            <div className="w-full text-start bg-white p-4 border-4 border-black rounded-xl shadow-[2px_2px_0_#1a1a1a]">
              <h4 className="font-display text-xs text-[#D23A3A] mb-1 uppercase">
                {lang === "ar" ? "الحل والتوضيح الكرتوني:" : "Solution & Fact:"}
              </h4>
              <p className="font-handwritten text-xs md:text-sm text-gray-800 leading-relaxed">
                "{lang === "ar" && question.arabicExplanation ? question.arabicExplanation : question.explanation}"
              </p>
            </div>

            {/* Speed bonus bubble */}
            {speedBonus && (
              <span className="text-xs font-mono font-bold text-amber-700 bg-amber-50 border border-amber-700 px-3 py-1 rounded-full animate-pulse uppercase">
                {lang === "ar" ? "⚡ تم تطبيق مكافأة السرعة (+50 نقطة!) ⚡" : "⚡ Speed Bonus Applied (+50 XP!) ⚡"}
              </span>
            )}

            {/* Victory controls */}
            <div className="flex flex-col sm:flex-row gap-3 w-full mt-2">
              <button
                onClick={() => { playClick(); onBackToLevels(); }}
                className="cartoon-button col-span-1 text-base p-3 flex-1 flex items-center justify-center gap-1 bg-[#5C3D2E] text-white"
              >
                <ArrowLeft className="w-5 h-5 stroke-[2.5]" /> {lang === "ar" ? "مسار الخريطة" : "Map Path"}
              </button>

              <button
                onClick={() => { playClick(); onNextLevel(); }}
                className="cartoon-button text-base p-3 flex-1 flex items-center justify-center gap-1 bg-[#D23A3A]"
              >
                <Play className="w-5 h-5 stroke-[2.5]" /> {lang === "ar" ? "المرحلة التالية" : "Next Stage"}
              </button>
            </div>
          </>
        ) : (
          /* ================= DEFEAT SCREEN ================= */
          <>
            <div className="text-xs font-mono tracking-widest text-red-800 border-b-2 border-red-800 pb-2 mb-2 w-full uppercase text-center font-bold">
              {lang === "ar" ? "★ هزيمة - عاد العقد للشيطان! ★" : "★ DEFEAT - THE DEVIL TAKES A CONTRACT ★"}
            </div>

            {/* YOU CRASHED BANNER */}
            <h1 
              className="text-5xl md:text-6xl font-display text-[#D23A3A] tracking-wide text-center filter drop-shadow-[3px_3px_0px_#1A1A1A]"
              style={{ WebkitTextStroke: "2px #1A1A1A" }}
            >
              {lang === "ar" ? "خسرت المحاولة!" : "YOU CRASHED!"}
            </h1>

            {/* Skull mascot */}
            <div className="w-24 h-24 bg-red-100 rounded-full border-4 border-black flex items-center justify-center text-5xl shadow-[3px_3px_0_#1a1a1a] rubber-hose-idle-fast">
              💀
            </div>

            <p className="font-handwritten text-center text-gray-800 text-sm max-w-sm">
              {lang === "ar" 
                ? "\"تحطمت كوابيسك أمام هذا اللغز! امسح دموعك وحاول مجدداً!\"" 
                : "\"Your head got cracked open on that puzzle! Wipe off that spilled milk and try again!\""}
            </p>

            {/* Explanation box explaining correct answer */}
            <div className="w-full text-center bg-red-50 p-4 border-4 border-black rounded-xl shadow-[2px_2px_0_#1a1a1a]">
              <span className="font-mono text-[10px] font-bold text-red-800 uppercase block mb-1">
                {lang === "ar" ? "تلميح... الإجابة الصحيحة كانت:" : "Psst... Here is the Correct Answer:"}
              </span>
              <p className="font-sans font-bold text-base text-black">
                "{lang === "ar" && question.arabicCorrectAnswer ? question.arabicCorrectAnswer : question.correctAnswer}"
              </p>
            </div>

            {/* Lives Remaining indicator */}
            <div className="text-xs font-mono font-bold text-gray-700 uppercase">
              {lang === "ar" 
                ? `القلوب المتبقية: ${livesRemaining > 0 ? "❤️".repeat(livesRemaining) : "نفدت القلوب! 💔"}`
                : `Hearts Remaining: ${livesRemaining > 0 ? "❤️".repeat(livesRemaining) : "OUT OF HEARTS! 💔"}`}
            </div>

            {/* Defeat Controls */}
            <div className="flex flex-col sm:flex-row gap-3 w-full mt-2">
              <button
                onClick={() => { playClick(); onBackToLevels(); }}
                className="cartoon-button text-base p-3 flex-1 flex items-center justify-center gap-1 bg-[#5C3D2E] text-white"
              >
                <ArrowLeft className="w-5 h-5 stroke-[2.5]" /> {lang === "ar" ? "العودة للخريطة" : "Back To Map"}
              </button>

              <button
                onClick={() => {
                  if (livesRemaining > 0) {
                    playClick();
                    onRetry();
                  } else {
                    audio.playWrong();
                    alert(lang === "ar" 
                      ? "نفدت القلوب لديك! اذهب للمتجر العام لشراء تعبئة قلوب أو أدر عجلة الحظ اليومية!" 
                      : "Out of Hearts! Go to the General Store to buy a Refill Heart or spin the Daily Fortune wheel!"
                    );
                  }
                }}
                disabled={livesRemaining <= 0}
                className={`cartoon-button text-base p-3 flex-1 flex items-center justify-center gap-1 bg-[#D23A3A] ${
                  livesRemaining <= 0 ? "opacity-30 cursor-not-allowed" : ""
                }`}
              >
                <RotateCcw className="w-5 h-5 stroke-[2.5]" /> {lang === "ar" ? "حاول مجدداً" : "Try Again"}
              </button>
            </div>
          </>
        )}
      </motion.div>

      {/* Retro film scratches */}
      <div className="film-scratch-1"></div>
      <div className="film-scratch-2"></div>
    </div>
  );
}
