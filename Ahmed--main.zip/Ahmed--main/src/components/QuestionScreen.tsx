/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useRef } from "react";
import { motion } from "motion/react";
import { audio } from "../audio";
import { getQuestionForLevel, WORLDS } from "../data";
import { User, Question, GameSettings } from "../types";
import { ArrowLeft, Heart, Clock, Scissors, Key } from "lucide-react";

interface QuestionScreenProps {
  user: User;
  levelId: number;
  onNavigate: (screen: string) => void;
  onAnswerResult: (correct: boolean, speedBonus: boolean, usedReveal: boolean, question: Question) => void;
  settings: GameSettings;
  deductCoins: (amount: number) => boolean;
}

export default function QuestionScreen({
  user,
  levelId,
  onNavigate,
  onAnswerResult,
  settings,
  deductCoins
}: QuestionScreenProps) {
  const world = WORLDS.find(w => levelId >= w.levelsRange[0] && levelId <= w.levelsRange[1]) || WORLDS[0];
  const question = getQuestionForLevel(world.id, levelId);

  const [timeLeft, setTimeLeft] = useState(30); // 30 seconds limit
  const [disabledAnswers, setDisabledAnswers] = useState<string[]>([]);
  const [revealedAnswer, setRevealedAnswer] = useState<string | null>(null);
  const [shakingHearts, setShakingHearts] = useState(false);
  const [isAnswered, setIsAnswered] = useState(false);

  const timerRef = useRef<any>(null);

  // Sound triggers
  const playClick = () => audio.playClick();

  // Timer loop
  useEffect(() => {
    if (isAnswered) return;

    timerRef.current = setInterval(() => {
      setTimeLeft((prev) => {
        if (prev <= 1) {
          clearInterval(timerRef.current);
          handleTimeOut();
          return 0;
        }
        // Play slight ticking woodblock sound on the last 5 seconds
        if (prev <= 6 && !settings.isMuted) {
          audio.playClick();
        }
        return prev - 1;
      });
    }, 1000);

    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
    };
  }, [levelId, isAnswered]);

  // Keyboard shortcut listener
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (isAnswered) return;
      const key = e.key;
      if (["1", "2", "3", "4"].includes(key)) {
        const idx = parseInt(key) - 1;
        const answersList = (settings.language === "ar" && question.arabicAnswers) ? question.arabicAnswers : question.answers;
        if (idx >= 0 && idx < answersList.length) {
          const selectedAns = answersList[idx];
          if (!disabledAnswers.includes(selectedAns)) {
            handleAnswer(selectedAns);
          }
        }
      }
    };

    window.addEventListener("keydown", handleKeyDown);
    return () => window.removeEventListener("keydown", handleKeyDown);
  }, [question, disabledAnswers, isAnswered, settings.language]);

  const handleTimeOut = () => {
    setIsAnswered(true);
    audio.playHeartLost();
    setShakingHearts(true);
    setTimeout(() => setShakingHearts(false), 500);
    onAnswerResult(false, false, false, question);
  };

  const handleAnswer = (selectedAnswer: string) => {
    if (isAnswered) return;
    setIsAnswered(true);
    if (timerRef.current) clearInterval(timerRef.current);

    const isArabic = settings.language === "ar";
    const isCorrect = isArabic && question.arabicCorrectAnswer
      ? (selectedAnswer === question.arabicCorrectAnswer)
      : (selectedAnswer === question.correctAnswer);

    const speedBonus = timeLeft > 15; // fast answer

    if (isCorrect) {
      audio.playCorrect();
    } else {
      audio.playWrong();
      setShakingHearts(true);
      setTimeout(() => setShakingHearts(false), 500);
    }

    onAnswerResult(isCorrect, speedBonus, revealedAnswer !== null, question);
  };

  // 50:50 powerup logic
  const handleUse5050 = () => {
    if (isAnswered) return;
    playClick();

    // Check if user has coins
    const cost = 60;
    if (deductCoins(cost)) {
      const answersList = (settings.language === "ar" && question.arabicAnswers) ? question.arabicAnswers : question.answers;
      const correctAns = (settings.language === "ar" && question.arabicCorrectAnswer)
        ? question.arabicCorrectAnswer
        : question.correctAnswer;
      // Find two incorrect answers to disable
      const incorrects = answersList.filter(ans => ans !== correctAns);
      // Shuffle incorrects to grab 2
      const toDisable = incorrects.slice(0, 2);
      setDisabledAnswers(toDisable);
      audio.playClick();
    } else {
      audio.playWrong();
    }
  };

  // Answer key reveal logic
  const handleUseReveal = () => {
    if (isAnswered) return;
    playClick();

    const cost = 120;
    if (deductCoins(cost)) {
      const correctAns = (settings.language === "ar" && question.arabicCorrectAnswer)
        ? question.arabicCorrectAnswer
        : question.correctAnswer;
      setRevealedAnswer(correctAns);
      audio.playClick();
    } else {
      audio.playWrong();
    }
  };

  // Category Icon selection
  const getCategoryIcon = () => {
    if (question.question.toLowerCase().includes("math")) return "🧮";
    if (question.question.toLowerCase().includes("cartoon") || question.question.toLowerCase().includes("willie")) return "📽️";
    if (question.question.toLowerCase().includes("wonder") || question.question.toLowerCase().includes("ancient")) return "🏺";
    if (question.question.toLowerCase().includes("star") || question.question.toLowerCase().includes("closest")) return "🚀";
    return "💡";
  };

  const lang = settings.language || "ar";
  const answersToRender = (lang === "ar" && question.arabicAnswers) ? question.arabicAnswers : question.answers;

  return (
    <div className="relative w-full min-h-screen bg-[#F5E6CA] vignette-overlay py-6 px-4 md:px-8 flex flex-col justify-between select-none">
      
      {/* HEADER HUD */}
      <div className="w-full max-w-4xl mx-auto flex justify-between items-center border-b-4 border-black pb-4 mb-4">
        <button
          onClick={() => { playClick(); onNavigate("levels"); }}
          className="cartoon-button text-xs px-3 py-1.5 flex items-center gap-1 bg-[#5C3D2E] text-white uppercase"
        >
          <ArrowLeft className="w-4 h-4 stroke-[3]" /> {lang === "ar" ? "خروج" : "Esc"}
        </button>

        <div className="text-center">
          <span className="font-mono text-[10px] font-bold bg-black text-white px-2 py-0.5 rounded uppercase">
            {lang === "ar" ? world.arabicName : world.name}
          </span>
          <h2 className="text-xl font-display text-gray-800 leading-none mt-1">
            {lang === "ar" ? `المرحلة ${levelId}` : `Stage ${levelId}`}
          </h2>
        </div>

        {/* Shaking Hearts / Lives Bar */}
        <div className={`flex items-center gap-1 bg-[#E6D5B3] border-4 border-black px-3 py-1 shadow-[3px_3px_0_#1a1a1a] rounded-xl ${shakingHearts ? "animate-shake bg-red-100" : ""}`}>
          <Heart className="w-5 h-5 text-red-600 fill-red-600 animate-pulse" />
          <div className="flex gap-0.5">
            {[1, 2, 3].map((heartNum) => (
              <span key={heartNum} className={`text-sm transition-all ${heartNum <= user.lives ? "opacity-100Scale" : "opacity-20"}`}>
                ❤️
              </span>
            ))}
          </div>
        </div>
      </div>

      {/* GAME AREA */}
      <div className="w-full max-w-4xl mx-auto grid grid-cols-1 md:grid-cols-12 gap-6 my-auto items-start">
        
        {/* Left Area: Timer, Question Card & answers */}
        <div className="md:col-span-9 flex flex-col gap-6">
          
          {/* Question Card (Vintage Frame) */}
          <motion.div
            initial={{ y: 20, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            className="vintage-paper-panel p-6 rounded-2xl flex flex-col items-center gap-4 border-4 text-center"
          >
            {/* Timer gauge */}
            <div className="w-full flex items-center justify-between border-b-2 border-dashed border-black/30 pb-3 mb-1">
              <div className="flex items-center gap-1.5 text-sm font-bold uppercase text-gray-700">
                <Clock className="w-4 h-4 text-[#D23A3A] stroke-[2.5]" />
                <span>{lang === "ar" ? "الوقت" : "Timer"}</span>
              </div>
              
              <div className="flex items-center gap-2">
                <div className="w-32 h-3.5 bg-gray-200 border-2 border-black rounded-full overflow-hidden">
                  <div 
                    className={`h-full border-r border-black transition-all duration-1000 ${timeLeft < 10 ? "bg-[#D23A3A]" : "bg-[#F4D160]"}`}
                    style={{ width: `${(timeLeft / 30) * 100}%` }}
                  ></div>
                </div>
                <span className="font-mono text-xs font-bold w-6">{timeLeft}{lang === "ar" ? "ث" : "s"}</span>
              </div>
            </div>

            {/* Illustrated Icon container */}
            <div className="w-20 h-20 bg-[#E6D5B3] rounded-full border-4 border-black flex items-center justify-center text-4xl shadow-[2px_2px_0_#1a1a1a] rubber-hose-idle">
              {getCategoryIcon()}
            </div>

            {/* Question Text */}
            <h1 className="text-xl md:text-2xl font-bold font-sans text-gray-900 leading-snug px-2 max-w-2xl">
              {lang === "ar" && question.arabicQuestion ? question.arabicQuestion : question.question}
            </h1>
          </motion.div>

          {/* Answer Grid */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {answersToRender.map((ans, idx) => {
              const isDisabled = disabledAnswers.includes(ans);
              const isRevealedCorrect = (lang === "ar" && question.arabicCorrectAnswer)
                ? revealedAnswer === question.arabicCorrectAnswer && ans === question.arabicCorrectAnswer
                : revealedAnswer === question.correctAnswer && ans === question.correctAnswer;

              return (
                <motion.button
                  key={ans}
                  disabled={isDisabled || isAnswered}
                  whileHover={!isDisabled && !isAnswered ? { scale: 1.03 } : {}}
                  whileTap={!isDisabled && !isAnswered ? { scale: 0.97 } : {}}
                  onClick={() => handleAnswer(ans)}
                  className={`cartoon-button p-4 text-start font-sans text-base font-bold rounded-2xl flex items-center gap-3 ${
                    isDisabled 
                      ? "bg-zinc-300 text-zinc-500 border-zinc-400 cursor-not-allowed shadow-none scale-95 opacity-40 translate-y-1" 
                      : isRevealedCorrect
                        ? "bg-[#5BB381] text-white border-black scale-105 shadow-[4px_4px_0_rgba(0,0,0,1)] animate-bounce"
                        : "bg-white text-black hover:bg-yellow-50"
                  }`}
                >
                  {/* Option Badge */}
                  <span className="w-8 h-8 rounded-full bg-[#E6D5B3] border-2 border-black flex items-center justify-center text-xs font-display flex-shrink-0">
                    {idx + 1}
                  </span>
                  <span>{ans}</span>
                </motion.button>
              );
            })}
          </div>
        </div>

        {/* Right Area: Cartoon Power-Ups / Help items */}
        <div className="md:col-span-3 flex flex-col gap-4">
          <div className="vintage-paper-panel p-4 rounded-2xl flex flex-col gap-3">
            <h3 className="text-sm font-display text-[#D23A3A] tracking-wider text-center border-b-2 border-black pb-2">
              {lang === "ar" ? "بطاقات المساعدة" : "HELP CARDS"}
            </h3>
            
            {/* 50:50 button */}
            <button
              onClick={handleUse5050}
              disabled={isAnswered || disabledAnswers.length > 0}
              className="cartoon-button p-3 flex flex-col items-center gap-1 text-xs uppercase bg-[#3A8FD2] hover:bg-[#4da6ec] disabled:opacity-40 disabled:scale-100 disabled:cursor-not-allowed"
            >
              <div className="flex items-center gap-1 font-display">
                <Scissors className="w-4 h-4 stroke-[2.5]" />
                <span>{lang === "ar" ? "حذف إجابتين 50:50" : "50:50 Hint"}</span>
              </div>
              <span className="font-mono text-[9px] font-bold text-sky-100">
                {lang === "ar" ? "التكلفة: 60 🪙" : "Cost: 60 🪙"}
              </span>
            </button>

            {/* Reveal correct button */}
            <button
              onClick={handleUseReveal}
              disabled={isAnswered || revealedAnswer !== null}
              className="cartoon-button p-3 flex flex-col items-center gap-1 text-xs uppercase bg-[#5BB381] hover:bg-[#6ed199] disabled:opacity-40 disabled:scale-100 disabled:cursor-not-allowed"
            >
              <div className="flex items-center gap-1 font-display">
                <Key className="w-4 h-4 stroke-[2.5]" />
                <span>{lang === "ar" ? "كشف الإجابة" : "Reveal Key"}</span>
              </div>
              <span className="font-mono text-[9px] font-bold text-emerald-100">
                {lang === "ar" ? "التكلفة: 120 🪙" : "Cost: 120 🪙"}
              </span>
            </button>

            {/* Quick Keyboard Info Card */}
            <div className="text-[10px] font-mono text-gray-600 bg-[#E6D5B3] p-2 rounded-xl border border-black/20 leading-relaxed uppercase">
              {lang === "ar" ? (
                <>
                  ★ اختصارات ★<br />
                  اضغط على [1] أو [2] أو [3] أو [4] من الأرقام للإجابة فوراً!
                </>
              ) : (
                <>
                  ★ HOTKEYS ★<br />
                  Press [1], [2], [3] or [4] keys to shoot answers!
                </>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* FOOTER */}
      <div className="w-full max-w-4xl mx-auto flex justify-between items-center border-t-4 border-black pt-4 mt-4 text-xs font-mono font-bold text-gray-700 uppercase">
        <span>{lang === "ar" ? `المحفظة النشطة: ${user.coins} 🪙` : `Active Wallet: ${user.coins} 🪙`}</span>
        <span>Reel: No. 104 • 1930s Film</span>
      </div>

      {/* Retro film scratches */}
      <div className="film-scratch-1"></div>
      <div className="film-scratch-2"></div>
    </div>
  );
}
