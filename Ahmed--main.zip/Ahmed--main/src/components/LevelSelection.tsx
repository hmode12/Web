/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from "react";
import { motion } from "motion/react";
import { audio } from "../audio";
import { WORLDS } from "../data";
import { User, GameSettings } from "../types";
import { ArrowLeft, Lock, Star } from "lucide-react";

interface LevelSelectionProps {
  user: User;
  worldId: number;
  onSelectLevel: (levelId: number) => void;
  onNavigate: (screen: string) => void;
  settings: GameSettings;
}

export default function LevelSelection({ user, worldId, onSelectLevel, onNavigate, settings }: LevelSelectionProps) {
  const lang = settings.language || "ar";

  const playClick = () => {
    audio.playClick();
  };

  const world = WORLDS.find((w) => w.id === worldId) || WORLDS[0];
  const [startLevel, endLevel] = world.levelsRange;

  // Generate the list of levels (50 levels)
  const levelsList = [];
  for (let lvl = startLevel; lvl <= endLevel; lvl++) {
    levelsList.push(lvl);
  }

  // A level is unlocked if:
  // - It is the first level of the world (lvl === startLevel)
  // - Or the user completed the previous level (lvl - 1 exists in user.completedLevels)
  const isLevelUnlocked = (lvl: number) => {
    if (lvl === startLevel) return true;
    return user.completedLevels[lvl - 1] !== undefined;
  };

  return (
    <div className="relative w-full min-h-screen bg-[#F5E6CA] vignette-overlay py-8 px-4 md:px-8 flex flex-col justify-between select-none">
      
      {/* HEADER HUD */}
      <div className="w-full max-w-5xl mx-auto flex flex-wrap justify-between items-center gap-4 border-b-4 border-black pb-4 mb-6">
        <button
          onClick={() => { playClick(); onNavigate("worlds"); }}
          className="cartoon-button text-xs md:text-sm px-4 py-2 flex items-center gap-1 bg-[#5C3D2E] text-white uppercase"
        >
          <ArrowLeft className="w-4 h-4 stroke-[3]" /> {lang === "ar" ? "الخريطة" : "Map"}
        </button>

        <div className="text-center">
          <h1 className="text-3xl md:text-4xl font-display text-[#D23A3A] leading-none filter drop-shadow-[2px_2px_0_#1a1a1a]">
            {lang === "ar" ? world.arabicName : world.name}
          </h1>
          <span className="font-mono text-xs font-bold text-gray-700">
            {lang === "ar" ? `المستويات ${startLevel} - ${endLevel}` : `LEVELS ${startLevel} - ${endLevel}`}
          </span>
        </div>

        {/* Stars Display */}
        <div className="flex items-center gap-2 bg-[#E6D5B3] border-4 border-black px-4 py-1.5 shadow-[3px_3px_0_#1a1a1a] rounded-xl font-display">
          <span>⭐</span>
          <span className="font-display tracking-tight text-gray-800">{user.stars}</span>
        </div>
      </div>

      {/* CORE PATHWAY */}
      <div className="w-full max-w-5xl mx-auto my-auto py-2">
        <p className="text-center font-handwritten text-gray-700 max-w-lg mx-auto mb-8 text-xs md:text-sm">
          {lang === "ar" 
            ? "اضغط على زر المرحلة لبدء المواجهة. يجب عليك الإجابة بشكل صحيح لفتح الطريق والمطالبة بعقدك الذهبي!" 
            : "\"Tap on a stage button to start your duel. You must answer correctly to clear the road and claim your golden contract!\""}
        </p>

        {/* Grid of level badges */}
        <div className="grid grid-cols-5 sm:grid-cols-6 md:grid-cols-8 lg:grid-cols-10 gap-4 max-h-[60vh] overflow-y-auto p-4 bg-[#E6D5B3] border-4 border-black shadow-[6px_6px_0_#1a1a1a] rounded-2xl vintage-flicker">
          {levelsList.map((lvl) => {
            const unlocked = isLevelUnlocked(lvl);
            const starsEarned = user.completedLevels[lvl] || 0;
            const isActive = user.currentLevelId === lvl;

            return (
              <motion.div
                key={lvl}
                whileHover={unlocked ? { scale: 1.15 } : {}}
                whileTap={unlocked ? { scale: 0.9 } : {}}
                onClick={() => {
                  if (unlocked) {
                    playClick();
                    onSelectLevel(lvl);
                  } else {
                    audio.playWrong();
                  }
                }}
                className={`relative w-14 h-14 rounded-full border-4 border-black flex flex-col items-center justify-center cursor-pointer shadow-[3px_3px_0_rgba(0,0,0,1)] ${
                  unlocked
                    ? isActive
                      ? "bg-[#D23A3A] text-white animate-pulse"
                      : "bg-[#F4D160] hover:bg-[#ffe066] text-[#1A1A1A]"
                    : "bg-zinc-400 text-zinc-600 opacity-60 cursor-not-allowed"
                }`}
              >
                {unlocked ? (
                  <>
                    <span className="font-display text-base leading-none mt-1">{lvl}</span>
                    
                    {/* Tiny Star Badges */}
                    <div className="absolute -bottom-2 flex justify-center gap-0.5">
                      {[1, 2, 3].map((starIdx) => (
                        <Star
                          key={starIdx}
                          className={`w-3.5 h-3.5 ${
                            starIdx <= starsEarned
                              ? "fill-amber-400 text-black stroke-[1.5]"
                              : "text-transparent fill-gray-400 opacity-30"
                          }`}
                        />
                      ))}
                    </div>
                  </>
                ) : (
                  <Lock className="w-5 h-5 text-zinc-700 stroke-[2.5]" />
                )}

                {/* Decorative border if active */}
                {isActive && (
                  <div className="absolute -inset-1.5 border-2 border-dashed border-[#D23A3A] rounded-full animate-spin [animation-duration:8s]"></div>
                )}
              </motion.div>
            );
          })}
        </div>
      </div>

      {/* FOOTER */}
      <div className="w-full max-w-5xl mx-auto flex justify-between items-center border-t-4 border-black pt-4 mt-8 text-xs font-mono font-bold text-gray-700 uppercase">
        <span>
          {lang === "ar" 
            ? `المنجز: ${Object.keys(user.completedLevels).filter(k => parseInt(k) >= startLevel && parseInt(k) <= endLevel).length} / 50` 
            : `Completed: ${Object.keys(user.completedLevels).filter(k => parseInt(k) >= startLevel && parseInt(k) <= endLevel).length} / 50`}
        </span>
        <span>Reel: No. 104 • 1930s Film</span>
      </div>

      {/* Retro film scratches */}
      <div className="film-scratch-1"></div>
      <div className="film-scratch-2"></div>
    </div>
  );
}
