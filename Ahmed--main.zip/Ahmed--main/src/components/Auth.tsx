/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from "react";
import { motion } from "motion/react";
import { audio } from "../audio";
import { User, GameSettings } from "../types";
import { t } from "../utils/i18n";

interface AuthProps {
  onAuthSuccess: (user: User) => void;
  settings: GameSettings;
}

export default function Auth({ onAuthSuccess, settings }: AuthProps) {
  const [isLogin, setIsLogin] = useState(true);
  const [username, setUsername] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [isAdminMode, setIsAdminMode] = useState(false);
  const [adminCode, setAdminCode] = useState("");
  const [error, setError] = useState("");

  const lang = settings.language || "ar";

  const playClick = () => {
    audio.playClick();
  };

  const validateEmail = (mail: string) => {
    return /\S+@\S+\.\S+/.test(mail);
  };

  const handleGuest = () => {
    playClick();
    // Create default guest user
    const guestUser: User = {
      username: "Guest_" + Math.floor(1000 + Math.random() * 9000),
      email: "guest@laraquiz.com",
      displayName: lang === "ar" ? "مغامر محظوظ" : "Lucky Mug",
      avatar: "🔴🥛",
      coins: 100,
      xp: 0,
      stars: 0,
      lives: 3,
      lastHeartRestoreTime: Date.now(),
      currentWorldId: 1,
      currentLevelId: 1,
      unlockedWorlds: [1],
      completedLevels: {},
      inventory: ["av_cuphead"],
      achievementsCompleted: [],
      dailyStreak: 0,
      lastDailyClaimTime: 0,
      role: "Guest",
    };
    onAuthSuccess(guestUser);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    playClick();
    setError("");

    if (!username || !password) {
      setError(lang === "ar" ? "املأ جميع الفراغات يا بطل الحبر!" : "Fill in all the ink blanks, pal!");
      audio.playWrong();
      return;
    }

    if (!isLogin && !email) {
      setError(lang === "ar" ? "البريد الإلكتروني مطلوب للتسجيل!" : "An email address is required to register!");
      audio.playWrong();
      return;
    }

    if (!isLogin && !validateEmail(email)) {
      setError(lang === "ar" ? "هذا البريد الإلكتروني لا يبدو حقيقياً!" : "That email doesn't look like real print!");
      audio.playWrong();
      return;
    }

    // Role check
    let userRole: "Player" | "Admin" = "Player";
    if (isAdminMode) {
      if (adminCode === "laraquiz1930") {
        userRole = "Admin";
      } else {
        setError(lang === "ar" ? "رمز السر غير صحيح! حاول مجدداً." : "Invalid Admin Secret Key! Try again.");
        audio.playWrong();
        return;
      }
    }

    // Create / Load user
    const mockUser: User = {
      username,
      email: email || `${username}@laraquiz.com`,
      displayName: username.charAt(0).toUpperCase() + username.slice(1),
      avatar: userRole === "Admin" ? "😈🔥" : "🔴🥛",
      coins: userRole === "Admin" ? 9999 : 100,
      xp: 0,
      stars: 0,
      lives: 3,
      lastHeartRestoreTime: Date.now(),
      currentWorldId: 1,
      currentLevelId: 1,
      unlockedWorlds: [1],
      completedLevels: {},
      inventory: ["av_cuphead"],
      achievementsCompleted: [],
      dailyStreak: 1,
      lastDailyClaimTime: Date.now() - 86400000, // available soon
      role: userRole,
    };

    // Save registered user locally
    localStorage.setItem(`user_${username}`, JSON.stringify(mockUser));
    onAuthSuccess(mockUser);
  };

  return (
    <div className="relative w-full h-screen flex flex-col justify-center items-center bg-[#F5E6CA] vignette-overlay px-4">
      {/* Dynamic Animated Background Cloud */}
      <div className="absolute top-10 left-0 right-0 h-24 overflow-hidden pointer-events-none opacity-20">
        <div className="cartoon-cloud text-6xl text-[#1A1A1A] absolute">☁️</div>
        <div className="cartoon-cloud text-7xl text-[#1A1A1A] absolute [animation-delay:12s]">☁️</div>
      </div>

      <motion.div
        layout
        className="vintage-paper-panel max-w-md w-full p-6 md:p-8 z-10"
      >
        {/* Paper Headers */}
        <div className="flex justify-between items-center border-b-4 border-black pb-4 mb-6">
          <h2 className="text-2xl font-display uppercase tracking-tight text-[#1A1A1A]">
            {isLogin ? t("auth.title", lang) : (lang === "ar" ? "بوابة توقيع العقد الجديد" : "New Contract Sign")}
          </h2>
          <div className="text-xs font-mono font-bold bg-[#E6D5B3] px-2 py-1 border-2 border-black">
            LARAQUIZ CO.
          </div>
        </div>

        {/* Error Dialog */}
        {error && (
          <motion.div
            initial={{ scale: 0.9, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            className="mb-4 p-3 bg-[#D23A3A] border-4 border-black text-white font-bold text-sm text-center shadow-[2px_2px_0_#1a1a1a] animate-shake"
          >
            ⚠️ {error}
          </motion.div>
        )}

        {/* Form elements */}
        <form onSubmit={handleSubmit} className="flex flex-col gap-4 font-sans">
          <div>
            <label className="block text-sm font-bold uppercase mb-1">
              {lang === "ar" ? "اسم المغامر المستعار" : "Username / Moniker"}
            </label>
            <input
              type="text"
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              className="w-full p-2.5 bg-white border-4 border-black text-black font-bold focus:outline-none focus:bg-[#FFFDF4] placeholder-gray-500 shadow-[2px_2px_0_#1a1a1a]"
              placeholder={lang === "ar" ? "مثال: كوبهيد" : "e.g. CupheadKid"}
            />
          </div>

          {!isLogin && (
            <div>
              <label className="block text-sm font-bold uppercase mb-1">
                {lang === "ar" ? "البريد الإلكتروني (اختياري)" : "Email Address (Optional)"}
              </label>
              <input
                type="text"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="w-full p-2.5 bg-white border-4 border-black text-black font-bold focus:outline-none focus:bg-[#FFFDF4] placeholder-gray-500 shadow-[2px_2px_0_#1a1a1a]"
                placeholder="e.g. adventurer@gmail.com"
              />
            </div>
          )}

          <div>
            <label className="block text-sm font-bold uppercase mb-1">
              {lang === "ar" ? "كلمة المرور" : "Password"}
            </label>
            <input
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="w-full p-2.5 bg-white border-4 border-black text-black font-bold focus:outline-none focus:bg-[#FFFDF4] placeholder-gray-500 shadow-[2px_2px_0_#1a1a1a]"
              placeholder="••••••••"
            />
          </div>

          {/* Admin Toggle */}
          <div className="border-t-2 border-dashed border-black/30 pt-3 mt-1">
            <label className="flex items-center gap-2 cursor-pointer select-none">
              <input
                type="checkbox"
                checked={isAdminMode}
                onChange={(e) => {
                  playClick();
                  setIsAdminMode(e.target.checked);
                }}
                className="w-5 h-5 accent-[#D23A3A] border-4 border-black rounded-none"
              />
              <span className="text-sm font-bold uppercase">
                {lang === "ar" ? "الدخول كمسؤول للنظام / Admin" : "Sign in as Administrator"}
              </span>
            </label>

            {isAdminMode && (
              <motion.div
                initial={{ height: 0, opacity: 0 }}
                animate={{ height: "auto", opacity: 1 }}
                className="mt-2"
              >
                <label className="block text-xs font-bold uppercase text-[#D23A3A] mb-1">
                  {lang === "ar" ? "كلمة سر المسؤول (تلميح: laraquiz1930)" : "Admin Passcode (Hint: laraquiz1930)"}
                </label>
                <input
                  type="password"
                  value={adminCode}
                  onChange={(e) => setAdminCode(e.target.value)}
                  className="w-full p-2 bg-white border-2 border-[#D23A3A] text-black font-mono focus:outline-none focus:bg-[#FFFDF4]"
                  placeholder="laraquiz1930"
                />
              </motion.div>
            )}
          </div>

          <motion.button
            whileHover={{ scale: 1.02 }}
            whileTap={{ scale: 0.98 }}
            type="submit"
            className="cartoon-button text-xl py-3 mt-2 uppercase tracking-wide bg-[#D23A3A] hover:bg-[#e54b4b]"
          >
            {isLogin 
              ? (lang === "ar" ? "توقيع العقد والدخول" : "Sign the Contract & Enter")
              : (lang === "ar" ? "توقيع وتعميد العقد" : "Sign & Register")}
          </motion.button>
        </form>

        {/* Tab switcher */}
        <div className="mt-4 flex justify-between items-center text-sm font-bold border-t-2 border-black/20 pt-4">
          <button
            onClick={() => {
              playClick();
              setIsLogin(!isLogin);
              setError("");
            }}
            className="text-gray-800 hover:text-black hover:underline cursor-pointer"
          >
            {isLogin 
              ? (lang === "ar" ? "ليس لديك عقد؟ سجل حساباً جديداً" : "Need a contract? Create Account")
              : (lang === "ar" ? "لديك عقد بالفعل؟ سجل دخولك" : "Already have a contract? Sign In")}
          </button>
        </div>

        {/* Guest Alternative */}
        <div className="mt-3">
          <button
            onClick={handleGuest}
            className="w-full text-center py-2 border-4 border-dashed border-black hover:bg-[#E6D5B3] font-sans font-bold uppercase text-xs tracking-wider cursor-pointer"
          >
            {lang === "ar" ? "🎲 الدخول كزائر سريع (بدون عقد) 🎲" : "🎲 Play as Guest / Skip Contract 🎲"}
          </button>
        </div>
      </motion.div>

      {/* Scratches */}
      <div className="film-scratch-1"></div>
      <div className="film-scratch-2"></div>
    </div>
  );
}
