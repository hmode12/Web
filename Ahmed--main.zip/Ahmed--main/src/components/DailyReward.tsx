/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from "react";
import { motion } from "motion/react";
import { audio } from "../audio";
import { User, GameSettings } from "../types";
import { ArrowLeft, Gift, RefreshCw } from "lucide-react";

interface DailyRewardProps {
  user: User;
  onNavigate: (screen: string) => void;
  onClaimReward: (rewardType: "coins" | "xp" | "hearts", amount: number) => void;
  settings: GameSettings;
}

export default function DailyReward({ user, onNavigate, onClaimReward, settings }: DailyRewardProps) {
  const lang = settings.language || "ar";

  const [isSpinning, setIsSpinning] = useState(false);
  const [hasSpun, setHasSpun] = useState(false);
  const [prizeIndex, setPrizeIndex] = useState<number | null>(null);
  const [timeLeftStr, setTimeLeftStr] = useState("");

  const playClick = () => {
    audio.playClick();
  };

  const prizes = [
    { type: "coins", amount: 100, label: "100 COINS 🪙", labelAr: "100 قطعة ذهبية 🪙" },
    { type: "xp", amount: 150, label: "150 XP ✨", labelAr: "150 نقطة خبرة ✨" },
    { type: "coins", amount: 250, label: "250 COINS 🪙", labelAr: "250 قطعة ذهبية 🪙" },
    { type: "hearts", amount: 1, label: "MAX HEARTS ❤️", labelAr: "القلوب كاملة ❤️" },
    { type: "coins", amount: 500, label: "500 COINS (JACKPOT!) 🏆", labelAr: "500 قطعة (الجائزة الكبرى!) 🏆" },
    { type: "xp", amount: 50, label: "50 XP 🎓", labelAr: "50 نقطة خبرة 🎓" }
  ];

  // Check cooldown: 24 hours (86400000 ms)
  const COOLDOWN_MS = 86400000;
  const nextClaimTime = user.lastDailyClaimTime + COOLDOWN_MS;
  const isEligible = Date.now() >= nextClaimTime;

  // Countdown timer loop
  useEffect(() => {
    if (isEligible) return;

    const timer = setInterval(() => {
      const diff = nextClaimTime - Date.now();
      if (diff <= 0) {
        setIsEligibleTrue();
        clearInterval(timer);
      } else {
        const hours = Math.floor(diff / 3600000);
        const mins = Math.floor((diff % 3600000) / 60000);
        const secs = Math.floor((diff % 60000) / 1000);
        setTimeLeftStr(
          `${hours.toString().padStart(2, "0")}:${mins
            .toString()
            .padStart(2, "0")}:${secs.toString().padStart(2, "0")}`
        );
      }
    }, 1000);

    return () => clearInterval(timer);
  }, [user.lastDailyClaimTime, isEligible]);

  const setIsEligibleTrue = () => {
    // Just re-triggers re-evaluation of component
  };

  const handleSpin = () => {
    if (!isEligible || isSpinning) return;
    
    playClick();
    setIsSpinning(true);

    // Pick a deterministic prize but looking random
    const randomIndex = Math.floor(Math.random() * prizes.length);
    setPrizeIndex(randomIndex);

    // Play spinning audio loop
    let ticks = 0;
    const soundInterval = setInterval(() => {
      audio.playClick();
      ticks++;
      if (ticks >= 15) clearInterval(soundInterval);
    }, 150);

    // Stop spin after 3 seconds (3000 ms)
    setTimeout(() => {
      setIsSpinning(false);
      setHasSpun(true);
      
      const chosenPrize = prizes[randomIndex];
      
      // Play reward audio
      if (chosenPrize.type === "coins") {
        audio.playCoin();
      } else {
        audio.playLevelWin();
      }

      // Callback to claim
      onClaimReward(
        chosenPrize.type as "coins" | "xp" | "hearts",
        chosenPrize.amount
      );
    }, 3000);
  };

  return (
    <div className="relative w-full min-h-screen bg-[#F5E6CA] vignette-overlay py-8 px-4 md:px-8 flex flex-col justify-between select-none">
      
      {/* HEADER HUD */}
      <div className="w-full max-w-5xl mx-auto flex justify-between items-center border-b-4 border-black pb-4 mb-6">
        <button
          onClick={() => { playClick(); onNavigate("menu"); }}
          className="cartoon-button text-xs md:text-sm px-4 py-2 flex items-center gap-1 bg-[#5C3D2E] text-white uppercase"
        >
          <ArrowLeft className="w-4 h-4 stroke-[3]" /> {lang === "ar" ? "القائمة" : "Menu"}
        </button>

        <h1 className="text-2xl md:text-4xl font-display text-[#D23A3A] tracking-wide filter drop-shadow-[2px_2px_0_#1a1a1a]">
          {lang === "ar" ? "عجلة الحظ اليومية" : "DAILY SPIN"}
        </h1>

        <div className="flex items-center gap-1.5 bg-[#E6D5B3] border-4 border-black px-3 py-1 shadow-[2px_2px_0_#1a1a1a] rounded-xl text-xs font-mono font-bold uppercase">
          <Gift className="w-4 h-4 text-emerald-700 animate-bounce" /> {lang === "ar" ? "غنائم مجانية" : "Free Loot"}
        </div>
      </div>

      {/* CORE WHEEL */}
      <div className="w-full max-w-4xl mx-auto my-auto grid grid-cols-1 md:grid-cols-12 gap-8 items-center">
        
        {/* Left Side: The Spinning Wheel */}
        <div className="md:col-span-6 flex flex-col items-center justify-center">
          <div className="relative w-64 h-64 md:w-80 md:h-80 rounded-full border-8 border-black shadow-[8px_8px_0_rgba(0,0,0,1)] bg-white overflow-hidden flex items-center justify-center">
            
            {/* Spinning Dial Panel */}
            <motion.div
              animate={
                isSpinning
                  ? { rotate: 360 * 5 + (prizeIndex !== null ? (prizeIndex * 60) : 0) }
                  : prizeIndex !== null
                  ? { rotate: prizeIndex * 60 }
                  : { rotate: 0 }
              }
              transition={
                isSpinning
                  ? { duration: 3, ease: "circOut" }
                  : { duration: 0 }
              }
              className="absolute w-full h-full rounded-full flex items-center justify-center"
              style={{
                backgroundImage: `conic-gradient(
                  #D23A3A 0deg 60deg,
                  #3A8FD2 60deg 120deg,
                  #F4D160 120deg 180deg,
                  #5BB381 180deg 240deg,
                  #5C3D2E 240deg 300deg,
                  #9B59B6 300deg 360deg
                )`
              }}
            >
              {/* Prize texts inside wedges */}
              {prizes.map((p, idx) => (
                <div
                  key={idx}
                  className="absolute text-[10px] md:text-xs font-display text-white tracking-tighter"
                  style={{
                    transform: `rotate(${idx * 60 + 30}deg) translateY(-80px) md:translateY(-100px)`,
                    textShadow: "1px 1px 0px #1a1a1a"
                  }}
                >
                  {p.type === "coins" ? "🪙" : p.type === "hearts" ? "❤️" : "✨"}
                </div>
              ))}
            </motion.div>

            {/* Central Pin */}
            <div className="absolute w-12 h-12 bg-white rounded-full border-4 border-black z-10 flex items-center justify-center shadow-[2px_2px_0_rgba(0,0,0,0.3)]">
              <span className="text-xl">🎯</span>
            </div>

            {/* Red pointer peg on top */}
            <div className="absolute top-0 w-0 h-0 border-l-[12px] border-l-transparent border-r-[12px] border-r-transparent border-t-[20px] border-t-black z-20"></div>
          </div>
        </div>

        {/* Right Side: Ticket Controls & Claim message */}
        <div className="md:col-span-6 flex flex-col gap-5 text-center md:text-left">
          <div className="vintage-paper-panel p-6 rounded-2xl border-4 shadow-[4px_4px_0_rgba(0,0,0,1)]">
            <h2 className="text-2xl font-display text-[#D23A3A] tracking-tight leading-none mb-1">
              {lang === "ar" ? "بكرة الكرنفال السحرية" : "THE CARNIVAL REEL"}
            </h2>
            <p className="font-sans text-xs text-gray-800 leading-relaxed mb-4">
              {lang === "ar" 
                ? "\"تفضلوا يا سادة! أدر عجلة حظ كب-هيد الكرنفالية واخرج غنياً بالجوائز! دورة مجانية واحدة متاحة يومياً لجميع المغامرين.\"" 
                : "\"Roll up, roll up! Spin the Wheel of Cuphead Fortune and walk away a rich man! One spin every day is free for all adventurers.\""}
            </p>

            {isEligible ? (
              <div className="flex flex-col gap-3">
                <button
                  onClick={handleSpin}
                  disabled={isSpinning}
                  className="cartoon-button text-base md:text-xl py-4 bg-[#D23A3A] text-white hover:bg-[#e54b4b] uppercase flex items-center justify-center gap-2"
                >
                  <RefreshCw className={`w-5 h-5 ${isSpinning ? "animate-spin" : ""}`} />
                  {isSpinning 
                    ? (lang === "ar" ? "جاري تدوير البكرة!..." : "Spinning Reel!...") 
                    : (lang === "ar" ? "أدر العجلة مجاناً" : "Spin Free Wheel")}
                </button>
              </div>
            ) : (
              <div className="bg-[#E6D5B3] p-4 border-4 border-dashed border-black/40 rounded-xl text-center">
                <span className="text-xl">⏳</span>
                <h4 className="font-display text-sm mt-1 mb-0.5 text-gray-800">
                  {lang === "ar" ? "فترة انتظار إعادة الشحن" : "COOLDOWN IN EFFECT"}
                </h4>
                <div className="font-mono text-xl font-bold text-[#D23A3A] tracking-wider my-1">
                  {timeLeftStr || "24:00:00"}
                </div>
                <p className="font-handwritten text-[10px] text-gray-600 uppercase">
                  {lang === "ar" 
                    ? "\"ستتوفر الدورة التالية عندما يصل العداد إلى الصفر!\"" 
                    : "\"Next fortune coin loads when the timer strikes zero!\""}
                </p>
              </div>
            )}

            {/* Claimed overlay notification */}
            {hasSpun && prizeIndex !== null && (
              <motion.div
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                className="mt-4 p-3 bg-[#E2F0D9] border-4 border-black rounded-lg text-center font-bold text-emerald-800 text-sm shadow-md animate-bounce"
              >
                {lang === "ar" 
                  ? `🎉 تم الحصول على الجائزة: ${prizes[prizeIndex].labelAr}!` 
                  : `🎉 CLAIMED PRIZE: ${prizes[prizeIndex].label}!`}
              </motion.div>
            )}
          </div>
        </div>
      </div>

      {/* FOOTER */}
      <div className="w-full max-w-5xl mx-auto flex justify-between items-center border-t-4 border-black pt-4 mt-8 text-xs font-mono font-bold text-gray-700 uppercase">
        <span>{lang === "ar" ? "التذكرة اليومية: تم الاستخدام" : "Daily ticket: claimed today"}</span>
        <span>Reel: No. 104 • 1930s Film</span>
      </div>

      {/* Retro film scratches */}
      <div className="film-scratch-1"></div>
      <div className="film-scratch-2"></div>
    </div>
  );
}
