/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useEffect } from "react";
// استخدام مسار صريح ومباشر لملف الصوت لتفادي مشاكل الـ Resolve في بيئات التشغيل المختلفة
import { audio } from "../audio";
import { GameSettings } from "../types";
import { ArrowLeft, Volume2, Eye } from "lucide-react";
import { t, Language } from "../utils/i18n"; // تم استيراد نظام الترجمة

interface SettingsScreenProps {
  settings: GameSettings;
  onNavigate: (screen: string) => void;
  onUpdateSettings: (newSettings: Partial<GameSettings>) => void;
}

export default function SettingsScreen({ settings, onNavigate, onUpdateSettings }: SettingsScreenProps) {
  // جلب اللغة الحالية من الإعدادات
  const lang = (settings.language || "ar") as Language;

  // تحديث اتجاه لغة الصفحة (RTL/LTR) تلقائياً لضمان تفاعل الواجهة بالكامل
  useEffect(() => {
    if (lang === "ar") {
      document.documentElement.dir = "rtl";
      document.documentElement.lang = "ar";
    } else {
      document.documentElement.dir = "ltr";
      document.documentElement.lang = "en";
    }
  }, [lang]);

  const playClick = () => {
    audio.playClick();
  };

  const handleMusicChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const val = parseFloat(e.target.value);
    onUpdateSettings({ musicVolume: val });
    audio.setVolumes(val, settings.effectsVolume, settings.isMuted);
  };

  const handleFXChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const val = parseFloat(e.target.value);
    onUpdateSettings({ effectsVolume: val });
    audio.setVolumes(settings.musicVolume, val, settings.isMuted);
  };

  const handleMuteToggle = () => {
    playClick();
    const muted = !settings.isMuted;
    onUpdateSettings({ isMuted: muted });
    audio.setVolumes(settings.musicVolume, settings.effectsVolume, muted);
    
    if (muted) {
      audio.stopMusic();
    } else {
      audio.startMusic();
    }
  };

  const handleFilterChange = (filter: "color" | "sepia" | "bw") => {
    playClick();
    onUpdateSettings({ visualFilter: filter });
  };

  const handleScratchesToggle = () => {
    playClick();
    onUpdateSettings({ showScratches: !settings.showScratches });
  };

  return (
    <div className="relative w-full min-h-screen bg-[#F5E6CA] vignette-overlay py-8 px-4 md:px-8 flex flex-col justify-between select-none">
      
      {/* HEADER HUD */}
      <div className="w-full max-w-4xl mx-auto flex justify-between items-center border-b-4 border-black pb-4 mb-6">
        <button
          onClick={() => { playClick(); onNavigate("menu"); }}
          className="cartoon-button text-xs md:text-sm px-4 py-2 flex items-center gap-1 bg-[#5C3D2E] text-white uppercase"
        >
          <ArrowLeft className={`w-4 h-4 stroke-[3] ${lang === "ar" ? "rotate-180" : ""}`} /> {lang === "ar" ? "القائمة" : "Menu"}
        </button>

        <h1 className="text-xl md:text-4xl font-display text-[#D23A3A] tracking-wide filter drop-shadow-[2px_2px_0_#1a1a1a]">
          {t("settings.title", lang)}
        </h1>

        <div className="flex items-center gap-1.5 bg-[#E6D5B3] border-4 border-black px-3 py-1.5 shadow-[2px_2px_0_#1a1a1a] rounded-xl text-xs font-mono font-bold uppercase">
          {lang === "ar" ? "إعدادات التطبيق" : "App Settings"}
        </div>
      </div>

      {/* BODY PANEL */}
      <div className="w-full max-w-3xl mx-auto my-auto">
        <div className="vintage-paper-panel p-6 md:p-8 rounded-3xl border-4 shadow-[8px_8px_0_rgba(0,0,0,1)] grid grid-cols-1 md:grid-cols-2 gap-8">
          
          {/* Left Column: Audio & Language Controls */}
          <div className={`flex flex-col gap-5 border-b-4 md:border-b-0 border-dashed border-black/20 pb-6 md:pb-0 ${lang === "ar" ? "md:border-l-4 md:pl-8" : "md:border-r-4 md:pr-8"}`}>
            <h3 className="text-lg font-display text-[#D23A3A] tracking-wider flex items-center gap-2 border-b-2 border-black pb-2">
              <Volume2 className="w-5 h-5 text-[#D23A3A] stroke-[2.5]" />
              {t("settings.audio", lang)}
            </h3>

            {/* Mute Toggle */}
            <div className="flex items-center justify-between">
              <label className="font-sans font-bold text-xs md:text-sm uppercase">{t("settings.mute", lang)}</label>
              <input
                type="checkbox"
                checked={settings.isMuted}
                onChange={handleMuteToggle}
                className="w-5 h-5 accent-[#D23A3A] border-4 border-black rounded-none cursor-pointer"
              />
            </div>

            {/* Music Volume slider */}
            <div>
              <div className="flex justify-between text-[10px] md:text-xs font-mono font-bold uppercase mb-1">
                <span>{t("settings.musicVol", lang)}</span>
                <span>{Math.round(settings.musicVolume * 100)}%</span>
              </div>
              <input
                type="range"
                min="0"
                max="1"
                step="0.05"
                value={settings.musicVolume}
                onChange={handleMusicChange}
                disabled={settings.isMuted}
                className="w-full accent-[#D23A3A] bg-zinc-200 border-2 border-black rounded-lg appearance-none h-3 cursor-pointer disabled:opacity-30"
              />
            </div>

            {/* Sound FX slider */}
            <div>
              <div className="flex justify-between text-[10px] md:text-xs font-mono font-bold uppercase mb-1">
                <span>{t("settings.sfxVol", lang)}</span>
                <span>{Math.round(settings.effectsVolume * 100)}%</span>
              </div>
              <input
                type="range"
                min="0"
                max="1"
                step="0.05"
                value={settings.effectsVolume}
                onChange={handleFXChange}
                disabled={settings.isMuted}
                className="w-full accent-[#D23A3A] bg-zinc-200 border-2 border-black rounded-lg appearance-none h-3 cursor-pointer disabled:opacity-30"
              />
            </div>

            {/* LANGUAGE CHANGER */}
            <div className="border-t-2 border-black/10 pt-4 mt-2">
              <span className="block font-sans font-bold text-xs md:text-sm uppercase mb-2">
                {t("settings.language", lang)}
              </span>
              <div className="flex gap-2">
                <button
                  onClick={() => { playClick(); onUpdateSettings({ language: "ar" }); }}
                  className={`p-2 flex-1 font-display text-xs rounded-xl border-4 border-black text-center shadow-[1px_1px_0_#1a1a1a] transition-all ${
                    settings.language === "ar" ? "bg-[#D23A3A] text-white scale-105" : "bg-white text-black"
                  }`}
                >
                  🇸🇦 {t("settings.ar", lang)}
                </button>
                <button
                  onClick={() => { playClick(); onUpdateSettings({ language: "en" }); }}
                  className={`p-2 flex-1 font-display text-xs rounded-xl border-4 border-black text-center shadow-[1px_1px_0_#1a1a1a] transition-all ${
                    settings.language === "en" ? "bg-[#D23A3A] text-white scale-105" : "bg-white text-black"
                  }`}
                >
                  🇬🇧 {t("settings.en", lang)}
                </button>
              </div>
            </div>
          </div>

          {/* Right Column: Visual Filters */}
          <div className="flex flex-col gap-5">
            <h3 className="text-lg font-display text-[#3A8FD2] tracking-wider flex items-center gap-2 border-b-2 border-black pb-2">
              <Eye className="w-5 h-5 text-[#3A8FD2] stroke-[2.5]" />
              {t("settings.theme", lang)}
            </h3>

            {/* Visual Filters Selector */}
            <div>
              <span className="block font-sans font-bold text-xs md:text-sm uppercase mb-3">
                {t("settings.printColor", lang)}
              </span>
              <div className="flex flex-col gap-2">
                {/* Full Color */}
                <button
                  onClick={() => handleFilterChange("color")}
                  className={`p-2 font-display text-xs rounded-xl border-4 border-black flex items-center gap-2 shadow-[2px_2px_0_#1a1a1a] ${
                    settings.visualFilter === "color" ? "bg-[#5BB381] text-white" : "bg-white text-black"
                  } ${lang === "ar" ? "text-right justify-start" : "text-left"}`}
                >
                  🎨 {t("settings.filterColor", lang)}
                </button>

                {/* Sepia */}
                <button
                  onClick={() => handleFilterChange("sepia")}
                  className={`p-2 font-display text-xs rounded-xl border-4 border-black flex items-center gap-2 shadow-[2px_2px_0_#1a1a1a] ${
                    settings.visualFilter === "sepia" ? "bg-[#F4D160] text-black" : "bg-white text-black"
                  } ${lang === "ar" ? "text-right justify-start" : "text-left"}`}
                >
                  📜 {t("settings.filterSepia", lang)}
                </button>

                {/* BW */}
                <button
                  onClick={() => handleFilterChange("bw")}
                  className={`p-2 font-display text-xs rounded-xl border-4 border-black flex items-center gap-2 shadow-[2px_2px_0_#1a1a1a] ${
                    settings.visualFilter === "bw" ? "bg-zinc-800 text-white" : "bg-white text-black"
                  } ${lang === "ar" ? "text-right justify-start" : "text-left"}`}
                >
                  🎬 {t("settings.filterBw", lang)}
                </button>
              </div>
            </div>

            {/* Toggle Projector Scratches */}
            <div className="flex items-center justify-between border-t-2 border-black/10 pt-4 mt-1">
              <label className="font-sans font-bold text-xs md:text-sm uppercase">{t("settings.scratches", lang)}</label>
              <input
                type="checkbox"
                checked={settings.showScratches}
                onChange={handleScratchesToggle}
                className="w-5 h-5 accent-[#D23A3A] border-4 border-black rounded-none cursor-pointer"
              />
            </div>
          </div>
        </div>
      </div>

      {/* FOOTER */}
      <div className="w-full max-w-4xl mx-auto flex justify-between items-center border-t-4 border-black pt-4 mt-8 text-xs font-mono font-bold text-gray-700 uppercase">
        <span>{lang === "ar" ? "إصدار الإعدادات 1.0" : "Settings Module V1.0"}</span>
        <span>Reel: No. 104 • LaraQuiz App</span>
      </div>
    </div>
  );
}