/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from "react";
import { motion } from "motion/react";
import { audio } from "../audio";
import { ACHIEVEMENTS, SHOP_ITEMS } from "../data";
import { User, Achievement, GameSettings } from "../types";
import { ArrowLeft, Award, Coins, Star, Swords } from "lucide-react";
import CharacterAvatar from "./CharacterAvatar";

interface ProfileProps {
  user: User;
  onNavigate: (screen: string) => void;
  onEquipAvatar: (avatarImage: string) => void;
  settings: GameSettings;
}

export default function Profile({ user, onNavigate, onEquipAvatar, settings }: ProfileProps) {
  const lang = settings.language || "ar";

  const playClick = () => {
    audio.playClick();
  };

  // Determine Level from XP
  const playerLevel = Math.floor(user.xp / 400) + 1;
  const totalLevelsSolved = Object.keys(user.completedLevels).length;

  // Find user's unlocked avatars in inventory
  const unlockedAvatars = SHOP_ITEMS.filter(
    (item) => item.category === "avatar" && (item.price === 0 || user.inventory.includes(item.id))
  );

  return (
    <div className="relative w-full min-h-screen bg-[#F5E6CA] vignette-overlay py-8 px-4 md:px-8 flex flex-col justify-between select-none">
      
      {/* HEADER HUD */}
      <div className="w-full max-w-5xl mx-auto flex justify-between items-center border-b-4 border-black pb-4 mb-6">
        <button
          onClick={() => { playClick(); onNavigate("menu"); }}
          className="cartoon-button text-xs md:text-sm px-4 py-2 flex items-center gap-1 bg-[#5C3D2E] text-white uppercase"
        >
          <ArrowLeft className="w-4 h-4 stroke-[3]" /> {lang === "ar" ? "القائمة" : "Menu"}
        </button>

        <h1 className="text-2xl md:text-4xl font-display text-[#D23A3A] tracking-wide filter drop-shadow-[2px_2px_0_#1a1a1a]">
          {lang === "ar" ? "السجل والجوائز" : "MY JOURNAL"}
        </h1>

        <div className="text-xs font-mono font-bold bg-[#E6D5B3] px-3 py-1.5 border-4 border-black rounded-lg">
          {lang === "ar" ? `مستوى ${playerLevel}` : `LVL ${playerLevel}`}
        </div>
      </div>

      {/* BODY SECTIONS */}
      <div className="w-full max-w-5xl mx-auto grid grid-cols-1 md:grid-cols-12 gap-8 my-auto items-start">
        
        {/* Left Side: Stats and Avatar Equip */}
        <div className="md:col-span-5 flex flex-col gap-6">
          {/* Main Stat Panel */}
          <div className="vintage-paper-panel p-6 rounded-2xl flex flex-col items-center border-4">
            <div className="w-24 h-24 bg-white rounded-full border-4 border-black flex items-center justify-center mb-4 shadow-[3px_3px_0_rgba(0,0,0,1)] rubber-hose-idle overflow-hidden">
              <CharacterAvatar avatar={user.avatar} size={76} />
            </div>

            <h2 className="text-2xl font-display leading-none text-center">{user.displayName}</h2>
            <p className="font-mono text-xs font-bold text-gray-700 uppercase mt-1 mb-4">
              {lang === "ar" ? "السجل الرسمي للاعب" : "Official Player Log"}
            </p>

            {/* Grid Stats */}
            <div className="grid grid-cols-3 gap-3 w-full border-t-2 border-black/10 pt-4 mt-1">
              <div className="flex flex-col items-center">
                <Coins className="w-5 h-5 text-amber-700" />
                <span className="font-display text-base text-gray-800 mt-1">{user.coins}</span>
                <span className="text-[9px] font-mono font-bold text-gray-500 uppercase">
                  {lang === "ar" ? "قطع" : "Coins"}
                </span>
              </div>

              <div className="flex flex-col items-center border-x-2 border-dashed border-black/10">
                <Star className="w-5 h-5 text-yellow-600 fill-yellow-500" />
                <span className="font-display text-base text-gray-800 mt-1">{user.stars}</span>
                <span className="text-[9px] font-mono font-bold text-gray-500 uppercase">
                  {lang === "ar" ? "نجوم" : "Stars"}
                </span>
              </div>

              <div className="flex flex-col items-center">
                <Swords className="w-5 h-5 text-[#D23A3A]" />
                <span className="font-display text-base text-gray-800 mt-1">{totalLevelsSolved}</span>
                <span className="text-[9px] font-mono font-bold text-gray-500 uppercase">
                  {lang === "ar" ? "مراحل" : "Stages"}
                </span>
              </div>
            </div>
          </div>

          {/* Avatar Equip Closet */}
          <div className="vintage-paper-panel p-5 rounded-2xl border-4">
            <h3 className="text-sm font-display text-[#3A8FD2] tracking-wider border-b-2 border-black pb-2 mb-4 text-center">
              {lang === "ar" ? "تغيير الشخصية" : "EQUIP MASCOT"}
            </h3>
            
            <div className="flex flex-wrap gap-3.5 justify-center">
              {unlockedAvatars.map((av) => {
                const isEquipped = user.avatar === av.image;
                return (
                  <motion.button
                    key={av.id}
                    whileHover={{ scale: 1.12 }}
                    whileTap={{ scale: 0.9 }}
                    onClick={() => {
                      if (!isEquipped) {
                        playClick();
                        onEquipAvatar(av.image);
                      }
                    }}
                    className={`w-12 h-12 rounded-full border-4 border-black flex items-center justify-center transition-all shadow-[2px_2px_0_#1a1a1a] overflow-hidden ${
                      isEquipped ? "bg-[#D23A3A] scale-110" : "bg-white hover:bg-yellow-50"
                    }`}
                    title={lang === "ar" ? av.arabicName : av.name}
                  >
                    <CharacterAvatar avatar={av.image} size={36} />
                  </motion.button>
                );
              })}
            </div>
            <p className="text-[10px] font-mono text-center text-gray-600 mt-3 uppercase">
              {lang === "ar" ? "* اشترِ المزيد من مظهر الشخصيات من المتجر!" : "* Buy more character skins from the General Store!"}
            </p>
          </div>
        </div>

        {/* Right Side: Achievements shelf */}
        <div className="md:col-span-7">
          <div className="vintage-paper-panel p-6 rounded-2xl border-4">
            <h3 className="text-xl font-display text-[#D23A3A] tracking-wider border-b-2 border-black pb-2 mb-4">
              {lang === "ar" ? "🎖️ الميداليات والإنجازات المكتسبة" : "🎖️ ACQUIRED MEDALS"}
            </h3>

            <div className="flex flex-col gap-4 max-h-[50vh] overflow-y-auto pr-1">
              {ACHIEVEMENTS.map((ach: Achievement) => {
                // Calculate completion
                let isCompleted = false;
                let progress = 0;

                if (ach.conditionType === "total_levels") {
                  progress = totalLevelsSolved;
                  isCompleted = totalLevelsSolved >= ach.conditionValue;
                } else if (ach.conditionType === "total_coins") {
                  progress = user.coins;
                  isCompleted = user.coins >= ach.conditionValue;
                } else if (ach.conditionType === "total_stars") {
                  progress = user.stars;
                  isCompleted = user.stars >= ach.conditionValue;
                }

                return (
                  <div
                    key={ach.id}
                    className={`flex gap-4 p-3 border-4 border-black rounded-xl shadow-[2px_2px_0_#1a1a1a] items-center ${
                      isCompleted ? "bg-[#E2F0D9]" : "bg-white/40"
                    }`}
                  >
                    {/* Medal Stamp */}
                    <div className={`w-12 h-12 rounded-full border-4 border-black flex items-center justify-center text-3xl shadow-[1px_1px_0_#1a1a1a] ${
                      isCompleted ? "bg-[#F4D160] animate-pulse" : "bg-zinc-200 grayscale opacity-40"
                    }`}>
                      {ach.icon}
                    </div>

                    <div className="flex-1">
                      <div className="flex items-baseline justify-between gap-1">
                        <h4 className="font-display text-sm leading-tight text-gray-950">
                          {lang === "ar" ? ach.arabicName : ach.name}
                        </h4>
                        <span className="font-mono text-[9px] font-bold text-gray-500 uppercase">
                          {isCompleted 
                            ? (lang === "ar" ? "★ تم الاكتساب" : "★ ACQUIRED") 
                            : (lang === "ar" ? "مغلق" : "LOCKED")}
                        </span>
                      </div>
                      <p className="font-sans text-xs text-gray-700 leading-tight">
                        {lang === "ar" ? ach.arabicDescription : ach.description}
                      </p>
                      
                      {/* Secondary Translation */}
                      {lang === "ar" && (
                        <p className="font-sans text-[10px] text-gray-500 italic mt-0.5 leading-none">
                          {ach.name}
                        </p>
                      )}

                      {/* Progress Bar */}
                      <div className="flex items-center gap-2 mt-2">
                        <div className="flex-1 h-2 bg-gray-200 border border-black rounded-full overflow-hidden">
                          <div 
                            className="h-full bg-amber-400 border-r border-black"
                            style={{ width: `${Math.min(100, (progress / ach.conditionValue) * 100)}%` }}
                          ></div>
                        </div>
                        <span className="font-mono text-[9px] font-bold text-gray-600">
                          {progress} / {ach.conditionValue}
                        </span>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      </div>

      {/* FOOTER */}
      <div className="w-full max-w-5xl mx-auto flex justify-between items-center border-t-4 border-black pt-4 mt-8 text-xs font-mono font-bold text-gray-700 uppercase">
        <span>{lang === "ar" ? `إجمالي نقاط الخبرة: ${user.xp}` : `Total XP logged: ${user.xp}`}</span>
        <span>Reel: No. 104 • 1930s Film</span>
      </div>

      {/* Retro film scratches */}
      <div className="film-scratch-1"></div>
      <div className="film-scratch-2"></div>
    </div>
  );
}
