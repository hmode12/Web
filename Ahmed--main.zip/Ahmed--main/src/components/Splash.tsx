/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from "react";
import { motion } from "motion/react";
import { audio } from "../audio";
import { GameSettings } from "../types";
import { t } from "../utils/i18n";

interface SplashProps {
  onStartGame: () => void;
  settings: GameSettings;
}

export default function Splash({ onStartGame, settings }: SplashProps) {
  const [hasClicked, setHasClicked] = useState(false);
  const lang = settings.language || "ar";

  const handleEnter = () => {
    setHasClicked(true);
    // Initialize audio on click
    audio.playClick();
    if (!settings.isMuted) {
      audio.startMusic();
    }
    // Fade out splash screen after short delay
    setTimeout(() => {
      onStartGame();
    }, 1000);
  };

  return (
    <div className="relative w-full h-screen flex flex-col justify-center items-center bg-[#F5E6CA] overflow-hidden vignette-overlay px-4 text-center select-none">
      {/* Decorative Floating Clouds */}
      <div className="absolute top-12 left-0 right-0 h-24 overflow-hidden pointer-events-none opacity-40">
        <div className="cartoon-cloud text-6xl absolute left-0 text-[#1A1A1A]">☁️</div>
        <div className="cartoon-cloud text-5xl absolute left-1/3 text-[#1A1A1A] [animation-delay:4s]">☁️</div>
        <div className="cartoon-cloud text-7xl absolute left-2/3 text-[#1A1A1A] [animation-delay:8s]">☁️</div>
      </div>

      {/* Main Vintage Paper Frame */}
      <motion.div
        initial={{ scale: 0.8, rotate: -2, opacity: 0 }}
        animate={{ scale: 1, rotate: 0, opacity: 1 }}
        transition={{ type: "spring", damping: 10 }}
        className="vintage-paper-panel max-w-lg w-full p-8 md:p-12 flex flex-col items-center gap-6 z-10"
      >
        {/* Vintage Top Ribbon */}
        <div className="text-xs font-mono tracking-widest text-gray-700 border-b-2 border-black pb-2 mb-2 w-full uppercase">
          {lang === "ar" ? "★ إنتاج رسوم متحركة كلاسيكي لعام 1930 ★" : "★ A Classic 1930s Cel Cartoon Production ★"}
        </div>

        {/* Bouncy Title Logo */}
        <motion.h1
          animate={{ scale: [1, 1.05, 1], rotate: [-1, 1, -1] }}
          transition={{ repeat: Infinity, duration: 1.2, ease: "easeInOut" }}
          className="text-6xl md:text-7xl font-display text-[#D23A3A] tracking-wide filter drop-shadow-[4px_4px_0px_#1A1A1A]"
          style={{ WebkitTextStroke: "2.5px #1A1A1A" }}
        >
          {lang === "ar" ? "لاراكويز" : "LARAQUIZ"}
        </motion.h1>

        {/* Rubber Hose Character Animation Placeholder */}
        <div className="relative w-36 h-36 my-2 flex items-center justify-center bg-[#E6D5B3] rounded-full border-4 border-black shadow-[4px_4px_0_#1A1A1A]">
          <div className="text-7xl rubber-hose-idle">🥛🔴</div>
          {/* Animated legs */}
          <div className="absolute -bottom-4 flex gap-6 text-2xl font-bold">
            <span className="animate-bounce">👞</span>
            <span className="animate-bounce [animation-delay:0.2s]">👞</span>
          </div>
        </div>

        <p className="text-lg font-bold text-gray-800 font-sans max-w-sm">
          {t("splash.subtitle", lang)}
        </p>

        {/* Bouncy Play Button */}
        {!hasClicked ? (
          <motion.button
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            onClick={handleEnter}
            className="cartoon-button text-2xl px-10 py-4 mt-4 w-full bg-[#D23A3A] hover:bg-[#e54b4b] uppercase tracking-wider"
          >
            {t("splash.pressStart", lang)}
          </motion.button>
        ) : (
          <div className="text-2xl font-display text-[#3A8FD2] animate-pulse py-4 mt-4 uppercase">
            {lang === "ar" ? "★ جاري تحميل بكرة الفيلم... ★" : "★ Loading Film Reel... ★"}
          </div>
        )}

        {/* Vintage Technical Footer */}
        <div className="text-xs font-mono text-gray-600 mt-2 uppercase">
          {lang === "ar" ? "بكرة: رقم 104 • 24 إطار • نظام صوتي" : "Reel: No. 104 • 24 FPS • SOUND SYSTEM"}
        </div>
      </motion.div>

      {/* Retro film grain / scratches */}
      <div className="film-scratch-1"></div>
      <div className="film-scratch-2"></div>
    </div>
  );
}
