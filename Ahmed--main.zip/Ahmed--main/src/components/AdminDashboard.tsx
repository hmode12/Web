/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from "react";
import { motion } from "motion/react";
import { audio } from "../audio";
import { WORLDS, CURATED_QUESTIONS } from "../data";
import { User, Question, GameSettings } from "../types";
import { ArrowLeft, Users, FileText, Settings, Heart, ShieldAlert, Sparkles, Check, Trash2, PlusCircle, Search } from "lucide-react";
import CharacterAvatar from "./CharacterAvatar";

interface AdminDashboardProps {
  user: User;
  onNavigate: (screen: string) => void;
  onUpdateUserStats: (targetUsername: string, updates: Partial<User>) => void;
  onAddCustomQuestion: (worldId: number, q: Question) => void;
  settings: GameSettings;
}

export default function AdminDashboard({
  user,
  onNavigate,
  onUpdateUserStats,
  onAddCustomQuestion,
  settings
}: AdminDashboardProps) {
  const lang = settings.language || "ar";

  const [activeTab, setActiveTab] = useState<"users" | "questions" | "worlds" | "logs">("users");
  const [userSearchQuery, setUserSearchQuery] = useState("");
  const [selectedUser, setSelectedUser] = useState<string | null>(null);

  // New question form state
  const [newWorldId, setNewWorldId] = useState(1);
  const [newQuestionText, setNewQuestionText] = useState("");
  const [ans1, setAns1] = useState("");
  const [ans2, setAns2] = useState("");
  const [ans3, setAns3] = useState("");
  const [ans4, setAns4] = useState("");
  const [correctAns, setCorrectAns] = useState("");
  const [explanationText, setExplanationText] = useState("");
  const [difficultySelect, setDifficultySelect] = useState<"Easy" | "Medium" | "Hard">("Easy");

  const [notif, setNotif] = useState("");

  const playClick = () => {
    audio.playClick();
  };

  const triggerNotif = (msg: string) => {
    setNotif(msg);
    setTimeout(() => setNotif(""), 4000);
  };

  // Compile list of registered users in localStorage
  const getRegisteredUsers = (): User[] => {
    const list: User[] = [];
    for (let i = 0; i < localStorage.length; i++) {
      const key = localStorage.key(i);
      if (key && key.startsWith("user_")) {
        try {
          const u = JSON.parse(localStorage.getItem(key) || "");
          list.push(u);
        } catch (e) {
          // ignore
        }
      }
    }
    // Always append the current user if not saved yet
    if (!list.some(u => u.username === user.username)) {
      list.push(user);
    }
    return list;
  };

  const allUsers = getRegisteredUsers();
  const filteredUsers = allUsers.filter(u =>
    u.username.toLowerCase().includes(userSearchQuery.toLowerCase()) ||
    u.email.toLowerCase().includes(userSearchQuery.toLowerCase())
  );

  const activeUserToEdit = allUsers.find(u => u.username === selectedUser);

  // Question adding logic
  const handleCreateQuestion = (e: React.FormEvent) => {
    e.preventDefault();
    playClick();

    if (!newQuestionText || !ans1 || !ans2 || !ans3 || !ans4 || !correctAns || !explanationText) {
      audio.playWrong();
      alert(lang === "ar" 
        ? "يرجى ملء جميع حقول بطاقة السؤال أولاً يا صاحبي!" 
        : "Fill out all the ink blocks on this question card, pal!"
      );
      return;
    }

    const answersArray = [ans1, ans2, ans3, ans4];
    if (!answersArray.includes(correctAns)) {
      audio.playWrong();
      alert(lang === "ar" 
        ? "يجب أن تطابق الإجابة الصحيحة أحد الخيارات الأربعة تماماً!" 
        : "The Correct Answer must match one of the four answers exactly!"
      );
      return;
    }

    const q: Question = {
      id: Date.now(),
      question: newQuestionText,
      answers: answersArray,
      correctAnswer: correctAns,
      explanation: explanationText,
      difficulty: difficultySelect
    };

    onAddCustomQuestion(newWorldId, q);
    
    // reset form
    setNewQuestionText("");
    setAns1("");
    setAns2("");
    setAns3("");
    setAns4("");
    setCorrectAns("");
    setExplanationText("");

    audio.playLevelWin();
    triggerNotif(lang === "ar" 
      ? `نجاح: تم إلحاق بطاقة السؤال الجديدة بالعالم ${newWorldId}!` 
      : `Success: Appended new question card to World ${newWorldId}!`
    );
  };

  return (
    <div className="relative w-full min-h-screen bg-[#F5E6CA] vignette-overlay py-8 px-4 md:px-8 flex flex-col justify-between select-none">
      
      {/* HEADER HUD */}
      <div className="w-full max-w-5xl mx-auto flex justify-between items-center border-b-4 border-black pb-4 mb-6">
        <button
          onClick={() => { playClick(); onNavigate("menu"); }}
          className="cartoon-button text-xs md:text-sm px-4 py-2 flex items-center gap-1 bg-[#5C3D2E] text-white uppercase"
        >
          <ArrowLeft className="w-4 h-4 stroke-[3]" /> {lang === "ar" ? "القائمة" : "Menu"}
        </button>

        <h1 className="text-xl md:text-4xl font-display text-[#D23A3A] tracking-wide filter drop-shadow-[2px_2px_0_#1a1a1a]">
          {lang === "ar" ? "سجل الإدارة الرئيسي" : "ADMINISTRATOR LEDGER"}
        </h1>

        <div className="flex items-center gap-1 font-mono text-[10px] font-bold bg-[#D23A3A] text-white px-2.5 py-1.5 border-2 border-black rounded-lg">
          <ShieldAlert className="w-4 h-4 text-white fill-white animate-pulse" /> {lang === "ar" ? "لوحة التحكم" : "CONTROL PANEL"}
        </div>
      </div>

      {/* BODY SECTIONS */}
      <div className="w-full max-w-5xl mx-auto my-auto grid grid-cols-1 md:grid-cols-12 gap-8 items-start">
        
        {/* Left Side Tabs */}
        <div className="md:col-span-3 flex flex-col gap-2 bg-[#E6D5B3] p-4 border-4 border-black rounded-2xl shadow-[4px_4px_0_#1a1a1a]">
          <h3 className="text-xs font-display text-gray-700 tracking-wider mb-2 border-b border-black/10 pb-2 text-center">
            {lang === "ar" ? "غرف التحكم" : "OFFICE ROOMS"}
          </h3>

          <button
            onClick={() => { playClick(); setActiveTab("users"); }}
            className={`p-3 text-left font-display text-xs rounded-xl border-2 border-black flex items-center gap-2 transition-all ${
              activeTab === "users" ? "bg-[#D23A3A] text-white" : "bg-white text-black hover:bg-yellow-50"
            }`}
          >
            <Users className="w-4 h-4" /> {lang === "ar" ? "سجل اللاعبين" : "Players Registry"}
          </button>

          <button
            onClick={() => { playClick(); setActiveTab("questions"); }}
            className={`p-3 text-left font-display text-xs rounded-xl border-2 border-black flex items-center gap-2 transition-all ${
              activeTab === "questions" ? "bg-[#3A8FD2] text-white" : "bg-white text-black hover:bg-yellow-50"
            }`}
          >
            <PlusCircle className="w-4 h-4" /> {lang === "ar" ? "إضافة أسئلة" : "Create Questions"}
          </button>

          <button
            onClick={() => { playClick(); setActiveTab("worlds"); }}
            className={`p-3 text-left font-display text-xs rounded-xl border-2 border-black flex items-center gap-2 transition-all ${
              activeTab === "worlds" ? "bg-[#5BB381] text-white" : "bg-white text-black hover:bg-yellow-50"
            }`}
          >
            <Settings className="w-4 h-4" /> {lang === "ar" ? "تكوين العوالم" : "Worlds config"}
          </button>

          <button
            onClick={() => { playClick(); setActiveTab("logs"); }}
            className={`p-3 text-left font-display text-xs rounded-xl border-2 border-black flex items-center gap-2 transition-all ${
              activeTab === "logs" ? "bg-zinc-800 text-white" : "bg-white text-black hover:bg-yellow-50"
            }`}
          >
            <FileText className="w-4 h-4" /> {lang === "ar" ? "صحة النظام" : "System Health"}
          </button>
        </div>

        {/* Right Content Frame */}
        <div className="md:col-span-9 flex flex-col gap-4">
          {notif && (
            <div className="p-3 bg-[#5BB381] border-4 border-black text-white font-bold text-sm text-center shadow-[2px_2px_0_#1a1a1a] rounded-lg">
              🎉 {notif}
            </div>
          )}

          {/* TAB 1: PLAYER MANAGEMENT */}
          {activeTab === "users" && (
            <div className="vintage-paper-panel p-6 rounded-2xl border-4 min-h-[50vh]">
              <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center border-b-2 border-black pb-3 mb-4 gap-2">
                <h2 className="text-xl font-display text-[#D23A3A] uppercase">
                  {lang === "ar" ? "سجل اللاعبين" : "Players Registry"}
                </h2>
                
                {/* Search box */}
                <div className="relative w-full sm:w-64">
                  <input
                    type="text"
                    value={userSearchQuery}
                    onChange={(e) => setUserSearchQuery(e.target.value)}
                    placeholder={lang === "ar" ? "ابحث باسم اللاعب..." : "Search player name..."}
                    className="w-full pl-8 pr-2 py-1.5 bg-white border-2 border-black text-xs font-bold text-black focus:outline-none placeholder-gray-500 rounded-lg"
                  />
                  <Search className="w-3.5 h-3.5 text-gray-500 absolute left-2.5 top-2.5" />
                </div>
              </div>

              {/* Grid content */}
              <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
                {/* Left: User search items */}
                <div className="lg:col-span-5 flex flex-col gap-2 max-h-[35vh] overflow-y-auto pr-1">
                  {filteredUsers.map(u => (
                    <div
                      key={u.username}
                      onClick={() => { playClick(); setSelectedUser(u.username); }}
                      className={`p-2 border-2 border-black rounded-lg cursor-pointer flex justify-between items-center text-xs ${
                        selectedUser === u.username ? "bg-[#3A8FD2] text-white" : "bg-white text-black hover:bg-yellow-50"
                      }`}
                    >
                      <div className="flex items-center gap-2">
                        <div className="w-5 h-5 rounded-full bg-[#E6D5B3] border border-black flex items-center justify-center overflow-hidden flex-shrink-0">
                          <CharacterAvatar avatar={u.avatar} size={16} />
                        </div>
                        <span className="font-bold">{u.username}</span>
                      </div>
                      <span className="font-mono text-[9px] uppercase bg-black text-white px-1.5 rounded">{u.role}</span>
                    </div>
                  ))}
                </div>

                {/* Right: Selected user controls */}
                <div className="lg:col-span-7 bg-[#E6D5B3] p-4 border-4 border-black rounded-xl">
                  {activeUserToEdit ? (
                    <div className="flex flex-col gap-4">
                      <div className="flex items-center gap-3">
                        <div className="w-12 h-12 rounded-full bg-white border-2 border-black flex items-center justify-center overflow-hidden flex-shrink-0 shadow-[2px_2px_0_rgba(0,0,0,1)]">
                          <CharacterAvatar avatar={activeUserToEdit.avatar} size={36} />
                        </div>
                        <div>
                          <h4 className="font-display text-sm leading-tight text-gray-900">
                            {activeUserToEdit.displayName}
                          </h4>
                          <span className="font-mono text-[10px] text-gray-600 uppercase">
                            Wallet: {activeUserToEdit.coins} coins • {activeUserToEdit.stars} Stars
                          </span>
                        </div>
                      </div>

                      {/* Control Operations */}
                      <div className="border-t border-black/10 pt-3 flex flex-col gap-3">
                        <span className="font-mono text-[10px] font-bold text-gray-700 uppercase">
                          {lang === "ar" ? "مكتب العمليات الإدارية:" : "Operations Desk:"}
                        </span>
                        
                        <div className="flex flex-wrap gap-2.5">
                          {/* Grant Coins */}
                          <button
                            onClick={() => {
                              playClick();
                              onUpdateUserStats(activeUserToEdit.username, { coins: activeUserToEdit.coins + 500 });
                              triggerNotif(`Granted +500 Gold Coins to ${activeUserToEdit.username}!`);
                            }}
                            className="cartoon-button text-[10px] px-3 py-1.5 bg-amber-600 text-white"
                          >
                            {lang === "ar" ? "+500 عملة" : "+500 Coins"}
                          </button>

                          {/* Grant XP */}
                          <button
                            onClick={() => {
                              playClick();
                              onUpdateUserStats(activeUserToEdit.username, { xp: activeUserToEdit.xp + 400 });
                              triggerNotif(`Granted +400 XP levels to ${activeUserToEdit.username}!`);
                            }}
                            className="cartoon-button text-[10px] px-3 py-1.5 bg-emerald-600 text-white"
                          >
                            {lang === "ar" ? "+400 خبرة" : "+400 XP"}
                          </button>

                          {/* Refill Hearts */}
                          <button
                            onClick={() => {
                              playClick();
                              onUpdateUserStats(activeUserToEdit.username, { lives: 3 });
                              triggerNotif(`Refilled hearts to Max (3 Hearts) for ${activeUserToEdit.username}!`);
                            }}
                            className="cartoon-button text-[10px] px-3 py-1.5 bg-red-600 text-white"
                          >
                            {lang === "ar" ? "تعبئة القلوب" : "Refill Hearts"}
                          </button>

                          {/* Promote Admin */}
                          {activeUserToEdit.role !== "Admin" && (
                            <button
                              onClick={() => {
                                playClick();
                                onUpdateUserStats(activeUserToEdit.username, { role: "Admin" });
                                triggerNotif(`Promoted ${activeUserToEdit.username} to Administrator!`);
                              }}
                              className="cartoon-button text-[10px] px-3 py-1.5 bg-purple-600 text-white"
                            >
                              {lang === "ar" ? "ترقية لمشرف" : "Promote Admin"}
                            </button>
                          )}

                          {/* Reset Progress */}
                          <button
                            onClick={() => {
                              playClick();
                              onUpdateUserStats(activeUserToEdit.username, {
                                currentWorldId: 1,
                                currentLevelId: 1,
                                completedLevels: {},
                                stars: 0,
                                xp: 0,
                                coins: 100
                              });
                              triggerNotif(`Successfully reset levels & progress for ${activeUserToEdit.username}!`);
                            }}
                            className="cartoon-button text-[10px] px-3 py-1.5 bg-neutral-700 text-white"
                          >
                            {lang === "ar" ? "إعادة ضبط التقدم" : "Reset Progress"}
                          </button>
                        </div>
                      </div>
                    </div>
                  ) : (
                    <div className="text-center text-gray-600 py-10 font-handwritten text-xs uppercase leading-relaxed">
                      {lang === "ar" 
                        ? "\"اختر لاعباً نشطاً من السجل أعلاه لفحص ملفات تعاقده وتعديل بياناته!\"" 
                        : "\"Select an active player from the directory ledger to examine their contract files!\""}
                    </div>
                  )}
                </div>
              </div>
            </div>
          )}

          {/* TAB 2: QUESTIONS WRITER */}
          {activeTab === "questions" && (
            <div className="vintage-paper-panel p-5 rounded-2xl border-4">
              <h2 className="text-xl font-display text-[#3A8FD2] uppercase border-b-2 border-black pb-2 mb-4">
                {lang === "ar" ? "إضافة أسئلة مخصصة" : "Question Creator"}
              </h2>

              <form onSubmit={handleCreateQuestion} className="grid grid-cols-1 sm:grid-cols-2 gap-4 font-sans text-xs">
                {/* World select */}
                <div>
                  <label className="block font-bold mb-1">{lang === "ar" ? "اختر العالم المستهدف" : "Select Target World"}</label>
                  <select
                    value={newWorldId}
                    onChange={(e) => setNewWorldId(parseInt(e.target.value))}
                    className="w-full p-2 bg-white border-2 border-black font-bold focus:outline-none"
                  >
                    {WORLDS.map(w => (
                      <option key={w.id} value={w.id}>
                        {lang === "ar" ? `العالم ${w.id}: ${w.arabicName || w.name}` : `World ${w.id}: ${w.name}`}
                      </option>
                    ))}
                  </select>
                </div>

                {/* Difficulty */}
                <div>
                  <label className="block font-bold mb-1">{lang === "ar" ? "اختر مستوى الصعوبة" : "Select Difficulty"}</label>
                  <select
                    value={difficultySelect}
                    onChange={(e) => setDifficultySelect(e.target.value as any)}
                    className="w-full p-2 bg-white border-2 border-black font-bold focus:outline-none"
                  >
                    <option value="Easy">{lang === "ar" ? "سهل" : "Easy"}</option>
                    <option value="Medium">{lang === "ar" ? "متوسط" : "Medium"}</option>
                    <option value="Hard">{lang === "ar" ? "صعب" : "Hard"}</option>
                  </select>
                </div>

                {/* Question */}
                <div className="sm:col-span-2">
                  <label className="block font-bold mb-1">{lang === "ar" ? "نص السؤال" : "Question Text"}</label>
                  <input
                    type="text"
                    value={newQuestionText}
                    onChange={(e) => setNewQuestionText(e.target.value)}
                    placeholder={lang === "ar" ? "مثال: ما هي الأداة الأساسية للرسم الكرتوني القديم؟" : "e.g. Which tool do animators use to draw characters?"}
                    className="w-full p-2.5 bg-white border-2 border-black font-bold focus:outline-none"
                  />
                </div>

                {/* Answers */}
                <div>
                  <label className="block font-bold mb-1">{lang === "ar" ? "خيار الإجابة 1" : "Answer Choice 1"}</label>
                  <input
                    type="text"
                    value={ans1}
                    onChange={(e) => setAns1(e.target.value)}
                    placeholder="Option A"
                    className="w-full p-2 bg-white border-2 border-black focus:outline-none"
                  />
                </div>

                <div>
                  <label className="block font-bold mb-1">{lang === "ar" ? "خيار الإجابة 2" : "Answer Choice 2"}</label>
                  <input
                    type="text"
                    value={ans2}
                    onChange={(e) => setAns2(e.target.value)}
                    placeholder="Option B"
                    className="w-full p-2 bg-white border-2 border-black focus:outline-none"
                  />
                </div>

                <div>
                  <label className="block font-bold mb-1">{lang === "ar" ? "خيار الإجابة 3" : "Answer Choice 3"}</label>
                  <input
                    type="text"
                    value={ans3}
                    onChange={(e) => setAns3(e.target.value)}
                    placeholder="Option C"
                    className="w-full p-2 bg-white border-2 border-black focus:outline-none"
                  />
                </div>

                <div>
                  <label className="block font-bold mb-1">{lang === "ar" ? "خيار الإجابة 4" : "Answer Choice 4"}</label>
                  <input
                    type="text"
                    value={ans4}
                    onChange={(e) => setAns4(e.target.value)}
                    placeholder="Option D"
                    className="w-full p-2 bg-white border-2 border-black focus:outline-none"
                  />
                </div>

                {/* Correct Answer */}
                <div className="sm:col-span-2">
                  <label className="block font-bold mb-1 text-[#D23A3A]">
                    {lang === "ar" ? "الإجابة الصحيحة (يجب تطابق أحد الخيارات تماماً)" : "Correct Answer (Must match an option above exactly!)"}
                  </label>
                  <input
                    type="text"
                    value={correctAns}
                    onChange={(e) => setCorrectAns(e.target.value)}
                    placeholder="Match spelling exactly"
                    className="w-full p-2.5 bg-white border-2 border-[#D23A3A] font-bold focus:outline-none"
                  />
                </div>

                {/* Explanation */}
                <div className="sm:col-span-2">
                  <label className="block font-bold mb-1">{lang === "ar" ? "توضيح وشرح الحل" : "Solution Explanation"}</label>
                  <textarea
                    value={explanationText}
                    onChange={(e) => setExplanationText(e.target.value)}
                    placeholder="Describe why this answer is correct..."
                    rows={2}
                    className="w-full p-2.5 bg-white border-2 border-black font-medium focus:outline-none"
                  />
                </div>

                <div className="sm:col-span-2 mt-2">
                  <button
                    type="submit"
                    className="cartoon-button w-full text-base py-3 bg-[#3A8FD2] hover:bg-[#4da6ec]"
                  >
                    {lang === "ar" ? "إضافة بطاقة السؤال إلى قاعدة بيانات اللعبة" : "Append Question Card to Game Database"}
                  </button>
                </div>
              </form>
            </div>
          )}

          {/* TAB 3: WORLDS CONFIG */}
          {activeTab === "worlds" && (
            <div className="vintage-paper-panel p-5 rounded-2xl border-4">
              <h2 className="text-xl font-display text-[#5BB381] uppercase border-b-2 border-black pb-2 mb-4">
                {lang === "ar" ? "بوابات العبور للعوالم" : "Worlds Gate Controller"}
              </h2>

              <p className="font-handwritten text-xs text-gray-700 leading-relaxed mb-4">
                {lang === "ar" 
                  ? "\"اضبط شروط المرور لكل عالم. يتطلب فتح الأقفال جمع النجوم من القطاعات السابقة!\"" 
                  : "\"Adjust passage rules for each world segment. Unlocking gate locks requires stars collected in previous sectors!\""}
              </p>

              <div className="flex flex-col gap-3">
                {WORLDS.map(w => (
                  <div key={w.id} className="flex justify-between items-center p-3 border-2 border-black bg-white rounded-xl text-xs">
                    <div>
                      <h4 className="font-display text-gray-900 leading-none">
                        {lang === "ar" ? w.arabicName : w.name}
                      </h4>
                      <span className="font-mono text-[9px] text-gray-500 uppercase">
                        {lang === "ar" ? `نطاق المراحل: ${w.levelsRange[0]} - ${w.levelsRange[1]}` : `Levels Range: ${w.levelsRange[0]} - ${w.levelsRange[1]}`}
                      </span>
                    </div>

                    <div className="flex items-center gap-2 font-mono">
                      <span>{lang === "ar" ? "قفل البوابة:" : "Gate Lock:"}</span>
                      <span className="font-bold bg-amber-100 border border-amber-400 px-2 py-0.5 rounded text-amber-800">
                        {lang === "ar" ? `يتطلب ${w.starsRequiredToUnlock} نجمة لفتح القفل` : `${w.starsRequiredToUnlock} STARS REQUIRED`}
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* TAB 4: DIAGNOSTIC LOGS */}
          {activeTab === "logs" && (
            <div className="vintage-paper-panel p-5 rounded-2xl border-4 font-mono text-xs text-black min-h-[50vh] flex flex-col justify-between">
              <div>
                <h2 className="text-xl font-display text-zinc-800 uppercase border-b-2 border-black pb-2 mb-4">
                  {lang === "ar" ? "سجلات تشخيص النظام" : "SYSTEM DIAGNOSTIC LOGS"}
                </h2>

                <div className="bg-black text-emerald-400 p-4 border-4 border-black rounded-xl max-h-[30vh] overflow-y-auto leading-relaxed text-[10px]">
                  <div>[2026-06-28 13:16:16] - BOOTSTRAPPED LARAQUIZ ENGINE</div>
                  <div>[2026-06-28 13:16:18] - INITIALIZED RETRO PROCEDURAL AUDIO DRIVER</div>
                  <div>[2026-06-28 13:16:20] - RESOLVED 10 ADVENTURE WORLDS CONTROLLERS</div>
                  <div>[2026-06-28 13:16:21] - SYNCHRONIZED STAGE CHANNELS: 1 - 500</div>
                  <div>[2026-06-28 13:16:25] - LOADED LOCALSTORAGE PLAYER LEDGER STATUS: HEALTHY</div>
                  <div>[2026-06-28 13:16:30] - CPU HEAT SINK: 38C • CONTAINER RUNTIME PORT: 3000</div>
                  <div>[2026-06-28 13:16:35] - ACTIVE WEBSOCKET TUNNEL: INACTIVE (HMR DISABLED)</div>
                  <div>[2026-06-28 13:16:40] - HEALTHCHECK ENDPOINT: OK STATUS</div>
                </div>
              </div>

              <div className="border-t border-black/10 pt-3 mt-4 flex justify-between items-center text-[10px] text-gray-600 font-bold uppercase">
                <span>{lang === "ar" ? "محرك البيانات: SQLite3 محلي" : "Database engine: SQLite3/Local"}</span>
                <span>{lang === "ar" ? "سجلات الأمان والتدقيق: نظيفة" : "Audit security logs: Clear"}</span>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* FOOTER */}
      <div className="w-full max-w-5xl mx-auto flex justify-between items-center border-t-4 border-black pt-4 mt-8 text-xs font-mono font-bold text-gray-700 uppercase">
        <span>{lang === "ar" ? "مستوى صلاحية المشرف: 10" : "Admin Authority level: 10"}</span>
        <span>Reel: No. 104 • 1930s Film</span>
      </div>

      {/* Retro film scratches */}
      <div className="film-scratch-1"></div>
      <div className="film-scratch-2"></div>
    </div>
  );
}
