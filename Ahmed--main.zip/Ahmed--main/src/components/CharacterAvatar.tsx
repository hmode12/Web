/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from "react";

interface CharacterAvatarProps {
  avatar: string; // Emoji like "🔴🥛" or ID like "av_cuphead"
  className?: string;
  size?: number;
}

export default function CharacterAvatar({ avatar, className = "", size = 48 }: CharacterAvatarProps) {
  // Map both emojis and IDs to clean lookups
  let type = "cuphead";
  if (avatar === "🔴🥛" || avatar === "av_cuphead" || avatar.toLowerCase().includes("cuphead")) {
    type = "cuphead";
  } else if (avatar === "🔵🥛" || avatar === "av_mugman" || avatar.toLowerCase().includes("mugman")) {
    type = "mugman";
  } else if (avatar === "🟡🏆" || avatar === "av_chalice" || avatar.toLowerCase().includes("chalice")) {
    type = "chalice";
  } else if (avatar === "🍬👑" || avatar === "av_baroness" || avatar.toLowerCase().includes("baroness")) {
    type = "baroness";
  } else if (avatar === "🎲🟣" || avatar === "av_kingdice" || avatar.toLowerCase().includes("kingdice")) {
    type = "kingdice";
  } else if (avatar === "😈🔥" || avatar === "av_devil" || avatar.toLowerCase().includes("devil")) {
    type = "devil";
  } else {
    // Fallback if none matches
    type = "cuphead";
  }

  // Common SVG rendering properties for retro 1930s cartoon feel (thick outlines, rich flat colors)
  const strokeColor = "#1a1a1a";
  const strokeWidth = "3.5";

  switch (type) {
    case "cuphead":
      return (
        <svg
          width={size}
          height={size}
          viewBox="0 0 100 100"
          className={`overflow-visible select-none ${className}`}
          id={`avatar-cuphead-${size}`}
        >
          <g>
            {/* Straw: Red and White striped bended straw */}
            <path
              d="M 50,15 L 56,10 L 72,20 L 66,25 Z"
              fill="#D23A3A"
              stroke={strokeColor}
              strokeWidth={strokeWidth}
              strokeLinejoin="round"
            />
            <path
              d="M 56,10 L 59,5 L 75,15 L 72,20 Z"
              fill="#FFFFFF"
              stroke={strokeColor}
              strokeWidth={strokeWidth}
              strokeLinejoin="round"
            />
            <path
              d="M 59,5 L 61,0 L 77,10 L 75,15 Z"
              fill="#D23A3A"
              stroke={strokeColor}
              strokeWidth={strokeWidth}
              strokeLinejoin="round"
            />
            <path
              d="M 45,30 L 50,15 L 66,25 L 61,40"
              fill="#FFFFFF"
              stroke={strokeColor}
              strokeWidth={strokeWidth}
              strokeLinejoin="round"
            />
            {/* Straw stripes inside main section */}
            <path d="M 48,22 L 64,32" stroke={strokeColor} strokeWidth={strokeWidth} />

            {/* Cup Handle (Left/Back side) */}
            <path
              d="M 32,50 C 15,50 15,75 32,75"
              fill="none"
              stroke="#FFFFFF"
              strokeWidth="10"
              strokeLinecap="round"
            />
            <path
              d="M 32,50 C 15,50 15,75 32,75"
              fill="none"
              stroke={strokeColor}
              strokeWidth={strokeWidth}
              strokeLinecap="round"
            />

            {/* Cup Head Base */}
            <path
              d="M 32,42 C 32,30 78,30 78,42 C 78,72 32,72 32,42 Z"
              fill="#FFFFFF"
              stroke={strokeColor}
              strokeWidth={strokeWidth}
              strokeLinejoin="round"
            />

            {/* Red Rim Liquid */}
            <path
              d="M 33,42 C 38,36 72,36 77,42 C 77,44 33,44 33,42 Z"
              fill="#D23A3A"
              stroke={strokeColor}
              strokeWidth="1.5"
            />

            {/* Pie Eyes (Left and Right) */}
            {/* Left Eye */}
            <ellipse
              cx="48"
              cy="48"
              rx="8"
              ry="11"
              fill="#FFFFFF"
              stroke={strokeColor}
              strokeWidth={strokeWidth}
            />
            {/* Pie cut pupil */}
            <path
              d="M 48,48 C 51,46 52,49 51,52 L 48,48 Z"
              fill="#1a1a1a"
            />
            <ellipse cx="49" cy="49" rx="4" ry="6" fill="#1a1a1a" />
            <polygon points="49,49 54,45 54,53" fill="#FFFFFF" /> {/* Pie wedge cutout */}

            {/* Right Eye */}
            <ellipse
              cx="64"
              cy="48"
              rx="8"
              ry="11"
              fill="#FFFFFF"
              stroke={strokeColor}
              strokeWidth={strokeWidth}
            />
            <ellipse cx="63" cy="49" rx="4" ry="6" fill="#1a1a1a" />
            <polygon points="63,49 58,45 58,53" fill="#FFFFFF" />

            {/* Nose: Little Red Oval */}
            <ellipse
              cx="56"
              cy="56"
              rx="4.5"
              ry="3.5"
              fill="#D23A3A"
              stroke={strokeColor}
              strokeWidth="2.5"
            />

            {/* Mouth: Classic 1930s happy curve */}
            <path
              d="M 44,60 C 44,72 68,72 68,60"
              fill="#D23A3A"
              stroke={strokeColor}
              strokeWidth={strokeWidth}
              strokeLinejoin="round"
            />
            {/* Teeth / Tongue line */}
            <path
              d="M 47,63 C 52,65 60,65 65,63"
              stroke="#FFFFFF"
              strokeWidth="2"
              fill="none"
            />
            {/* Rosy Cheek */}
            <circle cx="39" cy="58" r="3" fill="#F0A0A0" />
            <circle cx="71" cy="58" r="3" fill="#F0A0A0" />
          </g>
        </svg>
      );

    case "mugman":
      return (
        <svg
          width={size}
          height={size}
          viewBox="0 0 100 100"
          className={`overflow-visible select-none ${className}`}
          id={`avatar-mugman-${size}`}
        >
          <g>
            {/* Blue and White bended straw */}
            <path
              d="M 50,15 L 56,10 L 72,20 L 66,25 Z"
              fill="#3A8FD2"
              stroke={strokeColor}
              strokeWidth={strokeWidth}
              strokeLinejoin="round"
            />
            <path
              d="M 56,10 L 59,5 L 75,15 L 72,20 Z"
              fill="#FFFFFF"
              stroke={strokeColor}
              strokeWidth={strokeWidth}
              strokeLinejoin="round"
            />
            <path
              d="M 59,5 L 61,0 L 77,10 L 75,15 Z"
              fill="#3A8FD2"
              stroke={strokeColor}
              strokeWidth={strokeWidth}
              strokeLinejoin="round"
            />
            <path
              d="M 45,30 L 50,15 L 66,25 L 61,40"
              fill="#FFFFFF"
              stroke={strokeColor}
              strokeWidth={strokeWidth}
              strokeLinejoin="round"
            />
            <path d="M 48,22 L 64,32" stroke={strokeColor} strokeWidth={strokeWidth} />

            {/* Mug Handle (Left/Back side) */}
            <path
              d="M 30,50 C 10,50 10,78 30,78"
              fill="none"
              stroke="#FFFFFF"
              strokeWidth="10"
              strokeLinecap="round"
            />
            <path
              d="M 30,50 C 10,50 10,78 30,78"
              fill="none"
              stroke={strokeColor}
              strokeWidth={strokeWidth}
              strokeLinecap="round"
            />

            {/* Mug Head Base (slightly taller and narrower than Cuphead) */}
            <path
              d="M 30,40 C 30,26 80,26 80,40 C 80,75 30,75 30,40 Z"
              fill="#FFFFFF"
              stroke={strokeColor}
              strokeWidth={strokeWidth}
              strokeLinejoin="round"
            />

            {/* Blue Rim Liquid */}
            <path
              d="M 31,40 C 36,34 74,34 79,40 C 79,42 31,42 31,40 Z"
              fill="#3A8FD2"
              stroke={strokeColor}
              strokeWidth="1.5"
            />

            {/* Pie Eyes - Closer together, slightly larger */}
            {/* Left Eye */}
            <ellipse
              cx="49"
              cy="46"
              rx="9"
              ry="12"
              fill="#FFFFFF"
              stroke={strokeColor}
              strokeWidth={strokeWidth}
            />
            <ellipse cx="50" cy="47" rx="4.5" ry="6.5" fill="#1a1a1a" />
            <polygon points="50,47 55,43 55,51" fill="#FFFFFF" />

            {/* Right Eye */}
            <ellipse
              cx="67"
              cy="46"
              rx="9"
              ry="12"
              fill="#FFFFFF"
              stroke={strokeColor}
              strokeWidth={strokeWidth}
            />
            <ellipse cx="66" cy="47" rx="4.5" ry="6.5" fill="#1a1a1a" />
            <polygon points="66,47 61,43 61,51" fill="#FFFFFF" />

            {/* Large Blue Nose - Mugman signature! */}
            <ellipse
              cx="58"
              cy="56"
              rx="8"
              ry="6"
              fill="#3A8FD2"
              stroke={strokeColor}
              strokeWidth={strokeWidth}
            />

            {/* Wide happy mouth */}
            <path
              d="M 44,62 C 44,73 70,73 70,62"
              fill="#3A8FD2"
              stroke={strokeColor}
              strokeWidth={strokeWidth}
              strokeLinejoin="round"
            />
            <path
              d="M 46,64 C 52,66 62,66 68,64"
              stroke="#FFFFFF"
              strokeWidth="2.5"
              fill="none"
            />
          </g>
        </svg>
      );

    case "chalice":
      return (
        <svg
          width={size}
          height={size}
          viewBox="0 0 100 100"
          className={`overflow-visible select-none ${className}`}
          id={`avatar-chalice-${size}`}
        >
          <g>
            {/* Golden-Yellow & White striped straw */}
            <path
              d="M 50,12 L 56,7 L 70,17 L 64,22 Z"
              fill="#F4D160"
              stroke={strokeColor}
              strokeWidth={strokeWidth}
              strokeLinejoin="round"
            />
            <path
              d="M 56,7 L 59,2 L 73,12 L 70,17 Z"
              fill="#FFFFFF"
              stroke={strokeColor}
              strokeWidth={strokeWidth}
              strokeLinejoin="round"
            />
            <path
              d="M 45,28 L 50,12 L 64,22 L 59,38"
              fill="#FFFFFF"
              stroke={strokeColor}
              strokeWidth={strokeWidth}
              strokeLinejoin="round"
            />
            <path d="M 48,20 L 62,30" stroke={strokeColor} strokeWidth={strokeWidth} />

            {/* Double Handles (Chalice handles on both sides) */}
            {/* Left Handle */}
            <path
              d="M 30,48 C 16,42 16,62 30,58"
              fill="none"
              stroke="#F4D160"
              strokeWidth="6"
              strokeLinecap="round"
            />
            <path
              d="M 30,48 C 16,42 16,62 30,58"
              fill="none"
              stroke={strokeColor}
              strokeWidth={strokeWidth}
              strokeLinecap="round"
            />
            {/* Right Handle */}
            <path
              d="M 70,48 C 84,42 84,62 70,58"
              fill="none"
              stroke="#F4D160"
              strokeWidth="6"
              strokeLinecap="round"
            />
            <path
              d="M 70,48 C 84,42 84,62 70,58"
              fill="none"
              stroke={strokeColor}
              strokeWidth={strokeWidth}
              strokeLinecap="round"
            />

            {/* Chalice Cup Head - Elegant Goblet Shape */}
            <path
              d="M 30,38 C 30,30 70,30 70,38 C 70,62 58,68 58,74 L 64,76 L 64,80 L 36,80 L 36,76 L 42,74 C 42,68 30,62 30,38 Z"
              fill="#F4D160"
              stroke={strokeColor}
              strokeWidth={strokeWidth}
              strokeLinejoin="round"
            />

            {/* Inside Rim Liquid / Color */}
            <path
              d="M 31,38 C 35,34 65,34 69,38 C 69,40 31,40 31,38 Z"
              fill="#FFFFFF"
              stroke={strokeColor}
              strokeWidth="1.5"
            />

            {/* Pie Eyes with sweet eyelashes */}
            {/* Left Eye */}
            <ellipse
              cx="44"
              cy="48"
              rx="7"
              ry="10"
              fill="#FFFFFF"
              stroke={strokeColor}
              strokeWidth={strokeWidth}
            />
            <ellipse cx="44" cy="49" rx="3.5" ry="5.5" fill="#1a1a1a" />
            <polygon points="44,49 40,46 40,53" fill="#FFFFFF" />
            {/* Eyelash */}
            <path d="M 38,42 L 34,39" stroke={strokeColor} strokeWidth="2" strokeLinecap="round" />
            <path d="M 40,40 L 37,36" stroke={strokeColor} strokeWidth="2" strokeLinecap="round" />

            {/* Right Eye */}
            <ellipse
              cx="56"
              cy="48"
              rx="7"
              ry="10"
              fill="#FFFFFF"
              stroke={strokeColor}
              strokeWidth={strokeWidth}
            />
            <ellipse cx="56" cy="49" rx="3.5" ry="5.5" fill="#1a1a1a" />
            <polygon points="56,49 60,46 60,53" fill="#FFFFFF" />
            {/* Eyelash */}
            <path d="M 62,42 L 66,39" stroke={strokeColor} strokeWidth="2" strokeLinecap="round" />
            <path d="M 60,40 L 63,36" stroke={strokeColor} strokeWidth="2" strokeLinecap="round" />

            {/* Nose */}
            <circle cx="50" cy="54" r="2.5" fill="#D23A3A" stroke={strokeColor} strokeWidth="1.5" />

            {/* Cute rosy cheeks */}
            <circle cx="36" cy="54" r="3.5" fill="#EE7A7A" />
            <circle cx="64" cy="54" r="3.5" fill="#EE7A7A" />

            {/* Smile */}
            <path
              d="M 43,58 C 43,65 57,65 57,58"
              fill="none"
              stroke={strokeColor}
              strokeWidth={strokeWidth}
              strokeLinecap="round"
            />
          </g>
        </svg>
      );

    case "baroness":
      return (
        <svg
          width={size}
          height={size}
          viewBox="0 0 100 100"
          className={`overflow-visible select-none ${className}`}
          id={`avatar-baroness-${size}`}
        >
          <g>
            {/* Pink Frosted Ice Cream hair swirls */}
            <circle cx="50" cy="30" r="16" fill="#F48FB1" stroke={strokeColor} strokeWidth={strokeWidth} />
            <circle cx="38" cy="40" r="12" fill="#F48FB1" stroke={strokeColor} strokeWidth={strokeWidth} />
            <circle cx="62" cy="40" r="12" fill="#F48FB1" stroke={strokeColor} strokeWidth={strokeWidth} />
            <rect x="34" y="30" width="32" height="20" fill="#F48FB1" />

            {/* Crown */}
            <polygon
              points="40,20 44,12 50,17 56,12 60,20"
              fill="#F4D160"
              stroke={strokeColor}
              strokeWidth="2.5"
              strokeLinejoin="round"
            />
            <circle cx="44" cy="11" r="2" fill="#D23A3A" />
            <circle cx="50" cy="16" r="2" fill="#D23A3A" />
            <circle cx="56" cy="11" r="2" fill="#D23A3A" />

            {/* Face base */}
            <path
              d="M 36,46 C 36,40 64,40 64,46 C 64,64 36,64 36,46 Z"
              fill="#FFE0B2"
              stroke={strokeColor}
              strokeWidth={strokeWidth}
              strokeLinejoin="round"
            />

            {/* Side hair locks */}
            <path
              d="M 33,42 C 28,45 28,55 33,58 Z"
              fill="#F48FB1"
              stroke={strokeColor}
              strokeWidth="2"
            />
            <path
              d="M 67,42 C 72,45 72,55 67,58 Z"
              fill="#F48FB1"
              stroke={strokeColor}
              strokeWidth="2"
            />

            {/* Eyelash / Eyes */}
            <ellipse cx="44" cy="48" rx="5" ry="7" fill="#FFFFFF" stroke={strokeColor} strokeWidth="2.5" />
            <circle cx="44" cy="49" r="2.5" fill="#1a1a1a" />
            <path d="M 38,45 C 38,43 42,42 43,43" stroke={strokeColor} strokeWidth="2" fill="none" />

            <ellipse cx="56" cy="48" rx="5" ry="7" fill="#FFFFFF" stroke={strokeColor} strokeWidth="2.5" />
            <circle cx="56" cy="49" r="2.5" fill="#1a1a1a" />
            <path d="M 62,45 C 62,43 58,42 57,43" stroke={strokeColor} strokeWidth="2" fill="none" />

            {/* Nose */}
            <circle cx="50" cy="53" r="2" fill="#F48FB1" />

            {/* Smug rosy smile */}
            <path
              d="M 45,56 C 47,59 53,59 55,56"
              fill="none"
              stroke={strokeColor}
              strokeWidth={strokeWidth}
              strokeLinecap="round"
            />
            <circle cx="40" cy="54" r="2" fill="#FF8A80" />
            <circle cx="60" cy="54" r="2" fill="#FF8A80" />
          </g>
        </svg>
      );

    case "kingdice":
      return (
        <svg
          width={size}
          height={size}
          viewBox="0 0 100 100"
          className={`overflow-visible select-none ${className}`}
          id={`avatar-kingdice-${size}`}
        >
          <g>
            {/* Square Dice Head */}
            <rect
              x="26"
              y="26"
              width="48"
              height="48"
              rx="8"
              ry="8"
              fill="#FFFFFF"
              stroke={strokeColor}
              strokeWidth={strokeWidth}
            />

            {/* Dice dots on corners/sides (cheeks/head) */}
            <circle cx="32" cy="32" r="3" fill="#8E24AA" />
            <circle cx="68" cy="32" r="3" fill="#8E24AA" />
            <circle cx="32" cy="68" r="3" fill="#8E24AA" />
            <circle cx="68" cy="68" r="3" fill="#8E24AA" />

            {/* Green Eyes (or classic purple pie-eyes) */}
            {/* Left Eye */}
            <ellipse
              cx="41"
              cy="44"
              rx="6"
              ry="9"
              fill="#FFFFFF"
              stroke={strokeColor}
              strokeWidth="3"
            />
            <ellipse cx="41" cy="45" rx="3.5" ry="5.5" fill="#4CAF50" />
            <circle cx="41" cy="45" r="1.5" fill="#1a1a1a" />

            {/* Right Eye */}
            <ellipse
              cx="59"
              cy="44"
              rx="6"
              ry="9"
              fill="#FFFFFF"
              stroke={strokeColor}
              strokeWidth="3"
            />
            <ellipse cx="59" cy="45" rx="3.5" ry="5.5" fill="#4CAF50" />
            <circle cx="59" cy="45" r="1.5" fill="#1a1a1a" />

            {/* Devious thin Purple Mustache */}
            <path
              d="M 36,56 Q 44,53 50,56 Q 56,53 64,56 C 64,56 50,50 36,56"
              fill="#8E24AA"
              stroke={strokeColor}
              strokeWidth="1.5"
            />

            {/* Smiling mouth with teeth lines */}
            <path
              d="M 38,59 C 38,69 62,69 62,59 Z"
              fill="#FFFFFF"
              stroke={strokeColor}
              strokeWidth={strokeWidth}
              strokeLinejoin="round"
            />
            <path d="M 50,59 L 50,65" stroke={strokeColor} strokeWidth="1.5" />
            <path d="M 44,59 L 44,63" stroke={strokeColor} strokeWidth="1.5" />
            <path d="M 56,59 L 56,63" stroke={strokeColor} strokeWidth="1.5" />

            {/* Small violet nose */}
            <circle cx="50" cy="51" r="2.5" fill="#8E24AA" />

            {/* Bowtie showing at bottom */}
            <path
              d="M 40,74 L 50,78 L 60,74 L 55,83 L 45,83 Z"
              fill="#8E24AA"
              stroke={strokeColor}
              strokeWidth="2.5"
            />
            <circle cx="50" cy="77" r="3" fill="#D23A3A" />
          </g>
        </svg>
      );

    case "devil":
      return (
        <svg
          width={size}
          height={size}
          viewBox="0 0 100 100"
          className={`overflow-visible select-none ${className}`}
          id={`avatar-devil-${size}`}
        >
          <g>
            {/* Fire background */}
            <path
              d="M 22,70 Q 15,40 35,25 Q 50,10 65,25 Q 85,40 78,70 Z"
              fill="#FF7043"
              opacity="0.3"
            />
            <path
              d="M 30,70 Q 25,48 40,35 Q 50,22 60,35 Q 75,48 70,70 Z"
              fill="#F4D160"
              opacity="0.4"
            />

            {/* Horns: Yellow/Orange curved */}
            <path
              d="M 35,32 Q 22,12 28,8 Q 38,12 40,26 Z"
              fill="#F4D160"
              stroke={strokeColor}
              strokeWidth={strokeWidth}
            />
            <path
              d="M 65,32 Q 78,12 72,8 Q 62,12 60,26 Z"
              fill="#F4D160"
              stroke={strokeColor}
              strokeWidth={strokeWidth}
            />

            {/* Furry Head base */}
            <path
              d="M 28,45 C 24,35 76,35 72,45 C 72,68 62,76 50,82 C 38,76 28,68 28,45 Z"
              fill="#37474F"
              stroke={strokeColor}
              strokeWidth={strokeWidth}
              strokeLinejoin="round"
            />

            {/* Pointy ears */}
            <path
              d="M 29,42 L 18,36 L 27,48 Z"
              fill="#37474F"
              stroke={strokeColor}
              strokeWidth="2.5"
            />
            <path
              d="M 71,42 L 82,36 L 73,48 Z"
              fill="#37474F"
              stroke={strokeColor}
              strokeWidth="2.5"
            />

            {/* Glowing Yellow Eyes */}
            {/* Left Eye */}
            <polygon
              points="34,44 46,40 46,50 34,48"
              fill="#F4D160"
              stroke={strokeColor}
              strokeWidth="3"
            />
            <circle cx="42" cy="45" r="2.5" fill="#D23A3A" />

            {/* Right Eye */}
            <polygon
              points="66,44 54,40 54,50 66,48"
              fill="#F4D160"
              stroke={strokeColor}
              strokeWidth="3"
            />
            <circle cx="58" cy="45" r="2.5" fill="#D23A3A" />

            {/* Nose */}
            <polygon points="50,49 47,53 53,53" fill="#1a1a1a" />

            {/* Pointed tooth devious smile */}
            <path
              d="M 38,58 Q 50,70 62,58 Z"
              fill="#1a1a1a"
              stroke={strokeColor}
              strokeWidth={strokeWidth}
            />
            {/* Pointy teeth */}
            <polygon points="43,59 45,63 47,59" fill="#F4D160" />
            <polygon points="53,59 55,63 57,59" fill="#F4D160" />

            {/* Goatee beard */}
            <polygon
              points="46,80 50,92 54,80"
              fill="#1a1a1a"
              stroke={strokeColor}
              strokeWidth="2"
            />
          </g>
        </svg>
      );

    default:
      return <span className="text-2xl">{avatar}</span>;
  }
}
