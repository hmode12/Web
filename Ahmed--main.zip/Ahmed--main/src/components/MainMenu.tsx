/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from "react";
import { motion } from "motion/react";
import { audio } from "../audio";
import { User, GameSettings } from "../types";
import { t } from "../utils/i18n";
import { LogOut, Map, Trophy, ShoppingBag, Gift, User2, Settings, ShieldAlert } from "lucide-react";
import CharacterAvatar from "./CharacterAvatar";

interface MainMenuProps {
  user: User;
  onNavigate: (screen: string) => void;
  onLogout: () => void;
  settings: GameSettings;
}

export default function MainMenu({ user, onNavigate, onLogout, settings }: MainMenuProps) {
  const lang = settings.language || "ar";

  const playClick = () => {
    audio.playClick();
  };

  // Calculate Level based on XP
  const playerLevel = Math.floor(user.xp / 400) + 1;
  const xpInLevel = user.xp % 400;
  const xpProgressPercent = Math.min(100, (xpInLevel / 400) * 100);

  const getRoleLabel = () => {
    if (lang === "ar") {
      if (user.role === "Admin") return "المشرف";
      if (user.role === "Guest") return "زائر";
      return "مغامر";
    }
    return user.role;
  };

  return (
    <div className="relative w-full min-h-screen flex flex-col justify-between bg-[#F5E6CA] vignette-overlay py-6 px-4 md:px-8 select-none">
      
      {/* HEADER HUD */}
      <div className="w-full max-w-5xl mx-auto flex flex-wrap justify-between items-center gap-4 border-b-4 border-black pb-4 mb-4">
        {/* User Badge */}
        <div 
          onClick={() => { playClick(); onNavigate("profile"); }}
          className="flex items-center gap-3 cursor-pointer p-1 bg-[#E6D5B3] border-4 border-black shadow-[3px_3px_0_#1a1a1a] rounded-xl hover:translate-y-[-2px] transition-all"
        >
          <div className="w-12 h-12 bg-white rounded-full flex items-center justify-center border-2 border-black overflow-hidden">
            <CharacterAvatar avatar={user.avatar} size={40} />
          </div>
          <div className={`${lang === "ar" ? "pl-3 text-right" : "pr-3 text-left"}`}>
            <h3 className="font-display text-sm tracking-wide leading-none">{user.displayName}</h3>
            <span className="font-mono text-[10px] font-bold text-gray-700">
              {lang === "ar" ? `المستوى ${playerLevel}` : `LVL ${playerLevel}`} • {getRoleLabel()}
            </span>
          </div>
        </div>

        {/* HUD STATS (Coins, Stars, Hearts) */}
        <div className="flex items-center gap-4">
          {/* Hearts / Lives */}
          <div className="flex items-center gap-1.5 bg-[#E6D5B3] border-4 border-black px-3 py-1.5 shadow-[3px_3px_0_#1a1a1a] rounded-xl">
            <span className="text-xl">❤️</span>
            <div className="flex gap-1">
              {[1, 2, 3].map((heartNum) => (
                <span
                  key={heartNum}
                  className={`text-lg transition-all ${
                    heartNum <= user.lives ? "opacity-100" : "opacity-20"
                  }`}
                >
                  ❤️
                </span>
              ))}
            </div>
          </div>

          {/* Coins */}
          <div className="flex items-center gap-2 bg-[#E6D5B3] border-4 border-black px-3 py-1.5 shadow-[3px_3px_0_#1a1a1a] rounded-xl font-display text-lg">
            <span>🪙</span>
            <span className="font-display tracking-tight text-gray-800">{user.coins}</span>
          </div>

          {/* Stars */}
          <div className="flex items-center gap-2 bg-[#E6D5B3] border-4 border-black px-3 py-1.5 shadow-[3px_3px_0_#1a1a1a] rounded-xl font-display text-lg">
            <span>⭐</span>
            <span className="font-display tracking-tight text-gray-800">{user.stars}</span>
          </div>
        </div>
      </div>

      {/* CORE CORE BODY */}
      <div className="w-full max-w-5xl mx-auto grid grid-cols-1 md:grid-cols-12 gap-8 items-center my-auto">
        
        {/* Left Side: Animated Bouncy Cup Mascot */}
        <div className="md:col-span-5 flex flex-col items-center justify-center text-center">
          <div className="relative w-64 h-64 flex items-center justify-center bg-[#E6D5B3] border-8 border-black shadow-[8px_8px_0_#1a1a1a] rounded-3xl overflow-hidden mb-4">
            <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,_var(--tw-gradient-stops))] from-[#f4edd2] to-[#c9ba9c] opacity-60"></div>
            
            {/* Mascot Bouncing */}
            <div className="relative z-10 flex flex-col items-center justify-center">
              <div className="text-9xl rubber-hose-idle select-none pointer-events-none">🥛🔴</div>
              <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 text-2xl animate-pulse">
                🎼
              </div>
            </div>
            
            {/* Vintage borders inside card */}
            <div className="absolute inset-2 border-2 border-dashed border-black/40 rounded-2xl pointer-events-none"></div>
          </div>

          {/* XP Bar */}
          <div className="w-64">
            <div className="flex justify-between text-xs font-mono font-bold uppercase mb-1">
              <span>{lang === "ar" ? "التقدم عبر مستويات الخبرة" : "XP Progress"}</span>
              <span>{xpInLevel} / 400</span>
            </div>
            <div className="w-full h-5 bg-[#E6D5B3] border-4 border-black rounded-full overflow-hidden shadow-[2px_2px_0_#1a1a1a]">
              <div 
                className="h-full bg-[#D23A3A] transition-all duration-500 border-r-2 border-black" 
                style={{ width: `${xpProgressPercent}%` }}
              ></div>
            </div>
          </div>
        </div>

        {/* Right Side: Retro Menu Controls */}
        <div className="md:col-span-7 flex flex-col gap-4">
          
          <div className="text-center md:text-start mb-2">
            <h1 className="text-4xl md:text-5xl font-display text-[#D23A3A] filter drop-shadow-[2px_2px_0px_#1a1a1a]">
              {t("menu.title", lang)}
            </h1>
            <p className="text-sm font-handwritten text-gray-700 mt-1 max-w-md">
              {t("menu.subtitle", lang)}
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
            {/* Play / Adventure Map */}
            <button
              onClick={() => { playClick(); onNavigate("worlds"); }}
              className="cartoon-button text-lg p-4 flex items-center justify-center gap-3 bg-[#D23A3A] hover:bg-[#e54b4b] uppercase text-white font-display"
            >
              <Map className="w-6 h-6 stroke-[3]" />
              {t("menu.adventureMap", lang)}
            </button>

            {/* Shop */}
            <button
              onClick={() => { playClick(); onNavigate("shop"); }}
              className="cartoon-button text-lg p-4 flex items-center justify-center gap-3 bg-[#3A8FD2] hover:bg-[#4da6ec] uppercase text-white font-display"
            >
              <ShoppingBag className="w-6 h-6 stroke-[3]" />
              {t("menu.generalStore", lang)}
            </button>

            {/* Leaderboard */}
            <button
              onClick={() => { playClick(); onNavigate("leaderboard"); }}
              className="cartoon-button text-lg p-4 flex items-center justify-center gap-3 bg-[#F4D160] hover:bg-[#ffe066] text-[#1A1A1A] uppercase font-display"
            >
              <Trophy className="w-6 h-6 stroke-[3]" />
              {t("menu.hallOfFame", lang)}
            </button>

            {/* Daily Spin */}
            <button
              onClick={() => { playClick(); onNavigate("daily"); }}
              className="cartoon-button text-lg p-4 flex items-center justify-center gap-3 bg-[#5BB381] hover:bg-[#6ed199] uppercase text-white font-display"
            >
              <Gift className="w-6 h-6 stroke-[3]" />
              {t("menu.dailyFortune", lang)}
            </button>

            {/* Profile */}
            <button
              onClick={() => { playClick(); onNavigate("profile"); }}
              className="cartoon-button text-lg p-4 flex items-center justify-center gap-3 bg-[#5C3D2E] hover:bg-[#724c3a] uppercase text-white font-display"
            >
              <User2 className="w-6 h-6 stroke-[3]" />
              {t("menu.myJournal", lang)}
            </button>

            {/* Settings */}
            <button
              onClick={() => { playClick(); onNavigate("settings"); }}
              className="cartoon-button text-lg p-4 flex items-center justify-center gap-3 bg-zinc-600 hover:bg-zinc-500 uppercase text-white font-display"
            >
              <Settings className="w-6 h-6 stroke-[3]" />
              {t("menu.filmBooth", lang)}
            </button>

            {/* Admin Dashboard */}
            {user.role === "Admin" && (
              <button
                onClick={() => { playClick(); onNavigate("admin"); }}
                className="cartoon-button col-span-1 sm:col-span-2 text-lg p-4 flex items-center justify-center gap-3 bg-[#E6D5B3] text-[#D23A3A] border-[#D23A3A] hover:bg-red-50 hover:text-[#d23a3a] border-4 uppercase font-display"
              >
                <ShieldAlert className="w-6 h-6 text-[#D23A3A] animate-pulse" />
                {lang === "ar" ? "قاعة التحكم بالمشرف" : "Admin Desk / control room"}
              </button>
            )}
          </div>
        </div>
      </div>

      {/* FOOTER */}
      <div className="w-full max-w-5xl mx-auto flex justify-between items-center border-t-4 border-black pt-4 mt-6 text-xs font-mono font-bold text-gray-700 uppercase">
        <span>© 1930 LARAQUIZ INC.</span>
        <button 
          onClick={() => { playClick(); onLogout(); }}
          className="flex items-center gap-1.5 hover:text-[#D23A3A] transition-colors cursor-pointer"
        >
          <LogOut className="w-4 h-4" /> {lang === "ar" ? "تسجيل الخروج" : "Sign Out"}
        </button>
      </div>

      {/* Retro film scratches */}
      <div className="film-scratch-1"></div>
      <div className="film-scratch-2"></div>
    </div>
  );
}
