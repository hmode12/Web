/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from "react";
import { motion } from "motion/react";
import { audio } from "../audio";
import { LEADERBOARD_DATA } from "../data";
import { User, LeaderboardEntry, GameSettings } from "../types";
import { ArrowLeft, Trophy, Star, Award } from "lucide-react";
import CharacterAvatar from "./CharacterAvatar";

interface LeaderboardProps {
  user: User;
  onNavigate: (screen: string) => void;
  settings: GameSettings;
}

export default function Leaderboard({ user, onNavigate, settings }: LeaderboardProps) {
  const lang = settings.language || "ar";

  const playClick = () => {
    audio.playClick();
  };

  // Compile active list by merging the live user with simulated rival players
  const liveUserEntry: LeaderboardEntry = {
    username: user.username,
    displayName: `${user.displayName} ${lang === "ar" ? "(أنت)" : "(YOU)"}`,
    avatar: user.avatar,
    stars: user.stars,
    xp: user.xp,
    coins: user.coins
  };

  // Filter out any older user entries and append live user
  const cleanSimulatedList = LEADERBOARD_DATA.filter(
    (rival) => rival.username !== user.username
  );
  
  const combinedList = [...cleanSimulatedList, liveUserEntry];

  // Sort by stars descending, then XP descending
  const sortedLeaderboard = combinedList.sort((a, b) => {
    if (b.stars !== a.stars) {
      return b.stars - a.stars;
    }
    return b.xp - a.xp;
  });

  return (
    <div className="relative w-full min-h-screen bg-[#F5E6CA] vignette-overlay py-8 px-4 md:px-8 flex flex-col justify-between select-none">
      
      {/* HEADER HUD */}
      <div className="w-full max-w-5xl mx-auto flex justify-between items-center border-b-4 border-black pb-4 mb-6">
        <button
          onClick={() => { playClick(); onNavigate("menu"); }}
          className="cartoon-button text-xs md:text-sm px-4 py-2 flex items-center gap-1 bg-[#5C3D2E] text-white uppercase"
        >
          <ArrowLeft className="w-4 h-4 stroke-[3]" /> {lang === "ar" ? "القائمة" : "Menu"}
        </button>

        <h1 className="text-2xl md:text-4xl font-display text-[#D23A3A] tracking-wide filter drop-shadow-[2px_2px_0_#1a1a1a]">
          {lang === "ar" ? "لوحة الصدارة" : "HALL OF FAME"}
        </h1>

        <div className="flex items-center gap-1.5 bg-[#E6D5B3] border-4 border-black px-3 py-1 shadow-[2px_2px_0_#1a1a1a] rounded-xl text-xs font-mono font-bold uppercase">
          <Trophy className="w-4 h-4 text-yellow-600 fill-yellow-500" /> {lang === "ar" ? "المراكز الأولى" : "High Scores"}
        </div>
      </div>

      {/* LEADERS GRID */}
      <div className="w-full max-w-4xl mx-auto my-auto py-2">
        <p className="text-center font-handwritten text-gray-700 max-w-lg mx-auto mb-6 text-xs md:text-sm leading-relaxed">
          {lang === "ar" 
            ? "\"قائمة الأساطير الذين ملأوا أكوابهم حتى الحافة! اجمع النجوم من المستويات لترتقي في القائمة وتطالب بالتاج!\"" 
            : "\"The list of legends who filled their cups to the brim! Earn stars from stages to climb the list and claim your crown.\""}
        </p>

        {/* Scoreboard Sheet */}
        <div className="vintage-paper-panel p-5 rounded-3xl border-4 shadow-[8px_8px_0_rgba(0,0,0,1)] flex flex-col gap-3 max-h-[55vh] overflow-y-auto vintage-flicker">
          {sortedLeaderboard.map((entry, idx) => {
            const isUser = entry.username === user.username;
            const rank = idx + 1;

            // Define Crown style for Top 3
            let rankCrown = "";
            let rankColor = "text-gray-800";
            if (rank === 1) {
              rankCrown = "👑";
              rankColor = "text-amber-500 font-extrabold";
            } else if (rank === 2) {
              rankCrown = "🥈";
              rankColor = "text-zinc-500 font-extrabold";
            } else if (rank === 3) {
              rankCrown = "🥉";
              rankColor = "text-amber-850 font-extrabold";
            }

            return (
              <div
                key={entry.username}
                className={`flex justify-between items-center p-3 border-4 border-black rounded-xl shadow-[2px_2px_0_rgba(0,0,0,1)] transition-all ${
                  isUser 
                    ? "bg-[#D23A3A] text-white border-black scale-[1.01] shadow-[3px_3px_0_rgba(0,0,0,1)] font-bold" 
                    : "bg-white text-black hover:bg-yellow-50"
                }`}
              >
                {/* Left side: Rank, Avatar and Display Name */}
                <div className="flex items-center gap-3.5">
                  <div className="font-display w-8 text-center text-lg flex items-center justify-center gap-1">
                    {rankCrown ? (
                      <span className="text-2xl">{rankCrown}</span>
                    ) : (
                      <span className={`font-display ${rankColor}`}>{rank}</span>
                    )}
                  </div>

                  {/* Character Avatar */}
                  <div className="w-10 h-10 rounded-full bg-[#E6D5B3] border-2 border-black flex items-center justify-center flex-shrink-0 shadow-[1px_1px_0_rgba(0,0,0,1)] overflow-hidden">
                    <CharacterAvatar avatar={entry.avatar} size={32} />
                  </div>

                  <div>
                    <h4 className="font-sans text-sm md:text-base leading-tight">
                      {entry.displayName}
                    </h4>
                    <span className={`font-mono text-[9px] block leading-none uppercase ${isUser ? "text-red-200" : "text-gray-500"}`}>
                      {lang === "ar" ? `${entry.xp} نقطة خبرة` : `${entry.xp} XP points`}
                    </span>
                  </div>
                </div>

                {/* Right side: Stars and Coins */}
                <div className="flex items-center gap-5">
                  {/* Stars column */}
                  <div className="flex items-center gap-1 text-sm font-display">
                    <Star className={`w-4 h-4 ${isUser ? "fill-white text-[#D23A3A]" : "fill-yellow-400 text-black"} stroke-[2.5]`} />
                    <span className="font-display">{entry.stars}</span>
                  </div>

                  {/* Coins column */}
                  <div className={`font-mono text-xs font-bold ${isUser ? "text-red-100" : "text-gray-600"} uppercase hidden sm:block`}>
                    🪙 {entry.coins}
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* FOOTER */}
      <div className="w-full max-w-5xl mx-auto flex justify-between items-center border-t-4 border-black pt-4 mt-8 text-xs font-mono font-bold text-gray-700 uppercase">
        <span>{lang === "ar" ? "تزامن الصدارة: نشط" : "Leaderboard synced: Online"}</span>
        <span>Reel: No. 104 • 1930s Film</span>
      </div>

      {/* Retro film scratches */}
      <div className="film-scratch-1"></div>
      <div className="film-scratch-2"></div>
    </div>
  );
}
