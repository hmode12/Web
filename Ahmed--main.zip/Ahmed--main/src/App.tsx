/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from "react";
import { User, GameSettings, Question, ShopItem } from "./types";
import { WORLDS, ACHIEVEMENTS, getQuestionForLevel } from "./data";
import { audio } from "./audio";

// Sub-components
import Splash from "./components/Splash";
import Auth from "./components/Auth";
import MainMenu from "./components/MainMenu";
import WorldSelection from "./components/WorldSelection";
import LevelSelection from "./components/LevelSelection";
import QuestionScreen from "./components/QuestionScreen";
import ResultScreen from "./components/ResultScreen";
import Profile from "./components/Profile";
import Shop from "./components/Shop";
import Leaderboard from "./components/Leaderboard";
import DailyReward from "./components/DailyReward";
import SettingsScreen from "./components/SettingsScreen";
import AdminDashboard from "./components/AdminDashboard";

export default function App() {
  // ROUTING SCREEN STATE
  const [screen, setScreen] = useState<string>("splash");

  // AUTH USER STATE
  const [user, setUser] = useState<User | null>(null);

  // SELECTIONS STATE
  const [activeWorldId, setActiveWorldId] = useState<number>(1);
  const [activeLevelId, setActiveLevelId] = useState<number>(1);

  // GAME ENGINE RESULTS STATE
  const [lastAnswerCorrect, setLastAnswerCorrect] = useState<boolean>(false);
  const [lastAnswerSpeedBonus, setLastAnswerSpeedBonus] = useState<boolean>(false);
  const [lastAnswerUsedReveal, setLastAnswerUsedReveal] = useState<boolean>(false);
  const [lastQuestionPlayed, setLastQuestionPlayed] = useState<Question | null>(null);

  // GAME SETTINGS STATE
  const [settings, setSettings] = useState<GameSettings>({
    musicVolume: 0.35,
    effectsVolume: 0.5,
    isMuted: false,
    visualFilter: "color",
    showScratches: true,
    language: "ar"
  });

  // مزامنة حالة اتجاه النص (RTL/LTR) وحفظ الإعدادات بمجرد تغير الـ settings
  useEffect(() => {
    localStorage.setItem("laraquiz_settings", JSON.stringify(settings));
    
    if (settings.language === "ar") {
      document.documentElement.dir = "rtl";
      document.documentElement.lang = "ar";
    } else {
      document.documentElement.dir = "ltr";
      document.documentElement.lang = "en";
    }

    audio.setVolumes(settings.musicVolume, settings.effectsVolume, settings.isMuted);
    if (settings.isMuted) {
      audio.stopMusic();
    } else {
      if (user) {
        audio.startMusic();
      }
    }
  }, [settings, user]);

  // استرجاع الإعدادات المحفوظة والجلسة النشطة
  useEffect(() => {
    const cachedSettings = localStorage.getItem("laraquiz_settings");
    if (cachedSettings) {
      try {
        setSettings(JSON.parse(cachedSettings));
      } catch (e) { /* ignore */ }
    }

    const cachedUser = localStorage.getItem("laraquiz_active_user");
    if (cachedUser) {
      try {
        const parsedUser = JSON.parse(cachedUser);
        setUser(parsedUser);
        setScreen("menu");
      } catch (e) { /* ignore */ }
    }
  }, []);

  // passive heart recovery checker
  useEffect(() => {
    if (!user) return;
    const RECOVERY_INTERVAL_MS = 300000;
    const interval = setInterval(() => {
      setUser((current) => {
        if (!current || current.lives >= 3) return current;
        const timePassed = Date.now() - current.lastHeartRestoreTime;
        const heartsToRestore = Math.floor(timePassed / RECOVERY_INTERVAL_MS);
        if (heartsToRestore > 0) {
          const newLives = Math.min(3, current.lives + heartsToRestore);
          const remainderTime = timePassed % RECOVERY_INTERVAL_MS;
          const updatedUser = { ...current, lives: newLives, lastHeartRestoreTime: Date.now() - remainderTime };
          saveUserLocally(updatedUser);
          return updatedUser;
        }
        return current;
      });
    }, 15000);
    return () => clearInterval(interval);
  }, [user]);

  // Sync state helpers
  const saveUserLocally = (updatedUser: User) => {
    localStorage.setItem("laraquiz_active_user", JSON.stringify(updatedUser));
    localStorage.setItem(`user_${updatedUser.username}`, JSON.stringify(updatedUser));
  };

  const updateSettings = (newSettings: Partial<GameSettings>) => {
    setSettings((prev) => ({ ...prev, ...newSettings }));
  };

  // Auth & Game Handlers
  const handleAuthSuccess = (authenticatedUser: User) => {
    setUser(authenticatedUser);
    saveUserLocally(authenticatedUser);
    setScreen("menu");
  };

  const handleLogout = () => {
    audio.stopMusic();
    audio.playClick();
    setUser(null);
    localStorage.removeItem("laraquiz_active_user");
    setScreen("auth");
  };

  const handleDeductCoinsInGame = (amount: number): boolean => {
    if (!user || user.coins < amount) return false;
    const updatedUser = { ...user, coins: user.coins - amount };
    setUser(updatedUser);
    saveUserLocally(updatedUser);
    return true;
  };

  const handleBuyItem = (item: ShopItem) => {
    if (!user) return;
    let updatedUser = { ...user };
    updatedUser.coins -= item.price;
    updatedUser.inventory = [...updatedUser.inventory, item.id];
    setUser(updatedUser);
    saveUserLocally(updatedUser);
  };

  const handleClaimDailyReward = (rewardType: "coins" | "xp" | "hearts", amount: number) => {
    if (!user) return;
    let updatedUser = { ...user, lastDailyClaimTime: Date.now(), dailyStreak: user.dailyStreak + 1 };
    if (rewardType === "coins") updatedUser.coins += amount;
    else if (rewardType === "xp") updatedUser.xp += amount;
    else if (rewardType === "hearts") updatedUser.lives = 3;
    setUser(updatedUser);
    saveUserLocally(updatedUser);
  };

  const handleEquipAvatar = (avatarImage: string) => {
    if (!user) return;
    const updatedUser = { ...user, avatar: avatarImage };
    setUser(updatedUser);
    saveUserLocally(updatedUser);
  };

  const handleAdminUpdateUserStats = (targetUsername: string, updates: Partial<User>) => {
    if (user?.username === targetUsername) {
      const updated = { ...user, ...updates };
      setUser(updated);
      saveUserLocally(updated);
    }
  };

  const handleAddCustomQuestion = (worldId: number, q: Question) => {
    const customKey = `custom_questions_world_${worldId}`;
    const cached = localStorage.getItem(customKey) || "[]";
    const parsedList = JSON.parse(cached);
    parsedList.push(q);
    localStorage.setItem(customKey, JSON.stringify(parsedList));
  };

  const handleAnswerResult = (correct: boolean, speedBonus: boolean, usedReveal: boolean, question: Question) => {
    if (!user) return;
    setLastAnswerCorrect(correct);
    setLastAnswerSpeedBonus(speedBonus);
    setLastAnswerUsedReveal(usedReveal);
    setLastQuestionPlayed(question);
    let updatedUser = { ...user };
    if (correct) {
      updatedUser.coins += 100;
      updatedUser.xp += speedBonus ? 150 : 100;
      const starsEarned = !usedReveal && speedBonus ? 3 : !usedReveal || speedBonus ? 2 : 1;
      const prev = user.completedLevels[activeLevelId] || 0;
      if (starsEarned > prev) {
        updatedUser.completedLevels[activeLevelId] = starsEarned;
        updatedUser.stars += (starsEarned - prev);
      }
      if (activeLevelId === user.currentLevelId) updatedUser.currentLevelId = activeLevelId + 1;
    } else {
      updatedUser.lives = Math.max(0, user.lives - 1);
    }
    setUser(updatedUser);
    saveUserLocally(updatedUser);
    setScreen("result");
  };

  const getDynamicFilterStyle = () => {
    let filterString = "";
    if (settings.visualFilter === "bw") filterString = "grayscale(100%) contrast(125%) brightness(95%)";
    else if (settings.visualFilter === "sepia") filterString = "sepia(80%) saturate(140%) contrast(95%) brightness(96%)";
    return { filter: filterString || "none", WebkitFilter: filterString || "none" };
  };

  return (
    <div dir={settings.language === "ar" ? "rtl" : "ltr"} className="relative w-full min-h-screen overflow-x-hidden vintage-flicker" style={getDynamicFilterStyle()}>
      <div className="film-grain"></div>
      {settings.showScratches && (
        <div style={{ pointerEvents: 'none', position: 'fixed', inset: 0, zIndex: 50, opacity: 0.15 }}>
          <div className="film-scratch-1"></div>
          <div className="film-scratch-2"></div>
        </div>
      )}

      {screen === "splash" && <Splash onStartGame={() => setScreen(user ? "menu" : "auth")} settings={settings} />}
      {screen === "auth" && <Auth onAuthSuccess={handleAuthSuccess} settings={settings} />}
      {screen === "menu" && user && <MainMenu user={user} onNavigate={setScreen} onLogout={handleLogout} settings={settings} />}
      {screen === "worlds" && user && <WorldSelection user={user} onSelectWorld={(id) => { setActiveWorldId(id); setScreen("levels"); }} onNavigate={setScreen} settings={settings} />}
      {screen === "levels" && user && <LevelSelection user={user} worldId={activeWorldId} onSelectLevel={(id) => { setActiveLevelId(id); setScreen("question"); }} onNavigate={setScreen} settings={settings} />}
      {screen === "question" && user && <QuestionScreen user={user} levelId={activeLevelId} onNavigate={setScreen} onAnswerResult={handleAnswerResult} settings={settings} deductCoins={handleDeductCoinsInGame} />}
      {screen === "result" && user && lastQuestionPlayed && <ResultScreen correct={lastAnswerCorrect} speedBonus={lastAnswerSpeedBonus} usedReveal={lastAnswerUsedReveal} question={lastQuestionPlayed} coinsEarned={lastAnswerCorrect ? 100 : 0} xpEarned={lastAnswerCorrect ? 100 : 0} starsEarned={lastAnswerCorrect ? 2 : 0} livesRemaining={user.lives} onNextLevel={() => setScreen("levels")} onRetry={() => setScreen("question")} onBackToLevels={() => setScreen("levels")} settings={settings} />}
      {screen === "profile" && user && <Profile user={user} onNavigate={setScreen} onEquipAvatar={handleEquipAvatar} settings={settings} />}
      {screen === "shop" && user && <Shop user={user} onNavigate={setScreen} onBuyItem={handleBuyItem} settings={settings} />}
      {screen === "leaderboard" && user && <Leaderboard user={user} onNavigate={setScreen} settings={settings} />}
      {screen === "daily" && user && <DailyReward user={user} onNavigate={setScreen} onClaimReward={handleClaimDailyReward} settings={settings} />}
      {screen === "settings" && <SettingsScreen settings={settings} onNavigate={setScreen} onUpdateSettings={updateSettings} />}
      {screen === "admin" && user && user.role === "Admin" && <AdminDashboard user={user} onNavigate={setScreen} onUpdateUserStats={handleAdminUpdateUserStats} onAddCustomQuestion={handleAddCustomQuestion} settings={settings} />}
    </div>
  );
}