/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export type Language = "ar" | "en";

export const TRANSLATIONS = {
  ar: {
    // Splash Screen
    "splash.title": "تحدي لاراكويز",
    "splash.subtitle": "اختبر معلوماتك في الثقافة العامة، الرياضة، العلوم والمزيد! هل أنت مستعد للتحدي؟",
    "splash.pressStart": "اضغط هنا لبدء التحدي",
    "splash.audioLoaded": "تم تحميل النظام الصوتي بنجاح!",

    // Auth Screen
    "auth.title": "تسجيل الدخول للمسابقة",
    "auth.desc": "أدخل اسمك لتبدأ رحلتك في عالم المعرفة وتنافس آلاف اللاعبين على الصدارة!",
    "auth.displayName": "اسم اللاعب",
    "auth.email": "البريد الإلكتروني (اختياري)",
    "auth.button": "دخول وبدء اللعب",
    "auth.placeholder": "مثال: بطل المعرفة",
    "auth.secureNotice": "بياناتك وتقدمك محفوظ بشكل آمن على جهازك",

    // Main Menu
    "menu.title": "القائمة الرئيسية",
    "menu.subtitle": "اختر القسم الذي تود اكتشافه، أجب عن الأسئلة، واجمع النقاط لتتصدر الترتيب!",
    "menu.adventureMap": "خريطة المعرفة",
    "menu.generalStore": "متجر المساعدات",
    "menu.hallOfFame": "لوحة أوائل العباقرة",
    "menu.dailyFortune": "المكافأة اليومية",
    "menu.myJournal": "ملفي الشخصي",
    "menu.filmBooth": "إعدادات التطبيق",
    "menu.play": "العب الآن",
    "menu.profile": "حسابي وإنجازاتي",
    "menu.shop": "متجر النقاط والمساعدات",
    "menu.leaderboard": "ترتيب اللاعبين",
    "menu.daily": "مكافأة كل يوم",
    "menu.settings": "الإعدادات والمظهر",
    "menu.admin": "لوحة الإدارة",
    "menu.logout": "تسجيل الخروج",
    "menu.welcome": "أهلاً بك يا بطل:",

    // World Selection
    "worlds.title": "موسوعة العوالم",
    "worlds.subtitle": "كل عالم يحتوي على أسئلة ومجالات جديدة. اجمع النجوم من إجاباتك لفتح العوالم المغلقة!",
    "worlds.locked": "عالم مغلق",
    "worlds.reqStars": "نجمة مطلوبة لفتح هذا العالم!",
    "worlds.backMenu": "العودة للقائمة",

    // Level Selection
    "levels.title": "مراحل التحدي",
    "levels.world": "التصنيف الحالي:",
    "levels.stage": "المرحلة",
    "levels.starsReq": "النجوم المطلوبة للبدء:",
    "levels.backMap": "خريطة العوالم",
    "levels.lockedStage": "المرحلة مقفلة! أجب عن المراحل السابقة بنجاح لفتحها.",

    // Question Screen
    "question.hearts": "المحاولات المتبقية",
    "question.coins": "العملات الذهبية",
    "question.stars": "النجوم المكتسبة",
    "question.speedActive": "مكافأة الإجابة السريعة نشطة! ⚡",
    "question.speedExpired": "انتهى وقت السرعة ⏳",
    "question.helpText": "ركز جيداً واختر الإجابة الصحيحة قبل انتهاء الوقت المتبقي!",
    "question.revealPowerup": "حذف إجابتين (50🪙)",
    "question.skipPowerup": "تخطي السؤال (100🪙)",
    "question.timePowerup": "إضافة وقت +15ث (30🪙)",
    "question.warning": "تنبيه مساعدة",

    // Result Screen
    "result.correct": "إجابة صحيحة! معلوماتك ممتازة!",
    "result.wrong": "إجابة خاطئة! حظاً أوفر في السؤال القادم",
    "result.scoreCard": "بطاقة النتيجة والتفاصيل",
    "result.speedBonus": "مكافأة السرعة والبديهة! (+50 خبرة)",
    "result.cheatPenalty": "تم خصم نقاط لاستخدام وسائل المساعدة",
    "result.goldEarned": "العملات المكتسبة:",
    "result.xpEarned": "نقاط الخبرة:",
    "result.starsEarned": "النجوم المحصلة:",
    "result.heartsLeft": "المحاولات المتبقية:",
    "result.next": "المرحلة التالية",
    "result.retry": "إعادة المحاولة",
    "result.backMap": "العودة للتصنيفات",

    // Profile Screen
    "profile.title": "الملف الشخصي للاعب",
    "profile.level": "مستوى التقدم",
    "profile.changeAvatar": "تغيير الصورة الرمزية (الأفاتار)",
    "profile.medalsTitle": "الإنجازات والأوسمة المكتسبة",
    "profile.xpLogged": "إجمالي نقاط الخبرة:",
    "profile.reelInfo": "معرف اللاعب: 104 • تطبيق لارا كويز",

    // Shop Screen
    "shop.title": "متجر المساعدات",
    "shop.subtitle": "استخدم عملاتك الذهبية لشراء وسائل مساعدة لتخطي الأسئلة الصعبة أو صور رمزية جديدة لتميز حسابك!",
    "shop.wallet": "رصيد العملات:",
    "shop.owned": "مملوك بالفعل ✅",
    "shop.heartsFull": "المحاولات ممتلئة ❤️",
    "shop.buyButton": "شراء",
    "shop.noFunds": "رصيدك لا يكفي! أجب عن المزيد من الأسئلة في المراحل لجمع العملات.",

    // Leaderboard Screen
    "leaderboard.title": "لوحة الصدارة والترتيب",
    "leaderboard.subtitle": "تعرف على أفضل اللاعبين وأكثرهم ثقافة. أجب بشكل صحيح لتجمع النجوم وتصل إلى المركز الأول!",
    "leaderboard.sync": "حالة الاتصال: متصل بالشبكة",

    // Daily Spin Screen
    "daily.title": "المكافآت اليومية",
    "daily.subtitle": "سجل دخولك كل يوم واحصل على مكافآت مجانية (عملات، قلوب، أو خبرة) تساعدك في تقدمك!",
    "daily.spinButton": "احصل على مكافأتك",
    "daily.spinning": "جاري تحديد المكافأة...",
    "daily.cooldown": "لقد حصلت على مكافأة اليوم!",
    "daily.nextClaim": "المكافأة القادمة تتوفر بعد:",
    "daily.prizeClaimed": "مبروك! لقد حصلت على:",

    // Settings Screen
    "settings.title": "إعدادات التطبيق",
    "settings.subtitle": "قم بتخصيص إعدادات الصوت والمظهر بما يناسبك لتجربة لعب مريحة.",
    "settings.audio": "إعدادات الصوت",
    "settings.mute": "كتم جميع الأصوات والموسيقى",
    "settings.musicVol": "مستوى موسيقى الخلفية",
    "settings.sfxVol": "مستوى المؤثرات الصوتية",
    "settings.theme": "المظهر المرئي",
    "settings.printColor": "سمة ألوان التطبيق",
    "settings.filterColor": "الألوان الافتراضية الساطعة",
    "settings.filterSepia": "ألوان دافئة (مريحة للعين)",
    "settings.filterBw": "نمط الأبيض والأسود",
    "settings.scratches": "تفعيل تأثير الرسوم المتحركة في الخلفية",
    "settings.language": "لغة الواجهة (Language)",
    "settings.ar": "العربية (Arabic)",
    "settings.en": "الإنجليزية (English)",

    // Admin Dashboard
    "admin.title": "لوحة الإدارة والتحكم",
    "admin.tabs.players": "إدارة اللاعبين",
    "admin.tabs.create": "إضافة أسئلة جديدة",
    "admin.tabs.worlds": "إعدادات التصنيفات",
    "admin.tabs.logs": "سجل النظام",
    "admin.searchPlaceholder": "ابحث عن لاعب بالاسم..."
  },
  en: {
    // Splash Screen
    "splash.title": "LaraQuiz Challenge",
    "splash.subtitle": "Test your knowledge in culture, sports, science, and more! Are you ready for the challenge?",
    "splash.pressStart": "Tap to Start Playing",
    "splash.audioLoaded": "Audio system loaded successfully!",

    // Auth Screen
    "auth.title": "Player Login",
    "auth.desc": "Enter your name to begin your journey in the world of knowledge and compete with thousands of players!",
    "auth.displayName": "Player Name",
    "auth.email": "Email Address (Optional)",
    "auth.button": "Enter and Play",
    "auth.placeholder": "e.g., Trivia Master",
    "auth.secureNotice": "Your data and progress are securely saved on your device",

    // Main Menu
    "menu.title": "Main Menu",
    "menu.subtitle": "Choose a category, answer questions, and collect points to climb the leaderboard!",
    "menu.adventureMap": "Knowledge Map",
    "menu.generalStore": "Help Store",
    "menu.hallOfFame": "Hall of Geniuses",
    "menu.dailyFortune": "Daily Reward",
    "menu.myJournal": "My Profile",
    "menu.filmBooth": "App Settings",
    "menu.play": "Play Now",
    "menu.profile": "My Profile & Achievements",
    "menu.shop": "Points & Helpers Store",
    "menu.leaderboard": "Player Leaderboard",
    "menu.daily": "Daily Bonus",
    "menu.settings": "Settings & Theme",
    "menu.admin": "Admin Dashboard",
    "menu.logout": "Log Out",
    "menu.welcome": "Welcome back, champion:",

    // World Selection
    "worlds.title": "Encyclopedia of Worlds",
    "worlds.subtitle": "Each world contains new questions and fields. Collect stars from your answers to unlock closed worlds!",
    "worlds.locked": "Locked World",
    "worlds.reqStars": "Stars required to unlock this world!",
    "worlds.backMenu": "Back to Menu",

    // Level Selection
    "levels.title": "Challenge Stages",
    "levels.world": "Current Category:",
    "levels.stage": "Stage",
    "levels.starsReq": "Stars required to start:",
    "levels.backMap": "Worlds Map",
    "levels.lockedStage": "Stage locked! Answer previous stages successfully to unlock it.",

    // Question Screen
    "question.hearts": "Remaining Attempts",
    "question.coins": "Gold Coins",
    "question.stars": "Earned Stars",
    "question.speedActive": "Fast answer bonus is active! ⚡",
    "question.speedExpired": "Speed time is up ⏳",
    "question.helpText": "Focus and choose the correct answer before the time runs out!",
    "question.revealPowerup": "Remove 2 options (50🪙)",
    "question.skipPowerup": "Skip Question (100🪙)",
    "question.timePowerup": "Add Time +15s (30🪙)",
    "question.warning": "Helper Alert",

    // Result Screen
    "result.correct": "Correct answer! Excellent knowledge!",
    "result.wrong": "Wrong answer! Better luck on the next question",
    "result.scoreCard": "Score and Details",
    "result.speedBonus": "Speed and reflex bonus! (+50 XP)",
    "result.cheatPenalty": "Points deducted for using helpers",
    "result.goldEarned": "Coins Earned:",
    "result.xpEarned": "Experience Points:",
    "result.starsEarned": "Collected Stars:",
    "result.heartsLeft": "Remaining Attempts:",
    "result.next": "Next Stage",
    "result.retry": "Try Again",
    "result.backMap": "Back to Categories",

    // Profile Screen
    "profile.title": "Player Profile",
    "profile.level": "Progress Level",
    "profile.changeAvatar": "Change Avatar",
    "profile.medalsTitle": "Earned Achievements & Medals",
    "profile.xpLogged": "Total Experience Points:",
    "profile.reelInfo": "Player ID: 104 • LaraQuiz App",

    // Shop Screen
    "shop.title": "Helpers Store",
    "shop.subtitle": "Use your gold coins to buy helpers to skip hard questions or get new avatars to stand out!",
    "shop.wallet": "Coin Balance:",
    "shop.owned": "Already Owned ✅",
    "shop.heartsFull": "Attempts Full ❤️",
    "shop.buyButton": "Buy",
    "shop.noFunds": "Not enough balance! Answer more questions in stages to collect coins.",

    // Leaderboard Screen
    "leaderboard.title": "Leaderboard",
    "leaderboard.subtitle": "Discover the best and most knowledgeable players. Answer correctly to collect stars and reach the top spot!",
    "leaderboard.sync": "Connection Status: Online",

    // Daily Spin Screen
    "daily.title": "Daily Rewards",
    "daily.subtitle": "Log in every day to get free rewards (coins, hearts, or XP) to help you progress!",
    "daily.spinButton": "Claim Your Reward",
    "daily.spinning": "Determining reward...",
    "daily.cooldown": "You already claimed today's reward!",
    "daily.nextClaim": "Next reward available in:",
    "daily.prizeClaimed": "Congratulations! You got:",

    // Settings Screen
    "settings.title": "App Settings",
    "settings.subtitle": "Customize audio and theme settings for a comfortable gaming experience.",
    "settings.audio": "Audio Settings",
    "settings.mute": "Mute all sounds and music",
    "settings.musicVol": "Background Music Volume",
    "settings.sfxVol": "Sound Effects Volume",
    "settings.theme": "Visual Theme",
    "settings.printColor": "App Color Theme",
    "settings.filterColor": "Default Bright Colors",
    "settings.filterSepia": "Warm Colors (Eye-friendly)",
    "settings.filterBw": "Black and White Mode",
    "settings.scratches": "Enable background animation effects",
    "settings.language": "Interface Language",
    "settings.ar": "Arabic (العربية)",
    "settings.en": "English (الإنجليزية)",

    // Admin Dashboard
    "admin.title": "Admin Dashboard",
    "admin.tabs.players": "Player Management",
    "admin.tabs.create": "Add New Questions",
    "admin.tabs.worlds": "Categories Settings",
    "admin.tabs.logs": "System Log",
    "admin.searchPlaceholder": "Search for a player by name..."
  }
};

export function t(key: keyof typeof TRANSLATIONS.ar, lang: Language): string {
  const dict = TRANSLATIONS[lang] || TRANSLATIONS.ar;
  return dict[key] || TRANSLATIONS.ar[key] || String(key);
}