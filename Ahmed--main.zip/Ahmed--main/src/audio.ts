/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

class RetroAudioEngine {
  private ctx: AudioContext | null = null;
  private musicNode: ScriptProcessorNode | null = null; // or synth loop
  private synthInterval: any = null;
  private musicVolumeNode: GainNode | null = null;
  private fxVolumeNode: GainNode | null = null;
  private masterVolumeNode: GainNode | null = null;
  private isMusicPlaying = false;
  private notesPlayed = 0;

  // Retro ragtime progression (honky-tonk notes)
  private melodyNotes = [
    // World 1/Main Theme: Ragtime bouncy tune (C major / A minor pentatonic)
    261.63, 329.63, 392.00, 440.00, 392.00, 329.63, 261.63, 293.66,
    329.63, 329.63, 349.23, 392.00, 440.00, 392.00, 349.23, 329.63,
    293.66, 349.23, 440.00, 493.88, 440.00, 349.23, 293.66, 329.63,
    392.00, 392.00, 440.00, 493.88, 523.25, 493.88, 440.00, 392.00
  ];

  constructor() {
    // Audio Context is initialized on first user interaction
  }

  private initCtx() {
    if (!this.ctx) {
      this.ctx = new (window.AudioContext || (window as any).webkitAudioContext)();
      
      this.masterVolumeNode = this.ctx.createGain();
      this.musicVolumeNode = this.ctx.createGain();
      this.fxVolumeNode = this.ctx.createGain();

      this.musicVolumeNode.connect(this.masterVolumeNode);
      this.fxVolumeNode.connect(this.masterVolumeNode);
      this.masterVolumeNode.connect(this.ctx.destination);

      this.masterVolumeNode.gain.setValueAtTime(0.5, this.ctx.currentTime);
      this.musicVolumeNode.gain.setValueAtTime(0.35, this.ctx.currentTime);
      this.fxVolumeNode.gain.setValueAtTime(0.5, this.ctx.currentTime);
    }
    if (this.ctx.state === "suspended") {
      this.ctx.resume();
    }
  }

  setVolumes(music: number, fx: number, isMuted: boolean) {
    this.initCtx();
    if (!this.ctx || !this.masterVolumeNode || !this.musicVolumeNode || !this.fxVolumeNode) return;
    
    const time = this.ctx.currentTime;
    this.masterVolumeNode.gain.setValueAtTime(isMuted ? 0 : 0.6, time);
    this.musicVolumeNode.gain.setValueAtTime(music, time);
    this.fxVolumeNode.gain.setValueAtTime(fx, time);
  }

  startMusic() {
    this.initCtx();
    if (this.isMusicPlaying) return;
    this.isMusicPlaying = true;
    
    let step = 0;
    const tempo = 220; // BPM
    const noteLength = 60 / tempo; // Eighth note duration in seconds

    this.synthInterval = setInterval(() => {
      if (!this.isMusicPlaying || !this.ctx || this.ctx.state === "suspended") return;

      const time = this.ctx.currentTime;
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();

      // Detuned honky-tonk sound: combine triangle wave and slight detune
      osc.type = "triangle";
      
      // Let's create a cute ragtime base line & melody alternating
      let freq = this.melodyNotes[step % this.melodyNotes.length];
      
      // Every even step, add a bass walk
      if (step % 2 === 0) {
        freq = freq / 2; // Octave lower for bass
      }

      osc.frequency.setValueAtTime(freq, time);
      // Slight detuning for saloon style
      osc.detune.setValueAtTime(8, time); 

      gain.gain.setValueAtTime(0.12, time);
      gain.gain.exponentialRampToValueAtTime(0.001, time + noteLength * 0.9);

      osc.connect(gain);
      gain.connect(this.musicVolumeNode!);
      
      osc.start(time);
      osc.stop(time + noteLength);

      // Play simple bass accompaniment
      if (step % 4 === 0) {
        const bassOsc = this.ctx.createOscillator();
        const bassGain = this.ctx.createGain();
        bassOsc.type = "sawtooth";
        bassOsc.frequency.setValueAtTime(freq / 2, time);
        bassGain.gain.setValueAtTime(0.04, time);
        bassGain.gain.exponentialRampToValueAtTime(0.001, time + noteLength * 1.8);
        bassOsc.connect(bassGain);
        bassGain.connect(this.musicVolumeNode!);
        bassOsc.start(time);
        bassOsc.stop(time + noteLength * 2);
      }

      step++;
    }, noteLength * 1000);
  }

  stopMusic() {
    this.isMusicPlaying = false;
    if (this.synthInterval) {
      clearInterval(this.synthInterval);
      this.synthInterval = null;
    }
  }

  playClick() {
    this.initCtx();
    if (!this.ctx || !this.fxVolumeNode) return;

    const time = this.ctx.currentTime;
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();

    osc.type = "triangle";
    osc.frequency.setValueAtTime(800, time);
    osc.frequency.exponentialRampToValueAtTime(100, time + 0.05);

    gain.gain.setValueAtTime(0.15, time);
    gain.gain.exponentialRampToValueAtTime(0.001, time + 0.05);

    osc.connect(gain);
    gain.connect(this.fxVolumeNode);
    osc.start(time);
    osc.stop(time + 0.06);
  }

  playCorrect() {
    this.initCtx();
    if (!this.ctx || !this.fxVolumeNode) return;

    const time = this.ctx.currentTime;
    
    // Play dual notes for harmonious bell chime
    const playBell = (freq: number, delay: number) => {
      const osc1 = this.ctx!.createOscillator();
      const osc2 = this.ctx!.createOscillator();
      const gain = this.ctx!.createGain();

      osc1.type = "sine";
      osc1.frequency.setValueAtTime(freq, time + delay);

      osc2.type = "triangle";
      osc2.frequency.setValueAtTime(freq * 1.5, time + delay); // fifth harmony

      gain.gain.setValueAtTime(0, time + delay);
      gain.gain.linearRampToValueAtTime(0.18, time + delay + 0.02);
      gain.gain.exponentialRampToValueAtTime(0.001, time + delay + 0.4);

      osc1.connect(gain);
      osc2.connect(gain);
      gain.connect(this.fxVolumeNode!);

      osc1.start(time + delay);
      osc1.stop(time + delay + 0.45);
      osc2.start(time + delay);
      osc2.stop(time + delay + 0.45);
    };

    // Bouncy arpeggio C-E-G
    playBell(523.25, 0);       // C5
    playBell(659.25, 0.08);    // E5
    playBell(783.99, 0.16);    // G5
    playBell(1046.50, 0.24);   // C6
  }

  playWrong() {
    this.initCtx();
    if (!this.ctx || !this.fxVolumeNode) return;

    const time = this.ctx.currentTime;
    
    // Low slide buzz: square wave gliding down
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();

    osc.type = "sawtooth";
    osc.frequency.setValueAtTime(220, time);
    osc.frequency.linearRampToValueAtTime(80, time + 0.55);

    gain.gain.setValueAtTime(0, time);
    gain.gain.linearRampToValueAtTime(0.2, time + 0.05);
    gain.gain.exponentialRampToValueAtTime(0.001, time + 0.55);

    // Apply distortion for buzzy feel
    osc.connect(gain);
    gain.connect(this.fxVolumeNode);

    osc.start(time);
    osc.stop(time + 0.6);
  }

  playCoin() {
    this.initCtx();
    if (!this.ctx || !this.fxVolumeNode) return;

    const time = this.ctx.currentTime;
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();

    osc.type = "sine";
    // Authentic double-ping coin chime
    osc.frequency.setValueAtTime(987.77, time); // B5
    osc.frequency.setValueAtTime(1318.51, time + 0.08); // E6

    gain.gain.setValueAtTime(0, time);
    gain.gain.linearRampToValueAtTime(0.2, time + 0.02);
    gain.gain.exponentialRampToValueAtTime(0.001, time + 0.35);

    osc.connect(gain);
    gain.connect(this.fxVolumeNode);

    osc.start(time);
    osc.stop(time + 0.4);
  }

  playHeartLost() {
    this.initCtx();
    if (!this.ctx || !this.fxVolumeNode) return;

    const time = this.ctx.currentTime;
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();

    osc.type = "sawtooth";
    osc.frequency.setValueAtTime(329.63, time); // E4
    osc.frequency.exponentialRampToValueAtTime(146.83, time + 0.4); // D3

    gain.gain.setValueAtTime(0.15, time);
    gain.gain.exponentialRampToValueAtTime(0.001, time + 0.45);

    osc.connect(gain);
    gain.connect(this.fxVolumeNode);

    osc.start(time);
    osc.stop(time + 0.5);
  }

  playLevelWin() {
    this.initCtx();
    if (!this.ctx || !this.fxVolumeNode) return;

    const time = this.ctx.currentTime;
    const notes = [261.63, 329.63, 392.00, 523.25, 392.00, 523.25, 659.25]; // Jazz arpeggio
    const duration = 0.12;

    notes.forEach((freq, idx) => {
      const osc = this.ctx!.createOscillator();
      const gain = this.ctx!.createGain();

      osc.type = "triangle";
      osc.frequency.setValueAtTime(freq, time + idx * duration);
      
      const isLast = idx === notes.length - 1;
      const length = isLast ? 0.6 : duration;

      gain.gain.setValueAtTime(0, time + idx * duration);
      gain.gain.linearRampToValueAtTime(0.18, time + idx * duration + 0.01);
      gain.gain.exponentialRampToValueAtTime(0.001, time + idx * duration + length - 0.01);

      osc.connect(gain);
      gain.connect(this.fxVolumeNode!);

      osc.start(time + idx * duration);
      osc.stop(time + idx * duration + length);
    });
  }
}

export const audio = new RetroAudioEngine();
