/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export interface Question {
  id: number;
  question: string;
  arabicQuestion?: string; // Optional Arabic translated question
  image?: string; // Optional illustration tag or sketch
  answers: string[];
  arabicAnswers?: string[]; // Optional Arabic translated answers
  correctAnswer: string;
  arabicCorrectAnswer?: string; // Optional Arabic translated correct answer
  explanation: string;
  arabicExplanation?: string; // Optional Arabic translated explanation
  difficulty: "Easy" | "Medium" | "Hard";
}

export interface Level {
  id: number;
  worldId: number;
  levelNumber: number;
  questionId: number;
  starsRequired: number;
  coinsReward: number;
  xpReward: number;
}

export interface World {
  id: number;
  name: string;
  arabicName: string;
  description: string;
  themeColor: string;
  bgColor: string;
  textColor: string;
  levelsRange: [number, number]; // [startLevel, endLevel]
  starsRequiredToUnlock: number;
  bgDecorativeElements: string[]; // e.g., ["butterflies", "clouds"]
  accent: string;
}

export interface User {
  username: string;
  email: string;
  displayName: string;
  avatar: string;
  coins: number;
  xp: number;
  stars: number;
  lives: number;
  lastHeartRestoreTime: number; // For passive recovery
  currentWorldId: number;
  currentLevelId: number;
  unlockedWorlds: number[]; // World IDs
  completedLevels: Record<number, number>; // levelId -> stars earned (1, 2, or 3)
  inventory: string[]; // list of purchased item IDs
  achievementsCompleted: string[]; // achievement IDs
  dailyStreak: number;
  lastDailyClaimTime: number;
  role: "Guest" | "Player" | "Moderator" | "Admin";
}

export interface ShopItem {
  id: string;
  name: string;
  arabicName: string;
  category: "avatar" | "background" | "powerup";
  price: number;
  description: string;
  arabicDescription: string;
  image: string; // SVG or unicode description
}

export interface Achievement {
  id: string;
  name: string;
  arabicName: string;
  description: string;
  arabicDescription: string;
  xpReward: number;
  coinsReward: number;
  icon: string;
  conditionType: "total_levels" | "total_coins" | "total_stars" | "perfect_streaks" | "heart_saves";
  conditionValue: number;
}

export interface LeaderboardEntry {
  username: string;
  displayName: string;
  avatar: string;
  stars: number;
  xp: number;
  coins: number;
}

export interface GameSettings {
  musicVolume: number;
  effectsVolume: number;
  isMuted: boolean;
  visualFilter: "color" | "sepia" | "bw"; // 1930s filters
  showScratches: boolean;
  language: "ar" | "en";
}
